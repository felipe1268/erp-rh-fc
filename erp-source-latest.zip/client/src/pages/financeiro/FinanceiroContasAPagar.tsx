import { useState, useMemo, useEffect, Fragment, type ReactNode } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { useCompany } from "@/hooks/useCompany";
import { useToast } from "@/hooks/use-toast";
import { Checkbox } from "@/components/ui/checkbox";
import {
  CheckCircle, AlertTriangle, Search, Calendar, ShoppingCart, FileText,
  ChevronLeft, ChevronRight, CreditCard, Banknote, Clock, Hash, Tag,
  Users, Truck, Briefcase, Scale, Package, Receipt, Wallet,
  Download, Copy, TrendingDown, TrendingUp, Zap, Activity, X,
  Eye, ExternalLink, History, Building2, Paperclip, Hash as HashIcon, Info,
  Trash2, RotateCcw, Pencil, Loader2,
} from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatNumeroOcDisplay } from "@shared/numeroOc";
// Rev. 1626 — single source of truth para origens financeiras
import {
  ORIGEM_LABELS, ORIGEM_ICONS, ORIGEM_COLORS,
  consolidateSubtype, unitLabelFor,
} from "@/lib/financialOrigins";

const MESES = ["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"];

function KV({ label, children, highlight }: { label: string; children: ReactNode; highlight?: boolean }) {
  return (
    <div className={`rounded-md border px-2.5 py-1.5 ${highlight ? "border-amber-300 bg-amber-50" : "border-slate-200 bg-white"}`}>
      <div className="text-[10px] font-semibold text-slate-500 uppercase tracking-wide leading-tight">{label}</div>
      <div className={`text-sm leading-tight mt-0.5 ${highlight ? "font-bold text-amber-900" : "text-slate-800"}`}>{children}</div>
    </div>
  );
}

function formatBRL(v: number) {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(v);
}

// Rev. 1619 — dd/MM/aaaa (regra de ouro do projeto)
function fmtDateBR(dateStr: string | null | undefined): string {
  if (!dateStr) return "—";
  const s = String(dateStr).slice(0, 10);
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s.split("-").reverse().join("/");
  return s;
}

// Rev. 1619 — Extrai nº OC/OS/MED/Folha de origem ou descrição
function extractOcNumero(c: any): string {
  const candidates = [c.origemDescricao, c.descricao, c.contaNome].filter(Boolean) as string[];
  for (const txt of candidates) {
    // OC-2026-0078, OS-123, MED-2026-012, NF 1234, SC-2026-0001
    const m = txt.match(/\b(OC|OS|MED|SC|NF|PO|RC|RPS)[\s-]*\d{2,4}[\s/-]*\d+\b/i);
    if (m) return m[0].toUpperCase().replace(/\s+/g, "-").replace(/\/+/g, "-");
  }
  // Fallbacks por origem + id
  if (c.origemModulo === "folha" && c.origemId) {
    const ref = c.dataVencimento ? c.dataVencimento.slice(0, 7).split("-").reverse().join("/") : "";
    return `FOLHA${ref ? "-" + ref : ""}`;
  }
  if (c.origemModulo === "pj" && c.origemId) return `PJ-${c.origemId}`;
  if (c.origemModulo === "frota" && c.origemId) return `FROTA-${c.origemId}`;
  if (c.origemModulo === "terceiros" && c.origemId) return `MED-${c.origemId}`;
  if (c.origemModulo === "tributario") return `TRIB${c.origemId ? "-" + c.origemId : ""}`;
  if (c.origemModulo === "beneficios" && c.origemId) return `BEN-${c.origemId}`;
  if (c.origemModulo === "almoxarifado" && c.origemId) return `ALM-${c.origemId}`;
  if (c.origemId) return `#${c.origemId}`;
  return "—";
}

// Rev. 1629 — Classificação Efetivo × Projeção
// Projeção = forecast vindo de Planejamento (sem fato gerador). Tudo o mais é Efetivo.
// Origens forecast (sem fato gerador): cronograma e PCP de compras vindo do Planejamento.
// Nota: planejamento_medicao é gravada como tipo='receita' pelo bridge, então não chega aqui;
// excluída para evitar falsa expectativa de filtro.
const PROJECAO_ORIGENS = new Set([
  // Forecast de obra (Planejamento)
  "cronograma_atividade", "planejamento_compra",
  // Forecast de RH/Folha (Rev. 1630/1636)
  "folha_projetada", "encargos_projetado",
  "beneficio_vr_projetado", "beneficio_va_projetado",
  "decimo_terceiro_projetado", "pj_projetado",
  "ferias_projetada", "rescisao_projetada",
]);
function isProjecao(c: any): boolean {
  return PROJECAO_ORIGENS.has(c?.origemModulo);
}

// Rev. 1629c — Remove prefixos redundantes de OC/OS/MED/etc da descrição,
// já que o nº aparece em coluna dedicada. Ex.:
//   "OC OC-2026-0010 — Fornecedor X"   →  "Fornecedor X"
//   "OC #OC-2026-0002 - Propel"        →  "Propel"
//   "MED-2026-012 — Empreiteira Y"     →  "Empreiteira Y"
function stripOcPrefix(text: string): string {
  if (!text) return text;
  // Match: opcional "OC "/"OS "/etc + opcional "#" + código (OC-2026-0010|MED-123|...) + separador
  // Só remove se houver TEXTO após o separador (preserva descrições que são só o nº)
  const re = /^\s*(?:(?:OC|OS|MED|SC|NF|PO|RC|RPS|FOLHA|PJ|FROTA|TRIB|BEN|ALM)\s+)?#?\s*[A-Z]{2,5}[\s-]+\d{2,4}[\s/-]+\d+\s*[—–\-:]\s+(?=\S)/i;
  let s = text.trim();
  for (let i = 0; i < 2; i++) {
    const next = s.replace(re, "").trim();
    if (next === s || !next) break;
    s = next;
  }
  return s || text.trim();
}

// Rev. 1619 — Descrição com fallback inteligente
// Rev. 2396 — Concatena nome do fornecedor (quando preenchido no lançamento)
// pra dar contexto na lista: "PGTO FORNECEDOR — Construtora XPTO Ltda".
function describeEntry(c: any): string {
  const fornec = (c.fornecedorNome ?? "").trim();
  const raw = (c.descricao ?? "").trim();
  const desc = stripOcPrefix(raw);
  const base = (() => {
    if (desc && desc !== "—") return desc;
    const orig = stripOcPrefix((c.origemDescricao ?? "").trim());
    if (orig) return orig;
    if (c.contaNome && c.obraNome) return `${c.contaNome} — ${c.obraNome}`;
    if (c.contaNome) return c.contaNome;
    if (c.obraNome) return c.obraNome;
    if (c.origemModulo) return `Lançamento ${ORIGEM_LABELS[c.origemModulo] ?? c.origemModulo}`;
    return "—";
  })();
  if (fornec && !base.toLowerCase().includes(fornec.toLowerCase())) {
    return `${base} — ${fornec}`;
  }
  return base;
}

// Rev. 1619 — Categoria (plano de contas) + fallback por origem
function categoriaFor(c: any): string {
  if (c.contaNome && String(c.contaNome).trim()) return c.contaNome;
  return ORIGEM_LABELS[c.origemModulo] ?? "Sem categoria";
}

// Rev. 1625/1626 — consolidateSubtype agora vive em @/lib/financialOrigins
const CONSOLIDATE_MIN = 3; // só agrupa quando há ≥ N entries do mesmo subtipo
const CONSOLIDATE_MODE_KEY = "fc_ap_consolidateMode_v1";

// Rev. 1619 — Agrupamento por horizonte de vencimento (gestão de caixa Bragg/Brealey)
function bucketKey(c: any, hojeStr: string): { key: string; order: number; label: string } {
  if (c.status === "pago") return { key: "pago", order: 9, label: "Pagos no mês" };
  if (!c.dataVencimento) return { key: "sem_data", order: 8, label: "Sem data definida" };
  const venc = c.dataVencimento.slice(0, 10);
  if (venc < hojeStr) return { key: "vencidas", order: 0, label: "Vencidas" };
  if (venc === hojeStr) return { key: "hoje", order: 1, label: "Vence hoje" };
  // Esta semana = próximos 7 dias incluindo hoje
  const hoje = new Date(hojeStr + "T00:00:00");
  const v = new Date(venc + "T00:00:00");
  const diff = Math.round((v.getTime() - hoje.getTime()) / 86400000);
  if (diff <= 7) return { key: "semana", order: 2, label: "Esta semana (7 dias)" };
  if (diff <= 15) return { key: "quinzena", order: 3, label: "Próximos 15 dias" };
  if (diff <= 30) return { key: "mes", order: 4, label: "Próximos 30 dias" };
  return { key: "depois", order: 5, label: "Após 30 dias" };
}

// Rev. 1627 — sempre fatiar para "YYYY-MM-DD" antes de parsear:
// timestamps PG (`"2026-04-22 14:44:06.518812"`) quebram `new Date()` no iOS Safari
// com a mensagem nativa "The string did not match the expected pattern."
function getMesFromDate(dateStr: string | null | undefined): number | null {
  if (!dateStr) return null;
  const s = String(dateStr).slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return null;
  const d = new Date(s + "T00:00:00");
  if (isNaN(d.getTime())) return null;
  return d.getMonth() + 1;
}

type MesStatus = "sem_dados" | "lancamento" | "consolidado";

export default function FinanceiroContasAPagar() {
  const { companyId } = useCompany();
  const { toast } = useToast();

  const hoje = new Date();
  const [ano, setAno] = useState(hoje.getFullYear());
  const [mesSel, setMesSel] = useState(hoje.getMonth() + 1);
  const [search, setSearch] = useState("");
  const [origemFilter, setOrigemFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("pendentes");
  // Rev. 1629 — Separação Efetivo × Projeção (APQC PCF 8.7 / PMBOK / Brealey-Myers cap. 30):
  // dívida incorrida (Compras, Folha, PJ, Benefícios, Frota, Parceiros, Almox, Medição, Seguro)
  // não pode dividir tela com forecast de cronograma. Default = Efetivo.
  const [naturezaFilter, setNaturezaFilter] = useState<"efetivo" | "projecao" | "todos">("efetivo");
  const [showPay, setShowPay] = useState<any | null>(null);
  const [dataPagamento, setDataPagamento] = useState(hoje.toISOString().split("T")[0]);
  const [formaPagamento, setFormaPagamento] = useState("pix");
  // Rev. 2540 — conta bancária na baixa (puxa a do lançamento; permite alterar)
  const [contaBancariaId, setContaBancariaId] = useState<number | null>(null);
  // Rev. 2655 — baixa detalhada: valor + juros − descontos + outros, observações, comprovante e cheque
  const [valorPagar, setValorPagar] = useState("");
  const [jurosPay, setJurosPay] = useState("");
  const [descontosPay, setDescontosPay] = useState("");
  const [outrosPay, setOutrosPay] = useState("");
  const [obsPay, setObsPay] = useState("");
  const [comprovanteUrl, setComprovanteUrl] = useState("");
  const [comprovanteNome, setComprovanteNome] = useState("");
  const [uploadingComp, setUploadingComp] = useState(false);
  const [chequeTipo, setChequeTipo] = useState("");
  const [chequeNumero, setChequeNumero] = useState("");
  const [chequeBanco, setChequeBanco] = useState("");
  const [chequeAgencia, setChequeAgencia] = useState("");
  const [chequeConta, setChequeConta] = useState("");
  const [chequeTitular, setChequeTitular] = useState("");
  const [chequeDataEmissao, setChequeDataEmissao] = useState("");
  const [chequeDataBomPara, setChequeDataBomPara] = useState("");
  // Rev. 1620 — seleção em lote (Onda 2)
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [showBulkPay, setShowBulkPay] = useState(false);
  const [bulkDataPagamento, setBulkDataPagamento] = useState(hoje.toISOString().split("T")[0]);
  const [bulkFormaPagamento, setBulkFormaPagamento] = useState("pix");
  // Rev. 1621 — modal de detalhes do título
  const [detailEntryId, setDetailEntryId] = useState<number | null>(null);
  // Rev. 2657 — EDITAR (lançamento manual) + ANEXAR documento
  const [showEdit, setShowEdit] = useState<any | null>(null);
  const [editForm, setEditForm] = useState({
    descricao: "", valorPrevisto: "", dataCompetencia: "", dataVencimento: "",
    contaNome: "", obraNome: "", formaPagamento: "", fornecedorNome: "", observacoes: "",
  });
  const [showAnexo, setShowAnexo] = useState<any | null>(null);
  const [anexoUrl, setAnexoUrl] = useState("");
  const [anexoNome, setAnexoNome] = useState("");
  const [uploadingAnexo, setUploadingAnexo] = useState(false);
  // Rev. 1625 — consolidação visual de RH/Benefícios/PJ/Frota/Terceiros
  const [consolidateMode, setConsolidateMode] = useState<boolean>(() => {
    if (typeof window === "undefined") return true;
    const v = window.localStorage.getItem(CONSOLIDATE_MODE_KEY);
    return v === null ? true : v === "1";
  });
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());
  useEffect(() => {
    if (typeof window !== "undefined") {
      window.localStorage.setItem(CONSOLIDATE_MODE_KEY, consolidateMode ? "1" : "0");
    }
  }, [consolidateMode]);
  const toggleGroupExpand = (key: string) => {
    setExpandedGroups(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key); else next.add(key);
      return next;
    });
  };

  const detailQuery = (trpc as any).financial.getEntryDetalhe.useQuery(
    { id: detailEntryId ?? 0, companyId },
    { enabled: !!detailEntryId && !!companyId }
  );

  const { data: allContas, isLoading, refetch } = (trpc as any).financial.getContasAPagarByYear.useQuery(
    { companyId, ano },
    { enabled: !!companyId }
  );

  const payMut = (trpc as any).financial.updateEntryStatus.useMutation({
    onSuccess: () => { toast({ title: "Pagamento registrado!" }); setShowPay(null); refetch(); },
    onError: (e: any) => toast({ title: "Erro", description: e.message, variant: "destructive" }),
  });

  // Rev. 2657 — fornecedores e categorias para os datalists do modal EDITAR
  const { data: fornecedoresList } = (trpc as any).compras.listarFornecedores.useQuery(
    { companyId },
    { enabled: !!companyId }
  );
  const fornecedoresOptions: { id: number; nome: string }[] = (() => {
    const list: any[] = Array.isArray(fornecedoresList) ? fornecedoresList : [];
    const seen = new Set<string>();
    const out: { id: number; nome: string }[] = [];
    for (const f of list) {
      const nome = (f.razaoSocial ?? f.nomeFantasia ?? f.nome ?? "").trim();
      const k = nome.toLowerCase();
      if (!nome || seen.has(k)) continue;
      seen.add(k);
      out.push({ id: f.id, nome });
    }
    return out;
  })();
  const { data: accountsList } = (trpc as any).financial.getAccounts.useQuery(
    { companyId },
    { enabled: !!companyId }
  );
  const categoriasOptions: string[] = (() => {
    const list: any[] = Array.isArray(accountsList) ? accountsList : [];
    const seen = new Set<string>();
    const out: string[] = [];
    for (const a of list) {
      if (String(a.tipo) === "receita") continue;
      const nome = String(a.nome ?? "").trim();
      const k = nome.toLowerCase();
      if (!nome || seen.has(k)) continue;
      seen.add(k);
      out.push(nome);
    }
    return out;
  })();

  // Rev. 2657 — EDITAR lançamento manual (origem nula/recorrente, não pago)
  const updateEntryMut = (trpc as any).financial.updateEntry.useMutation({
    onSuccess: () => {
      toast({ title: "Lançamento atualizado!" });
      setShowEdit(null);
      refetch();
      if (detailEntryId) detailQuery.refetch();
    },
    onError: (e: any) => toast({ title: "Erro ao editar", description: e.message, variant: "destructive" }),
  });
  function openEdit(c: any) {
    if (c.status === "pago" || c.status === "recebido") {
      toast({ title: "Lançamento já pago", description: "Estorne antes de editar.", variant: "destructive" });
      return;
    }
    // Rev. 2661 — títulos vinculados a outro módulo agora SÃO editáveis.
    // Quando a origem é Compras (OC), o save espelha fornecedor/vencimento/forma/obs
    // de volta na Ordem de Compra (ver banner informativo no modal).
    setEditForm({
      descricao: c.descricao ?? "",
      valorPrevisto: String(c.valorPrevisto ?? ""),
      dataCompetencia: (c.dataCompetencia ?? "").slice(0, 10),
      dataVencimento: (c.dataVencimento ?? "").slice(0, 10),
      contaNome: c.contaNome ?? "",
      obraNome: c.obraNome ?? "",
      formaPagamento: c.formaPagamento ?? "",
      fornecedorNome: c.fornecedorNome ?? "",
      observacoes: c.observacoes ?? "",
    });
    setShowEdit(c);
  }
  function handleSaveEdit() {
    if (!showEdit) return;
    if (!editForm.descricao.trim() || !editForm.valorPrevisto) {
      toast({ title: "Preencha descrição e valor", variant: "destructive" });
      return;
    }
    const valor = parseFloat(String(editForm.valorPrevisto).replace(",", "."));
    if (!Number.isFinite(valor) || valor <= 0) {
      toast({ title: "Valor inválido", variant: "destructive" });
      return;
    }
    updateEntryMut.mutate({
      id: showEdit.id,
      companyId,
      descricao: editForm.descricao.trim(),
      valorPrevisto: valor,
      dataCompetencia: editForm.dataCompetencia || undefined,
      dataVencimento: editForm.dataVencimento || undefined,
      contaNome: editForm.contaNome.trim() || undefined,
      obraNome: editForm.obraNome.trim() || undefined,
      formaPagamento: editForm.formaPagamento || undefined,
      fornecedorNome: editForm.fornecedorNome.trim() || undefined,
      observacoes: editForm.observacoes.trim() || undefined,
    });
  }

  // Rev. 2657 — ANEXAR documento ao título (boleto/NF/foto)
  const anexarMut = (trpc as any).financial.anexarDocumento.useMutation({
    onSuccess: () => {
      toast({ title: "Documento anexado!" });
      setShowAnexo(null);
      refetch();
      if (detailEntryId) detailQuery.refetch();
    },
    onError: (e: any) => toast({ title: "Erro ao anexar", description: e.message, variant: "destructive" }),
  });
  function openAnexo(c: any) {
    setAnexoUrl(c.anexoUrl ?? "");
    setAnexoNome(c.anexoNome ?? "");
    setShowAnexo(c);
  }
  const handleUploadAnexo = async (file: File) => {
    setUploadingAnexo(true);
    try {
      const base64: string = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result).split(",")[1] ?? "");
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
      const res = await uploadCompMut.mutateAsync({ fileName: file.name, fileBase64: base64, contentType: file.type || "application/octet-stream" });
      setAnexoUrl(res.url);
      setAnexoNome(file.name);
      toast({ title: "Upload concluído", description: "Clique em Salvar para vincular ao título." });
    } catch (e: any) {
      toast({ title: "Erro no upload", description: e?.message, variant: "destructive" });
    } finally {
      setUploadingAnexo(false);
    }
  };
  function handleSaveAnexo() {
    if (!showAnexo) return;
    if (!anexoUrl) { toast({ title: "Selecione um arquivo", variant: "destructive" }); return; }
    anexarMut.mutate({ id: showAnexo.id, companyId, anexoUrl, anexoNome: anexoNome || undefined });
  }

  // Rev. 2540 — contas bancárias para o seletor da baixa
  const { data: bankAccounts } = (trpc as any).financial.getBankAccounts.useQuery(
    { companyId },
    { enabled: !!companyId }
  );
  // Sincroniza conta bancária do lançamento ao abrir o diálogo (permite alterar)
  useEffect(() => {
    setContaBancariaId(showPay?.contaBancariaId ?? null);
    // Rev. 2655 — inicializa campos da baixa detalhada ao abrir
    setValorPagar(showPay?.valorPrevisto != null ? String(showPay.valorPrevisto) : "");
    setJurosPay("");
    setDescontosPay("");
    setOutrosPay("");
    setObsPay("");
    setComprovanteUrl("");
    setComprovanteNome("");
    setChequeTipo("");
    setChequeNumero("");
    setChequeBanco("");
    setChequeAgencia("");
    setChequeConta("");
    setChequeTitular("");
    setChequeDataEmissao("");
    setChequeDataBomPara("");
  }, [showPay]);

  // Rev. 2655 — total da baixa = valor + juros − descontos + outros (±)
  const totalPagar = useMemo(() => {
    const n = (s: string) => { const x = parseFloat(String(s).replace(",", ".")); return Number.isFinite(x) ? x : 0; };
    return n(valorPagar) + n(jurosPay) - n(descontosPay) + n(outrosPay);
  }, [valorPagar, jurosPay, descontosPay, outrosPay]);

  // Rev. 2655 — upload de comprovante (PDF/Word/imagem)
  const uploadCompMut = (trpc as any).financial.uploadComprovante.useMutation();
  const handleUploadComprovante = async (file: File) => {
    setUploadingComp(true);
    try {
      const base64: string = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result).split(",")[1] ?? "");
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
      const res = await uploadCompMut.mutateAsync({ fileName: file.name, fileBase64: base64, contentType: file.type || "application/octet-stream" });
      setComprovanteUrl(res.url);
      setComprovanteNome(file.name);
      toast({ title: "Comprovante anexado!" });
    } catch (e: any) {
      toast({ title: "Erro ao anexar", description: e?.message, variant: "destructive" });
    } finally {
      setUploadingComp(false);
    }
  };

  // Rev. 1620 — limpar seleção ao mudar mês/ano para evitar pagar item de outro escopo
  useEffect(() => { setSelectedIds(new Set()); }, [mesSel, ano]);

  const bulkPayMut = (trpc as any).financial.bulkUpdateStatus.useMutation({
    onSuccess: (r: any) => {
      toast({ title: `${r.updated} título(s) marcados como pagos!` });
      setShowBulkPay(false);
      setSelectedIds(new Set());
      refetch();
    },
    onError: (e: any) => toast({ title: "Erro", description: e.message, variant: "destructive" }),
  });

  // Rev. 2228 — Excluir lançamento (duplicidade) + Estornar pagamento
  const [showDelete, setShowDelete] = useState<any | null>(null);
  const [motivoDelete, setMotivoDelete] = useState("");
  const [showEstorno, setShowEstorno] = useState<any | null>(null);
  const [motivoEstorno, setMotivoEstorno] = useState("");
  const deleteMut = (trpc as any).financial.deleteEntry.useMutation({
    onSuccess: () => {
      toast({ title: "Lançamento excluído!", description: "Operação registrada no log de auditoria." });
      setShowDelete(null); setMotivoDelete(""); refetch();
    },
    onError: (e: any) => toast({ title: "Erro ao excluir", description: e.message, variant: "destructive" }),
  });
  const estornoMut = (trpc as any).financial.estornarPagamento.useMutation({
    onSuccess: () => {
      toast({ title: "Pagamento estornado!", description: "Lançamento voltou para 'A Pagar'. Registrado no log de auditoria." });
      setShowEstorno(null); setMotivoEstorno(""); refetch();
    },
    onError: (e: any) => toast({ title: "Erro ao estornar", description: e.message, variant: "destructive" }),
  });

  const mesesStatus: Record<number, MesStatus> = useMemo(() => {
    const map: Record<number, MesStatus> = {};
    for (let m = 1; m <= 12; m++) map[m] = "sem_dados";
    if (!allContas) return map;
    for (const c of allContas) {
      const m = getMesFromDate(c.dataVencimento);
      if (!m) continue;
      const cur = map[m];
      const isPago = c.status === "pago";
      if (cur === "sem_dados") {
        map[m] = isPago ? "consolidado" : "lancamento";
      } else if (cur === "consolidado" && !isPago) {
        map[m] = "lancamento";
      }
    }
    return map;
  }, [allContas]);

  const mesData = useMemo(() => {
    if (!allContas) return [];
    return allContas.filter((c: any) => getMesFromDate(c.dataVencimento) === mesSel);
  }, [allContas, mesSel]);

  const hojeStr = hoje.toISOString().split("T")[0];

  const filtered = useMemo(() => {
    let list = mesData;
    if (statusFilter === "pendentes") list = list.filter((c: any) => c.status !== "pago");
    if (statusFilter === "pagos") list = list.filter((c: any) => c.status === "pago");
    if (naturezaFilter === "efetivo") list = list.filter((c: any) => !isProjecao(c));
    else if (naturezaFilter === "projecao") list = list.filter((c: any) => isProjecao(c));
    if (origemFilter !== "all") list = list.filter((c: any) => c.origemModulo === origemFilter);
    if (search) {
      const q = search.toLowerCase();
      list = list.filter((c: any) =>
        (c.descricao ?? "").toLowerCase().includes(q) ||
        (c.contaNome ?? "").toLowerCase().includes(q) ||
        (c.obraNome ?? "").toLowerCase().includes(q) ||
        (c.origemDescricao ?? "").toLowerCase().includes(q) ||
        extractOcNumero(c).toLowerCase().includes(q)
      );
    }
    // Ordena por: bucket (vencidas primeiro) → data → valor desc
    return list.slice().sort((a: any, b: any) => {
      const ba = bucketKey(a, hojeStr).order;
      const bb = bucketKey(b, hojeStr).order;
      if (ba !== bb) return ba - bb;
      const da = (a.dataVencimento || "9999-12-31").slice(0, 10);
      const db = (b.dataVencimento || "9999-12-31").slice(0, 10);
      if (da !== db) return da.localeCompare(db);
      return Number(b.valorPrevisto ?? 0) - Number(a.valorPrevisto ?? 0);
    });
  }, [mesData, statusFilter, naturezaFilter, origemFilter, search, hojeStr]);

  // Rev. 1619 — agrupamento por horizonte de vencimento (cabeçalhos sticky)
  const grupos = useMemo(() => {
    const map = new Map<string, { label: string; order: number; items: any[]; total: number }>();
    for (const c of filtered) {
      const b = bucketKey(c, hojeStr);
      if (!map.has(b.key)) map.set(b.key, { label: b.label, order: b.order, items: [], total: 0 });
      const g = map.get(b.key)!;
      g.items.push(c);
      g.total += Number(c.valorPrevisto ?? 0);
    }
    return Array.from(map.values()).sort((a, b) => a.order - b.order);
  }, [filtered, hojeStr]);

  // Rev. 1629 — KPIs respeitam o escopo (Efetivo/Projeção/Todos) selecionado para evitar
  // que a tela mostre números de "dívida total" enquanto a lista oculta projeções.
  const escopoMes = useMemo(() => {
    if (naturezaFilter === "efetivo") return mesData.filter((c: any) => !isProjecao(c));
    if (naturezaFilter === "projecao") return mesData.filter(isProjecao);
    return mesData;
  }, [mesData, naturezaFilter]);
  const pendentes = escopoMes.filter((c: any) => c.status !== "pago");
  const pagos = escopoMes.filter((c: any) => c.status === "pago");
  const vencidos = pendentes.filter((c: any) => c.dataVencimento && c.dataVencimento < hojeStr);

  const totalMes = escopoMes.reduce((s: number, c: any) => s + Number(c.valorPrevisto ?? 0), 0);
  const totalPago = pagos.reduce((s: number, c: any) => s + Number(c.valorRealizado ?? c.valorPrevisto ?? 0), 0);
  const totalPendente = pendentes.reduce((s: number, c: any) => s + Number(c.valorPrevisto ?? 0), 0);
  const totalVencido = vencidos.reduce((s: number, c: any) => s + Number(c.valorPrevisto ?? 0), 0);
  const projecoesOcultas = naturezaFilter === "efetivo" ? mesData.filter(isProjecao).length : 0;

  // Rev. 2943 — "Em Aberto (Acumulado)": soma de TODOS os títulos não-pagos do ano
  // (todos os meses), não só do mês selecionado. Respeita o escopo Efetivo/Projeção/Todos
  // (Rev. 1629) para casar com os demais KPIs. "Vencido" = parcela do acumulado já em atraso.
  const acumuladoAberto = useMemo(() => {
    if (!allContas) return { total: 0, count: 0, vencido: 0 };
    let list = (allContas as any[]).filter((c: any) => c.status !== "pago");
    if (naturezaFilter === "efetivo") list = list.filter((c: any) => !isProjecao(c));
    else if (naturezaFilter === "projecao") list = list.filter((c: any) => isProjecao(c));
    let total = 0;
    let vencido = 0;
    for (const c of list) {
      const v = Number(c.valorPrevisto ?? 0);
      total += v;
      if (c.dataVencimento && c.dataVencimento.slice(0, 10) < hojeStr) vencido += v;
    }
    return { total, count: list.length, vencido };
  }, [allContas, naturezaFilter, hojeStr]);

  const origensDisponiveis = useMemo(() => {
    if (!mesData.length) return [];
    const s = new Set(mesData.map((c: any) => c.origemModulo).filter(Boolean));
    return Array.from(s) as string[];
  }, [mesData]);

  // ─────────────────────────────────────────────────────────────────
  // Rev. 1620 — Onda 2/3: anti-duplicidade, aging, projeção, KPIs Hackett
  // ─────────────────────────────────────────────────────────────────

  // Anti-duplicidade: chaves repetidas no ano (descricao+valor+vencimento)
  const duplicateKeys = useMemo(() => {
    if (!allContas) return new Set<string>();
    const cnt = new Map<string, number>();
    for (const c of allContas as any[]) {
      const key = `${(c.descricao ?? c.origemDescricao ?? c.contaNome ?? "").toLowerCase().trim()}|${Number(c.valorPrevisto ?? 0).toFixed(2)}|${(c.dataVencimento ?? "").slice(0, 10)}`;
      if (!key.startsWith("|")) cnt.set(key, (cnt.get(key) ?? 0) + 1);
    }
    return new Set(Array.from(cnt.entries()).filter(([, n]) => n > 1).map(([k]) => k));
  }, [allContas]);

  const dupKeyOf = (c: any) =>
    `${(c.descricao ?? c.origemDescricao ?? c.contaNome ?? "").toLowerCase().trim()}|${Number(c.valorPrevisto ?? 0).toFixed(2)}|${(c.dataVencimento ?? "").slice(0, 10)}`;

  // Aging Hackett (apenas pendentes vencidos): 1-15, 16-30, 31-60, 61-90, >90
  const agingBuckets = useMemo(() => {
    const buckets = [
      { label: "1-15 dias", min: 1, max: 15, total: 0, count: 0, color: "amber" },
      { label: "16-30 dias", min: 16, max: 30, total: 0, count: 0, color: "orange" },
      { label: "31-60 dias", min: 31, max: 60, total: 0, count: 0, color: "red" },
      { label: "61-90 dias", min: 61, max: 90, total: 0, count: 0, color: "rose" },
      { label: "+90 dias", min: 91, max: 99999, total: 0, count: 0, color: "purple" },
    ];
    for (const c of vencidos) {
      const dias = Number(c.diasAtraso ?? 0);
      const b = buckets.find(x => dias >= x.min && dias <= x.max);
      if (b) { b.total += Number(c.valorPrevisto ?? 0); b.count += 1; }
    }
    return buckets;
  }, [vencidos]);

  // Projeção de caixa (Brealey/Myers — short-term cash forecast)
  // Rev. 1629 — respeita filtro Efetivo × Projeção × Todos para coerência com KPIs/lista.
  const cashProjection = useMemo(() => {
    const horizons = [7, 15, 30, 60, 90];
    const result: { dias: number; total: number; count: number }[] = [];
    if (!allContas) return horizons.map(d => ({ dias: d, total: 0, count: 0 }));
    const escopo = (allContas as any[]).filter(c => {
      if (naturezaFilter === "efetivo") return !isProjecao(c);
      if (naturezaFilter === "projecao") return isProjecao(c);
      return true;
    });
    const today = new Date(hojeStr);
    for (const dias of horizons) {
      const limite = new Date(today);
      limite.setDate(limite.getDate() + dias);
      const limiteStr = limite.toISOString().slice(0, 10);
      const items = escopo.filter(c =>
        c.status !== "pago" && c.dataVencimento &&
        c.dataVencimento.slice(0, 10) >= hojeStr &&
        c.dataVencimento.slice(0, 10) <= limiteStr
      );
      result.push({
        dias,
        total: items.reduce((s, c) => s + Number(c.valorPrevisto ?? 0), 0),
        count: items.length,
      });
    }
    return result;
  }, [allContas, hojeStr, naturezaFilter]);

  // KPIs Hackett: DPO (Days Payable Outstanding), % on-time, % eletrônico
  const kpisHackett = useMemo(() => {
    if (!allContas || allContas.length === 0) return { dpo: 0, onTime: 0, eletronico: 0, totalPagos: 0 };
    const pgs = (allContas as any[]).filter(c => c.status === "pago" && c.dataPagamento && c.dataVencimento);
    if (pgs.length === 0) return { dpo: 0, onTime: 0, eletronico: 0, totalPagos: 0 };
    // DPO simplificado: média de dias entre competência e pagamento
    let somaDias = 0;
    let onTimeCount = 0;
    let eletronicoCount = 0;
    for (const c of pgs) {
      const comp = new Date((c.dataCompetencia ?? c.dataVencimento).slice(0, 10) + "T00:00:00");
      const pag = new Date(c.dataPagamento.slice(0, 10) + "T00:00:00");
      const venc = new Date(c.dataVencimento.slice(0, 10) + "T00:00:00");
      somaDias += Math.max(0, Math.round((pag.getTime() - comp.getTime()) / 86400000));
      if (pag.getTime() <= venc.getTime()) onTimeCount += 1;
      const f = (c.formaPagamento ?? "").toLowerCase();
      if (f === "pix" || f === "ted" || f === "debito_automatico") eletronicoCount += 1;
    }
    return {
      dpo: Math.round(somaDias / pgs.length),
      onTime: Math.round((onTimeCount / pgs.length) * 100),
      eletronico: Math.round((eletronicoCount / pgs.length) * 100),
      totalPagos: pgs.length,
    };
  }, [allContas]);

  // Seleção em lote
  const selectableIds = useMemo(
    () => filtered.filter((c: any) => c.status !== "pago" && !isProjecao(c)).map((c: any) => c.id as number),
    [filtered]
  );
  const allVisibleSelected = selectableIds.length > 0 && selectableIds.every(id => selectedIds.has(id));
  const toggleSelect = (id: number) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };
  const toggleSelectAllVisible = () => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (allVisibleSelected) selectableIds.forEach(id => next.delete(id));
      else selectableIds.forEach(id => next.add(id));
      return next;
    });
  };
  const selectedTotal = useMemo(() => {
    if (!allContas || selectedIds.size === 0) return 0;
    return (allContas as any[])
      .filter(c => selectedIds.has(c.id))
      .reduce((s, c) => s + Number(c.valorPrevisto ?? 0), 0);
  }, [allContas, selectedIds]);

  // Exportar CSV (Excel-friendly, BOM + ; separador padrão BR)
  const exportCsv = () => {
    if (!filtered.length) return;
    const header = ["Vencimento", "Nº OC/OS", "Descrição", "Categoria", "Origem", "Obra", "Valor Previsto", "Valor Pago", "Status", "Data Pagamento", "Forma Pagamento"];
    const rows = filtered.map((c: any) => [
      fmtDateBR(c.dataVencimento),
      extractOcNumero(c),
      (describeEntry(c) ?? "").replace(/[\r\n;]/g, " "),
      (categoriaFor(c) ?? "").replace(/[\r\n;]/g, " "),
      ORIGEM_LABELS[c.origemModulo] ?? c.origemModulo ?? "",
      (c.obraNome ?? "").replace(/[\r\n;]/g, " "),
      Number(c.valorPrevisto ?? 0).toFixed(2).replace(".", ","),
      c.valorRealizado ? Number(c.valorRealizado).toFixed(2).replace(".", ",") : "",
      c.status === "pago" ? "Pago" : (c.dataVencimento && c.dataVencimento.slice(0, 10) < hojeStr ? "Vencido" : "A Pagar"),
      fmtDateBR(c.dataPagamento),
      c.formaPagamento ?? "",
    ]);
    const csv = "\uFEFF" + [header, ...rows].map(r => r.map(v => `"${String(v ?? "").replace(/"/g, '""')}"`).join(";")).join("\r\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `contas-a-pagar_${MESES[mesSel - 1]}_${ano}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: `CSV exportado: ${rows.length} linhas` });
  };

  return (
    <DashboardLayout>
      {/* Rev. 2227 — Tela de Contas a Pagar agora ocupa a largura total
          disponível (antes capada em 1600px → coluna "Ações" cortava em telas
          médias/grandes). Coluna Ações vira sticky-right pra nunca clipar. */}
      <div className="w-full mx-auto px-4 py-6 space-y-5">

        <div>
          <h1 className="text-2xl font-bold text-gray-900">Contas a Pagar</h1>
          <p className="text-sm text-gray-500 mt-1">Despesas e obrigações financeiras por mês</p>
        </div>

        {/* Navegação Ano + Meses */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <button onClick={() => setAno(a => a - 1)} className="p-1 rounded hover:bg-gray-100 text-gray-500 hover:text-gray-800">
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="text-base font-bold text-gray-800 min-w-[3.5rem] text-center">{ano}</span>
                <button onClick={() => setAno(a => a + 1)} className="p-1 rounded hover:bg-gray-100 text-gray-500 hover:text-gray-800">
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
              <div className="flex items-center gap-4 text-xs text-gray-500">
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-500 inline-block" />Com lançamento</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-500 inline-block" />Consolidado</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-gray-300 inline-block" />Sem dados</span>
              </div>
            </div>
            <div className="grid grid-cols-6 sm:grid-cols-12 gap-1.5">
              {MESES.map((m, i) => {
                const num = i + 1;
                const status = mesesStatus[num];
                const isSelected = mesSel === num;
                return (
                  <button
                    key={m}
                    onClick={() => setMesSel(num)}
                    className={`relative flex flex-col items-center gap-1 py-2 rounded-lg border text-xs font-medium transition-all
                      ${isSelected
                        ? "border-blue-500 bg-blue-50 text-blue-700 shadow-sm"
                        : "border-gray-200 bg-white text-gray-500 hover:border-gray-300 hover:bg-gray-50"
                      }`}
                  >
                    <span>{m}</span>
                    <span className={`w-1.5 h-1.5 rounded-full ${
                      status === "consolidado" ? "bg-green-500" :
                      status === "lancamento" ? "bg-blue-500" :
                      "bg-gray-300"
                    }`} />
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <Card className="border-0 shadow-sm border-l-4 border-l-gray-400">
            <CardContent className="p-4">
              <p className="text-xs text-gray-500 mb-1 flex items-center gap-1"><Banknote className="w-3 h-3" />Total {MESES[mesSel-1]}</p>
              <p className="text-lg font-bold text-gray-800">{formatBRL(totalMes)}</p>
              <p className="text-xs text-gray-400">{mesData.length} conta(s)</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm border-l-4 border-l-indigo-500">
            <CardContent className="p-4">
              <p className="text-xs text-gray-500 mb-1 flex items-center gap-1"><Wallet className="w-3 h-3 text-indigo-500" />Em Aberto (Acum.)</p>
              <p className="text-lg font-bold text-indigo-700">{formatBRL(acumuladoAberto.total)}</p>
              <p className="text-xs text-gray-400">
                {acumuladoAberto.count} título(s) · todos os meses
                {acumuladoAberto.vencido > 0 && (
                  <span className="text-red-500"> · {formatBRL(acumuladoAberto.vencido)} vencido</span>
                )}
              </p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm border-l-4 border-l-orange-500">
            <CardContent className="p-4">
              <p className="text-xs text-gray-500 mb-1 flex items-center gap-1"><Clock className="w-3 h-3" />A Pagar</p>
              <p className="text-lg font-bold text-orange-600">{formatBRL(totalPendente)}</p>
              <p className="text-xs text-gray-400">{pendentes.length} pendente(s)</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm border-l-4 border-l-red-500">
            <CardContent className="p-4">
              <p className="text-xs text-gray-500 mb-1 flex items-center gap-1"><AlertTriangle className="w-3 h-3 text-red-500" />Vencidas</p>
              <p className="text-lg font-bold text-red-600">{formatBRL(totalVencido)}</p>
              <p className="text-xs text-gray-400">{vencidos.length} em atraso</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm border-l-4 border-l-green-500">
            <CardContent className="p-4">
              <p className="text-xs text-gray-500 mb-1 flex items-center gap-1"><CheckCircle className="w-3 h-3 text-green-500" />Pago</p>
              <p className="text-lg font-bold text-green-700">{formatBRL(totalPago)}</p>
              <p className="text-xs text-gray-400">{pagos.length} quitado(s)</p>
            </CardContent>
          </Card>
        </div>

        {/* Rev. 1620 — Onda 3: Projeção de Caixa (Brealey short-term forecast) */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2 px-5 pt-4">
            <CardTitle className="text-sm font-semibold text-gray-700 flex items-center gap-2">
              <TrendingDown className="w-4 h-4 text-blue-500" />
              Projeção de Saídas — próximos dias
              <span className="text-xs font-normal text-gray-400 ml-1">(a partir de hoje, {fmtDateBR(hojeStr)})</span>
              {naturezaFilter !== "todos" && (
                <span className={`ml-1 text-[10px] font-medium px-2 py-0.5 rounded-full ${naturezaFilter === "efetivo" ? "bg-emerald-100 text-emerald-700" : "bg-violet-100 text-violet-700"}`}>
                  {naturezaFilter === "efetivo" ? "💰 Efetivo" : "📊 Projeção"}
                </span>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="px-5 pb-4">
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              {cashProjection.map(p => (
                <div key={p.dias} className="rounded-lg border border-blue-100 bg-gradient-to-br from-blue-50 to-white p-3">
                  <div className="text-[11px] font-semibold text-blue-700 uppercase tracking-wide flex items-center gap-1">
                    <Clock className="w-3 h-3" />Próx. {p.dias}d
                  </div>
                  <div className="text-base font-bold text-slate-800 tabular-nums mt-1">{formatBRL(p.total)}</div>
                  <div className="text-[10px] text-slate-400">{p.count} título(s)</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Rev. 1620 — Onda 3: Aging Hackett + KPIs */}
        {(vencidos.length > 0 || kpisHackett.totalPagos > 0) && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {vencidos.length > 0 && (
              <Card className="border-0 shadow-sm lg:col-span-2">
                <CardHeader className="pb-2 px-5 pt-4">
                  <CardTitle className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                    <Activity className="w-4 h-4 text-red-500" />
                    Aging — Idade dos Vencidos
                    <span className="text-xs font-normal text-gray-400 ml-1">(padrão Hackett)</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="px-5 pb-4">
                  <div className="grid grid-cols-5 gap-2">
                    {agingBuckets.map(b => {
                      const colorMap: Record<string, string> = {
                        amber: "border-amber-200 bg-amber-50 text-amber-700",
                        orange: "border-orange-200 bg-orange-50 text-orange-700",
                        red: "border-red-200 bg-red-50 text-red-700",
                        rose: "border-rose-300 bg-rose-50 text-rose-700",
                        purple: "border-purple-300 bg-purple-50 text-purple-700",
                      };
                      return (
                        <div key={b.label} className={`rounded-lg border p-2.5 ${colorMap[b.color]}`}>
                          <div className="text-[10px] font-semibold uppercase tracking-wide">{b.label}</div>
                          <div className="text-sm font-bold tabular-nums mt-0.5">{formatBRL(b.total)}</div>
                          <div className="text-[10px] opacity-70">{b.count} título(s)</div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            )}
            {kpisHackett.totalPagos > 0 && (
              <Card className="border-0 shadow-sm">
                <CardHeader className="pb-2 px-5 pt-4">
                  <CardTitle className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-indigo-500" />
                    Performance AP
                    <span className="text-xs font-normal text-gray-400 ml-1">(base: {kpisHackett.totalPagos} pagos)</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="px-5 pb-4 grid grid-cols-3 gap-2">
                  <div className="rounded-lg border border-indigo-100 bg-indigo-50/40 p-2">
                    <div className="text-[10px] font-semibold uppercase tracking-wide text-indigo-700">DPO</div>
                    <div className="text-base font-bold text-indigo-900 tabular-nums mt-0.5">{kpisHackett.dpo}d</div>
                    <div className="text-[10px] text-indigo-500">prazo médio</div>
                  </div>
                  <div className="rounded-lg border border-emerald-100 bg-emerald-50/40 p-2">
                    <div className="text-[10px] font-semibold uppercase tracking-wide text-emerald-700">No prazo</div>
                    <div className="text-base font-bold text-emerald-900 tabular-nums mt-0.5">{kpisHackett.onTime}%</div>
                    <div className="text-[10px] text-emerald-500">on-time pay</div>
                  </div>
                  <div className="rounded-lg border border-cyan-100 bg-cyan-50/40 p-2">
                    <div className="text-[10px] font-semibold uppercase tracking-wide text-cyan-700">Eletrônico</div>
                    <div className="text-base font-bold text-cyan-900 tabular-nums mt-0.5">{kpisHackett.eletronico}%</div>
                    <div className="text-[10px] text-cyan-500">PIX/TED/DA</div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {/* Filtros */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4 flex flex-wrap gap-3 items-center">
            <div className="flex rounded-lg border border-gray-200 overflow-hidden">
              {[["pendentes","A Pagar"],["pagos","Pagos"],["all","Todos"]].map(([v,l]) => (
                <button key={v}
                  onClick={() => setStatusFilter(v)}
                  className={`px-3 py-1.5 text-xs font-medium transition-colors ${statusFilter === v ? "bg-blue-600 text-white" : "bg-white text-gray-600 hover:bg-gray-50"}`}>
                  {l}
                </button>
              ))}
            </div>
            {/* Rev. 1629 — Efetivo × Projeção (separação fundamental APQC/PMBOK/Brealey-Myers) */}
            <div className="flex rounded-lg border border-violet-200 overflow-hidden" title="Efetivo = dívida real (OC, Folha, PJ, etc.). Projeção = forecast do cronograma.">
              {[
                ["efetivo","Efetivo","💰"],
                ["projecao","Projeção","📊"],
                ["todos","Todos","∑"],
              ].map(([v,l,ico]) => (
                <button key={v}
                  onClick={() => setNaturezaFilter(v as any)}
                  className={`px-3 py-1.5 text-xs font-medium transition-colors inline-flex items-center gap-1 ${naturezaFilter === v ? "bg-violet-600 text-white" : "bg-white text-violet-700 hover:bg-violet-50"}`}>
                  <span>{ico}</span>{l}
                </button>
              ))}
            </div>
            {origensDisponiveis.length > 0 && (
              <Select value={origemFilter} onValueChange={setOrigemFilter}>
                <SelectTrigger className="w-40 h-8 text-xs">
                  <SelectValue placeholder="Origem" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas origens</SelectItem>
                  {origensDisponiveis.map((o: string) => (
                    <SelectItem key={o} value={o}>{ORIGEM_LABELS[o] ?? o}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
            <div className="relative flex-1 min-w-[180px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input className="pl-9 h-8 text-sm" placeholder="Buscar conta, OC/OS, fornecedor..." value={search} onChange={e => setSearch(e.target.value)} />
            </div>
            <Button variant="outline" size="sm" onClick={exportCsv} className="h-8 text-xs gap-1" disabled={!filtered.length}>
              <Download className="w-3.5 h-3.5" />Exportar CSV
            </Button>
            {/* Rev. 1625 — Toggle Consolidar RH/Benefícios/Recorrentes */}
            <button
              onClick={() => { setConsolidateMode(v => !v); setExpandedGroups(new Set()); }}
              className={`h-8 text-xs px-3 rounded-md border inline-flex items-center gap-1.5 transition-colors ${
                consolidateMode
                  ? "bg-indigo-600 text-white border-indigo-600 hover:bg-indigo-700"
                  : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
              }`}
              title="Agrupa folha, vales, PJ, frota e medições em uma linha por mês"
            >
              <Users className="w-3.5 h-3.5" />
              {consolidateMode ? "Consolidado: ON" : "Consolidado: OFF"}
            </button>
          </CardContent>
        </Card>

        {/* Rev. 1620 — Barra de ações em lote */}
        {selectedIds.size > 0 && (
          <div className="sticky top-2 z-20 bg-blue-600 text-white rounded-lg shadow-lg px-4 py-2.5 flex items-center justify-between">
            <div className="flex items-center gap-3 text-sm">
              <CheckCircle className="w-4 h-4" />
              <span className="font-semibold">{selectedIds.size} título(s) selecionado(s)</span>
              <span className="text-blue-100">· Total {formatBRL(selectedTotal)}</span>
            </div>
            <div className="flex items-center gap-2">
              <Button size="sm" className="bg-white text-blue-700 hover:bg-blue-50 h-8 text-xs gap-1"
                onClick={() => setShowBulkPay(true)}>
                <Zap className="w-3.5 h-3.5" />Pagar selecionados
              </Button>
              <button onClick={() => setSelectedIds(new Set())}
                className="p-1.5 rounded hover:bg-blue-700 text-white" title="Limpar seleção">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Rev. 1629 — Banner explicativo do modo Projeção */}
        {naturezaFilter === "projecao" && (
          <div className="rounded-lg border border-violet-200 bg-violet-50 px-4 py-2.5 text-xs text-violet-800 flex items-start gap-2">
            <Info className="w-4 h-4 mt-0.5 flex-shrink-0 text-violet-600" />
            <div>
              <strong>Projeção de caixa</strong> — lançamentos gerados automaticamente pelo cronograma e PCP do Planejamento (sem fato gerador ainda).
              São <em>previsões</em> usadas para fluxo de caixa futuro, não dívidas pagáveis (não selecionáveis para baixa). À medida que viram OC/Contrato/NF, migram para <em>Efetivo</em>.
            </div>
          </div>
        )}
        {/* Rev. 1629 — Aviso persistente: há projeções ocultas no modo Efetivo */}
        {projecoesOcultas > 0 && filtered.length > 0 && (
          <div className="rounded-lg border border-violet-200 bg-violet-50/60 px-3 py-2 text-[11px] text-violet-700 flex items-center justify-between gap-3">
            <span>📊 {projecoesOcultas} lançamento(s) de Projeção ocultos neste mês.</span>
            <button onClick={() => setNaturezaFilter("projecao")} className="font-medium underline hover:text-violet-900">Ver Projeção</button>
          </div>
        )}

        {/* Tabela */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-2 px-5 pt-4">
            <CardTitle className="text-sm font-semibold text-gray-700 flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-orange-500" />
              {MESES[mesSel-1]} {ano} — {filtered.length} conta(s)
              {naturezaFilter !== "todos" && (
                <span className={`ml-2 text-[11px] font-medium px-2 py-0.5 rounded-full ${naturezaFilter === "efetivo" ? "bg-emerald-100 text-emerald-700" : "bg-violet-100 text-violet-700"}`}>
                  {naturezaFilter === "efetivo" ? "💰 Efetivo" : "📊 Projeção"}
                </span>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-8 text-center text-gray-500">Carregando...</div>
            ) : filtered.length === 0 ? (
              <div className="p-10 text-center">
                <Calendar className="w-10 h-10 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500 font-medium">Nenhuma conta em {MESES[mesSel-1]} {ano}</p>
                {(search || origemFilter !== "all" || statusFilter !== "all" || naturezaFilter !== "efetivo") && (
                  <button onClick={() => { setSearch(""); setOrigemFilter("all"); setStatusFilter("pendentes"); setNaturezaFilter("efetivo"); }}
                    className="mt-2 text-xs text-blue-600 hover:underline">Limpar filtros</button>
                )}
                {projecoesOcultas > 0 && (
                  <p className="mt-2 text-[11px] text-violet-600">
                    Há {projecoesOcultas} lançamento(s) de Projeção ocultos.
                    <button onClick={() => setNaturezaFilter("projecao")} className="ml-1 underline hover:text-violet-800">Ver Projeção</button>
                  </p>
                )}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 sticky top-0 z-10">
                    <tr>
                      <th className="px-2 py-2.5 text-center w-8">
                        <Checkbox checked={allVisibleSelected} onCheckedChange={toggleSelectAllVisible} aria-label="Selecionar todos" />
                      </th>
                      <th className="px-2 py-2.5 text-left text-[11px] font-semibold text-gray-600 uppercase tracking-wide whitespace-nowrap"><span className="inline-flex items-center gap-1"><Calendar className="w-3 h-3" />Data</span></th>
                      <th className="px-2 py-2.5 text-left text-[11px] font-semibold text-gray-600 uppercase tracking-wide whitespace-nowrap"><span className="inline-flex items-center gap-1"><Hash className="w-3 h-3" />Nº OC/OS</span></th>
                      <th className="px-2 py-2.5 text-left text-[11px] font-semibold text-gray-600 uppercase tracking-wide">Descrição</th>
                      <th className="px-2 py-2.5 text-left text-[11px] font-semibold text-gray-600 uppercase tracking-wide whitespace-nowrap"><span className="inline-flex items-center gap-1"><Tag className="w-3 h-3" />Categoria</span></th>
                      <th className="px-2 py-2.5 text-right text-[11px] font-semibold text-gray-600 uppercase tracking-wide whitespace-nowrap">Valor</th>
                      <th className="px-2 py-2.5 text-center text-[11px] font-semibold text-gray-600 uppercase tracking-wide whitespace-nowrap">Status</th>
                      <th className="px-2 py-2.5 text-right text-[11px] font-semibold text-gray-600 uppercase tracking-wide w-[140px] sticky right-0 bg-gray-50 shadow-[-4px_0_6px_-4px_rgba(0,0,0,0.08)]">Ações</th>
                    </tr>
                  </thead>
                  <tbody>
                    {grupos.map((g) => {
                      // Rev. 1625 — Dentro de cada bucket, monta linhas mistas: consolidadas + individuais
                      type Row =
                        | { kind: "single"; item: any }
                        | { kind: "group"; key: string; sub: string; label: string; origem: string; items: any[]; total: number; mesAno: string };
                      const rows: Row[] = [];
                      if (consolidateMode) {
                        const groupMap = new Map<string, { sub: string; label: string; origem: string; items: any[]; mesAno: string }>();
                        const singles: any[] = [];
                        for (const c of g.items) {
                          const sub = consolidateSubtype(c);
                          const venc = (c.dataVencimento ?? "").slice(0, 7);
                          if (sub && venc) {
                            // Rev. 1625b — agrupa por origemBase (não origemModulo) para consolidar folha_rh+folha_clt
                            const k = `${sub.origemBase}|${sub.sub}|${venc}`;
                            if (!groupMap.has(k)) groupMap.set(k, { sub: sub.sub, label: sub.label, origem: sub.origemBase, items: [], mesAno: venc });
                            groupMap.get(k)!.items.push(c);
                          } else {
                            singles.push(c);
                          }
                        }
                        // Promove grupos com < CONSOLIDATE_MIN itens de volta para singles
                        for (const [k, gp] of groupMap.entries()) {
                          if (gp.items.length < CONSOLIDATE_MIN) {
                            singles.push(...gp.items);
                            groupMap.delete(k);
                          }
                        }
                        // Mistura na ordem original (por bucket já vem ordenado)
                        // Para manter ordem cronológica, ordena tudo por menor data
                        const allRows: Row[] = [];
                        for (const [k, gp] of groupMap.entries()) {
                          const total = gp.items.reduce((s, x) => s + Number(x.valorPrevisto ?? 0), 0);
                          allRows.push({ kind: "group", key: k, sub: gp.sub, label: gp.label, origem: gp.origem, items: gp.items, total, mesAno: gp.mesAno });
                        }
                        for (const it of singles) allRows.push({ kind: "single", item: it });
                        allRows.sort((a, b) => {
                          const da = a.kind === "single"
                            ? (a.item.dataVencimento || "9999-12-31").slice(0, 10)
                            : a.items.map(x => (x.dataVencimento || "9999-12-31").slice(0, 10)).sort()[0];
                          const db = b.kind === "single"
                            ? (b.item.dataVencimento || "9999-12-31").slice(0, 10)
                            : b.items.map(x => (x.dataVencimento || "9999-12-31").slice(0, 10)).sort()[0];
                          return da.localeCompare(db);
                        });
                        rows.push(...allRows);
                      } else {
                        for (const c of g.items) rows.push({ kind: "single", item: c });
                      }
                      const totalRowsCount = rows.reduce((n, r) => n + (r.kind === "group" ? r.items.length : 1), 0);
                      return (
                      <Fragment key={g.label}>
                        {/* Cabeçalho de grupo */}
                        <tr className="bg-gradient-to-r from-slate-100 to-transparent border-y border-slate-200">
                          <td colSpan={8} className="px-3 py-1.5">
                            <div className="flex items-center justify-between">
                              <span className={`text-xs font-semibold uppercase tracking-wide ${
                                g.order === 0 ? "text-red-700" :
                                g.order === 1 ? "text-orange-700" :
                                g.order === 2 ? "text-amber-700" :
                                g.order === 9 ? "text-green-700" :
                                "text-slate-700"
                              }`}>
                                {g.order === 0 && <AlertTriangle className="w-3 h-3 inline mr-1" />}
                                {g.order === 1 && <Clock className="w-3 h-3 inline mr-1" />}
                                {g.order === 9 && <CheckCircle className="w-3 h-3 inline mr-1" />}
                                {g.label} <span className="text-slate-400 font-normal ml-1">· {totalRowsCount} {totalRowsCount === 1 ? "conta" : "contas"}{consolidateMode && rows.length !== totalRowsCount ? ` em ${rows.length} ${rows.length === 1 ? "linha" : "linhas"}` : ""}</span>
                              </span>
                              <span className="text-xs font-bold text-slate-700">{formatBRL(g.total)}</span>
                            </div>
                          </td>
                        </tr>
                        {rows.map((r) => {
                          // ─── LINHA CONSOLIDADA ───
                          if (r.kind === "group") {
                            const gp = r;
                            const ids = gp.items.map((x: any) => x.id as number);
                            const pendIds = gp.items.filter((x: any) => x.status !== "pago").map((x: any) => x.id as number);
                            const allSelected = pendIds.length > 0 && pendIds.every(id => selectedIds.has(id));
                            const someSelected = pendIds.some(id => selectedIds.has(id));
                            const isExpanded = expandedGroups.has(gp.key);
                            const pagosCount = gp.items.filter((x: any) => x.status === "pago").length;
                            const vencCount = gp.items.filter((x: any) => x.dataVencimento && x.dataVencimento.slice(0,10) < hojeStr && x.status !== "pago").length;
                            const minVenc = gp.items.map((x: any) => (x.dataVencimento || "").slice(0, 10)).filter(Boolean).sort()[0];
                            const Icon = ORIGEM_ICONS[gp.origem] ?? FileText;
                            const colorCls = ORIGEM_COLORS[gp.origem] ?? "bg-gray-50 text-gray-700 border-gray-200";
                            const mesLabel = gp.mesAno ? `${MESES[Number(gp.mesAno.slice(5,7))-1]}/${gp.mesAno.slice(0,4)}` : "";
                            const toggleGroupSelect = () => {
                              setSelectedIds(prev => {
                                const next = new Set(prev);
                                if (allSelected) pendIds.forEach(id => next.delete(id));
                                else pendIds.forEach(id => next.add(id));
                                return next;
                              });
                            };
                            return (
                              <Fragment key={gp.key}>
                                <tr
                                  onClick={() => toggleGroupExpand(gp.key)}
                                  className={`border-b border-slate-100 cursor-pointer hover:bg-indigo-50/40 ${someSelected ? "bg-blue-50/40" : "bg-indigo-50/20"}`}
                                >
                                  <td className="px-2 py-2.5 text-center" onClick={(e) => e.stopPropagation()}>
                                    {pendIds.length > 0 && (
                                      <Checkbox
                                        checked={allSelected}
                                        onCheckedChange={toggleGroupSelect}
                                        aria-label={`Selecionar todos os ${gp.label}`}
                                      />
                                    )}
                                  </td>
                                  <td className="px-3 py-2.5 whitespace-nowrap">
                                    <div className="flex flex-col leading-tight">
                                      <span className="text-sm font-semibold tabular-nums text-slate-800">{fmtDateBR(minVenc)}</span>
                                      <span className="text-[10px] text-slate-500">consolidado · {mesLabel}</span>
                                    </div>
                                  </td>
                                  <td className="px-3 py-2.5 whitespace-nowrap">
                                    <span className="text-xs font-mono font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 px-1.5 py-0.5 rounded inline-flex items-center gap-1">
                                      {isExpanded ? <ChevronLeft className="w-3 h-3 rotate-90" /> : <ChevronRight className="w-3 h-3" />}
                                      {gp.items.length}×
                                    </span>
                                  </td>
                                  <td className="px-2 py-2.5">
                                    <div className="flex items-center gap-1.5">
                                      <p className="text-sm font-bold text-slate-900">{gp.label}</p>
                                      <span className="text-xs text-slate-500">— {mesLabel}</span>
                                    </div>
                                    <p className="text-[11px] text-slate-500 mt-0.5">
                                      {gp.items.length} {unitLabelFor(gp.origem, gp.items.length)}
                                      {pagosCount > 0 && <span className="text-green-600"> · {pagosCount} pago(s)</span>}
                                      {vencCount > 0 && <span className="text-red-600"> · {vencCount} vencido(s)</span>}
                                    </p>
                                  </td>
                                  <td className="px-2 py-2.5">
                                    <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium border self-start ${colorCls}`}>
                                      <Icon className="w-2.5 h-2.5" />
                                      {ORIGEM_LABELS[gp.origem] ?? gp.origem}
                                    </span>
                                  </td>
                                  <td className="px-2 py-2.5 text-right whitespace-nowrap">
                                    <span className="text-sm font-bold tabular-nums text-slate-900">{formatBRL(gp.total)}</span>
                                  </td>
                                  <td className="px-2 py-2.5 text-center">
                                    {pagosCount === gp.items.length ? (
                                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-green-100 text-green-700 border border-green-200">
                                        <CheckCircle className="w-3 h-3" />Pago
                                      </span>
                                    ) : pagosCount > 0 ? (
                                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-amber-100 text-amber-700 border border-amber-200">
                                        Parcial {pagosCount}/{gp.items.length}
                                      </span>
                                    ) : vencCount > 0 ? (
                                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-red-100 text-red-700 border border-red-200">
                                        <AlertTriangle className="w-3 h-3" />Vencido
                                      </span>
                                    ) : (
                                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-orange-100 text-orange-700 border border-orange-200">
                                        <Clock className="w-3 h-3" />A Pagar
                                      </span>
                                    )}
                                  </td>
                                  <td className="px-2 py-2.5 text-right" onClick={(e) => e.stopPropagation()}>
                                    <div className="inline-flex items-center gap-1">
                                      <Button size="sm" variant="outline" className="h-7 w-7 p-0" title={isExpanded ? "Recolher" : "Expandir"}
                                        onClick={() => toggleGroupExpand(gp.key)}>
                                        <ChevronRight className={`w-4 h-4 transition-transform ${isExpanded ? "rotate-90" : ""}`} />
                                      </Button>
                                      {pendIds.length > 0 && (
                                        <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white h-7 px-2.5 text-xs"
                                          onClick={() => {
                                            setSelectedIds(new Set(pendIds));
                                            setShowBulkPay(true);
                                          }}>
                                          <CheckCircle className="w-3 h-3 mr-1" />Pagar lote
                                        </Button>
                                      )}
                                    </div>
                                  </td>
                                </tr>
                                {/* Filhas expandidas */}
                                {isExpanded && gp.items.map((c: any) => {
                                  const vencida = c.dataVencimento && c.dataVencimento.slice(0,10) < hojeStr && c.status !== "pago";
                                  const isSelected = selectedIds.has(c.id);
                                  const desc = describeEntry(c);
                                  return (
                                    <tr key={c.id}
                                      onClick={(e) => {
                                        const isInteractive = (e.target as HTMLElement).closest("button, [role=checkbox], input, a");
                                        if (isInteractive) return;
                                        setDetailEntryId(c.id);
                                      }}
                                      className={`hover:bg-blue-50/30 cursor-pointer border-b border-slate-100 ${isSelected ? "bg-blue-50/40" : ""}`}>
                                      <td className="px-2 py-2 text-center" onClick={(e) => e.stopPropagation()}>
                                        {c.status !== "pago" && !isProjecao(c) && (
                                          <Checkbox checked={isSelected} onCheckedChange={() => toggleSelect(c.id)} />
                                        )}
                                      </td>
                                      <td className="px-2 py-2 whitespace-nowrap pl-6">
                                        <div className="flex items-center gap-2">
                                          <span className="text-indigo-300 text-xs">└─</span>
                                          <span className={`text-xs tabular-nums ${vencida ? "text-red-700" : c.status === "pago" ? "text-green-700" : "text-slate-600"}`}>
                                            {fmtDateBR(c.dataVencimento)}
                                          </span>
                                        </div>
                                      </td>
                                      <td className="px-2 py-2 whitespace-nowrap">
                                        <span className="text-[11px] font-mono text-slate-500">#{c.id}</span>
                                      </td>
                                      <td className="px-2 py-2 max-w-[190px]">
                                        <p className="text-xs text-slate-700 truncate" title={desc}>{desc}</p>
                                      </td>
                                      <td className="px-2 py-2">
                                        <span className="text-[11px] text-slate-500">{categoriaFor(c)}</span>
                                      </td>
                                      <td className="px-2 py-2 text-right whitespace-nowrap">
                                        <span className={`text-xs font-semibold tabular-nums ${vencida ? "text-red-700" : c.status === "pago" ? "text-green-700" : "text-slate-700"}`}>
                                          {formatBRL(Number(c.valorPrevisto ?? 0))}
                                        </span>
                                      </td>
                                      <td className="px-2 py-2 text-center">
                                        {c.status === "pago" ? (
                                          <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-[10px] font-semibold bg-green-100 text-green-700 border border-green-200">
                                            <CheckCircle className="w-2.5 h-2.5" />Pago
                                          </span>
                                        ) : vencida ? (
                                          <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-[10px] font-semibold bg-red-100 text-red-700 border border-red-200">
                                            Vencido
                                          </span>
                                        ) : (
                                          <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-[10px] font-semibold bg-orange-100 text-orange-700 border border-orange-200">
                                            A Pagar
                                          </span>
                                        )}
                                      </td>
                                      <td className="px-3 py-2 text-right" onClick={(e) => e.stopPropagation()}>
                                        <Button size="sm" variant="outline" className="h-6 w-6 p-0"
                                          onClick={() => setDetailEntryId(c.id)}>
                                          <Eye className="w-3 h-3" />
                                        </Button>
                                      </td>
                                    </tr>
                                  );
                                })}
                              </Fragment>
                            );
                          }
                          // ─── LINHA INDIVIDUAL (caminho original) ───
                          const c = r.item;
                          const vencida = c.dataVencimento && c.dataVencimento.slice(0,10) < hojeStr && c.status !== "pago";
                          const Icon = ORIGEM_ICONS[c.origemModulo] ?? FileText;
                          const colorCls = ORIGEM_COLORS[c.origemModulo] ?? "bg-gray-50 text-gray-700 border-gray-200";
                          const oc = extractOcNumero(c);
                          const desc = describeEntry(c);
                          const cat = categoriaFor(c);
                          const isDup = duplicateKeys.has(dupKeyOf(c));
                          const isSelected = selectedIds.has(c.id);
                          const proj = isProjecao(c);
                          return (
                            <tr key={c.id}
                              onClick={(e) => {
                                // Não abrir detalhe quando o clique foi em checkbox/botão
                                const tag = (e.target as HTMLElement).tagName.toLowerCase();
                                const isInteractive = (e.target as HTMLElement).closest("button, [role=checkbox], input, a");
                                if (isInteractive || tag === "input") return;
                                setDetailEntryId(c.id);
                              }}
                              className={`hover:bg-blue-50/30 cursor-pointer border-b border-slate-100 ${isSelected ? "bg-blue-50/40" : vencida ? "bg-red-50/30" : proj ? "bg-violet-50/20 border-l-2 border-l-violet-300" : ""}`}>
                              {/* Checkbox */}
                              <td className="px-2 py-2.5 text-center" onClick={(e) => e.stopPropagation()}>
                                {c.status !== "pago" && !proj && (
                                  <Checkbox checked={isSelected} onCheckedChange={() => toggleSelect(c.id)} aria-label={`Selecionar ${oc}`} />
                                )}
                              </td>
                              {/* Data */}
                              <td className="px-3 py-2.5 whitespace-nowrap">
                                {c.dataVencimento ? (
                                  <div className="flex flex-col leading-tight">
                                    <span className={`text-sm font-semibold tabular-nums ${vencida ? "text-red-700" : c.status === "pago" ? "text-green-700" : "text-slate-800"}`}>
                                      {fmtDateBR(c.dataVencimento)}
                                    </span>
                                    {vencida && <span className="text-[10px] text-red-500 font-medium">{c.diasAtraso}d atraso</span>}
                                    {!vencida && c.status === "pago" && c.dataPagamento && (
                                      <span className="text-[10px] text-green-600">pago {fmtDateBR(c.dataPagamento)}</span>
                                    )}
                                    {!vencida && c.status !== "pago" && c.dataVencimento.slice(0,10) === hojeStr && (
                                      <span className="text-[10px] text-orange-600 font-medium">vence hoje</span>
                                    )}
                                  </div>
                                ) : <span className="text-xs text-gray-400">Sem data</span>}
                              </td>
                              {/* Nº OC/OS */}
                              <td className="px-3 py-2.5 whitespace-nowrap">
                                <span className="text-xs font-mono font-semibold text-slate-700 bg-slate-50 border border-slate-200 px-1.5 py-0.5 rounded">
                                  {oc}
                                </span>
                              </td>
                              {/* Descrição */}
                              <td className="px-2 py-2.5 max-w-[190px]">
                                <div className="flex items-center gap-1.5">
                                  <p className="text-sm font-medium text-slate-800 truncate" title={desc}>{desc}</p>
                                  {isDup && (
                                    <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[9px] font-bold bg-yellow-100 text-yellow-800 border border-yellow-300 whitespace-nowrap"
                                      title="Possível duplicidade: mesmo descrição, valor e vencimento já consta no ano">
                                      <Copy className="w-2.5 h-2.5" />DUP
                                    </span>
                                  )}
                                </div>
                                {c.fornecedorNome && (
                                  <p className="text-[11px] text-indigo-600 truncate font-medium" title={c.fornecedorNome}>🏢 {c.fornecedorNome}</p>
                                )}
                                {c.obraNome && (
                                  <p className="text-[11px] text-slate-400 truncate" title={c.obraNome}>📍 {c.obraNome}</p>
                                )}
                              </td>
                              {/* Categoria — Rev. 2228: removido pill ORIGEM redundante
                                  (texto da categoria já carrega o nome). Ícone inline + texto
                                  poupam ~120px de largura → tabela cabe sem scroll. */}
                              <td className="px-2 py-2.5">
                                <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[11px] font-medium border max-w-[110px] ${colorCls}`} title={cat}>
                                  <Icon className="w-3 h-3 shrink-0" />
                                  <span className="truncate">{cat}</span>
                                </span>
                              </td>
                              {/* Valor */}
                              <td className="px-2 py-2.5 text-right whitespace-nowrap">
                                <span className={`text-sm font-bold tabular-nums ${vencida ? "text-red-700" : c.status === "pago" ? "text-green-700" : "text-slate-800"}`}>
                                  {formatBRL(Number(c.valorPrevisto ?? 0))}
                                </span>
                                {c.status === "pago" && c.valorRealizado && Number(c.valorRealizado) !== Number(c.valorPrevisto) && (
                                  <div className="text-[10px] text-green-600">pago: {formatBRL(Number(c.valorRealizado))}</div>
                                )}
                              </td>
                              {/* Status */}
                              <td className="px-2 py-2.5 text-center">
                                {c.status === "pago" ? (
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-green-100 text-green-700 border border-green-200">
                                    <CheckCircle className="w-3 h-3" />Pago
                                  </span>
                                ) : vencida ? (
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-red-100 text-red-700 border border-red-200">
                                    <AlertTriangle className="w-3 h-3" />Vencido
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-orange-100 text-orange-700 border border-orange-200">
                                    <Clock className="w-3 h-3" />A Pagar
                                  </span>
                                )}
                              </td>
                              {/* Ações — sticky-right (Rev. 2227) + Estornar/Excluir (Rev. 2228) */}
                              <td className="px-2 py-2.5 text-right sticky right-0 bg-white group-hover:bg-slate-50 shadow-[-4px_0_6px_-4px_rgba(0,0,0,0.08)]" onClick={(e) => e.stopPropagation()}>
                                <div className="inline-flex items-center gap-0.5">
                                  <Button size="sm" variant="outline" className="h-7 w-7 p-0" title="Visualizar detalhes"
                                    onClick={() => setDetailEntryId(c.id)}>
                                    <Eye className="w-3.5 h-3.5" />
                                  </Button>
                                  {!proj && (
                                    <Button size="sm" variant="outline" className="h-7 w-7 p-0 border-blue-200 text-blue-600 hover:bg-blue-50 hover:text-blue-700"
                                      title={c.origemModulo && c.origemModulo !== "recorrente" ? "Vinculado a outro módulo — edite na origem" : c.status === "pago" ? "Estorne antes de editar" : "Editar lançamento"}
                                      onClick={() => openEdit(c)}>
                                      <Pencil className="w-3.5 h-3.5" />
                                    </Button>
                                  )}
                                  {!proj && (
                                    <Button size="sm" variant="outline" className={`h-7 w-7 p-0 ${c.anexoUrl ? "border-emerald-300 text-emerald-700 hover:bg-emerald-50" : "border-slate-200 text-slate-600 hover:bg-slate-50"}`}
                                      title={c.anexoUrl ? `Anexo: ${c.anexoNome ?? "documento"} (clique p/ trocar)` : "Anexar documento (boleto/NF/foto)"}
                                      onClick={() => openAnexo(c)}>
                                      <Paperclip className="w-3.5 h-3.5" />
                                    </Button>
                                  )}
                                  {c.status === "pago" ? (
                                    <Button size="sm" variant="outline" className="h-7 w-7 p-0 border-amber-300 text-amber-700 hover:bg-amber-50"
                                      title="Estornar pagamento (baixa errada)"
                                      onClick={() => { setShowEstorno(c); setMotivoEstorno(""); }}>
                                      <RotateCcw className="w-3.5 h-3.5" />
                                    </Button>
                                  ) : (
                                    <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white h-7 px-1.5 text-xs"
                                      onClick={() => setShowPay(c)}>
                                      <CheckCircle className="w-3 h-3 mr-0.5" />Pagar
                                    </Button>
                                  )}
                                  {!proj && (
                                    <Button size="sm" variant="outline" className="h-7 w-7 p-0 border-red-200 text-red-600 hover:bg-red-50 hover:text-red-700"
                                      title={c.status === "pago" ? "Estorne antes de excluir" : "Excluir lançamento (duplicidade)"}
                                      disabled={c.status === "pago"}
                                      onClick={() => { setShowDelete(c); setMotivoDelete(""); }}>
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </Button>
                                  )}
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </Fragment>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Resumo anual */}
        {allContas && allContas.length > 0 && (
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-2 px-5 pt-4">
              <CardTitle className="text-sm font-semibold text-gray-700">Resumo Anual {ano}</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600">Mês</th>
                      <th className="px-4 py-2 text-right text-xs font-semibold text-gray-600">Total</th>
                      <th className="px-4 py-2 text-right text-xs font-semibold text-gray-600">Pago</th>
                      <th className="px-4 py-2 text-right text-xs font-semibold text-gray-600">A Pagar</th>
                      <th className="px-4 py-2 text-right text-xs font-semibold text-gray-600">Vencido</th>
                      <th className="px-4 py-2 text-center text-xs font-semibold text-gray-600">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {MESES.map((m, i) => {
                      const num = i + 1;
                      const entries = allContas.filter((c: any) => getMesFromDate(c.dataVencimento) === num);
                      if (entries.length === 0) return null;
                      const totM = entries.reduce((s: number, c: any) => s + Number(c.valorPrevisto ?? 0), 0);
                      const pgM = entries.filter((c: any) => c.status === "pago").reduce((s: number, c: any) => s + Number(c.valorRealizado ?? c.valorPrevisto ?? 0), 0);
                      const pdM = entries.filter((c: any) => c.status !== "pago").reduce((s: number, c: any) => s + Number(c.valorPrevisto ?? 0), 0);
                      const vcM = entries.filter((c: any) => c.dataVencimento && c.dataVencimento < hojeStr && c.status !== "pago").reduce((s: number, c: any) => s + Number(c.valorPrevisto ?? 0), 0);
                      const st = mesesStatus[num];
                      return (
                        <tr key={m}
                          className={`hover:bg-gray-50 cursor-pointer ${mesSel === num ? "bg-blue-50/40" : ""}`}
                          onClick={() => setMesSel(num)}>
                          <td className="px-4 py-2.5 font-medium text-gray-700">{m}/{ano}</td>
                          <td className="px-4 py-2.5 text-right font-semibold text-gray-800">{formatBRL(totM)}</td>
                          <td className="px-4 py-2.5 text-right text-green-700">{formatBRL(pgM)}</td>
                          <td className="px-4 py-2.5 text-right text-orange-600">{formatBRL(pdM)}</td>
                          <td className="px-4 py-2.5 text-right text-red-600">{vcM > 0 ? formatBRL(vcM) : "—"}</td>
                          <td className="px-4 py-2.5 text-center">
                            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${
                              st === "consolidado" ? "bg-green-100 text-green-700" :
                              st === "lancamento" ? "bg-blue-100 text-blue-700" :
                              "bg-gray-100 text-gray-500"
                            }`}>
                              <span className={`w-1.5 h-1.5 rounded-full ${
                                st === "consolidado" ? "bg-green-500" :
                                st === "lancamento" ? "bg-blue-500" : "bg-gray-400"
                              }`} />
                              {st === "consolidado" ? "Consolidado" : st === "lancamento" ? "Lançamento" : "Sem dados"}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Rev. 1621 — Modal de DETALHE do título (drill-down completo p/ validação final) */}
        <Dialog open={!!detailEntryId} onOpenChange={(o) => !o && setDetailEntryId(null)}>
          <DialogContent
            resizable={false}
            className="!max-w-none w-[100vw] h-[100dvh] lg:w-[96vw] lg:h-[94vh] lg:max-w-[1600px] lg:rounded-lg rounded-none p-3 sm:p-5 overflow-y-auto flex flex-col"
          >
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-lg">
                <Info className="w-5 h-5 text-blue-600" />
                Detalhe do Título
                {detailQuery.data?.entry && (
                  <span className="ml-auto text-xs font-normal text-slate-500 tabular-nums">
                    Lançamento #{detailQuery.data.entry.id}
                  </span>
                )}
              </DialogTitle>
            </DialogHeader>

            {detailQuery.isLoading ? (
              <div className="py-12 text-center text-slate-500 text-sm">Carregando detalhes...</div>
            ) : detailQuery.error ? (
              <div className="py-6 px-4 space-y-2">
                <div className="text-red-700 font-semibold text-sm">Erro ao carregar detalhe:</div>
                <div className="text-red-600 text-sm font-mono break-all">{(detailQuery.error as any)?.name ? `[${(detailQuery.error as any).name}] ` : ""}{(detailQuery.error as any)?.message ?? String(detailQuery.error)}</div>
                {(detailQuery.error as any)?.data?.code && (
                  <div className="text-xs text-slate-500">Código: {(detailQuery.error as any).data.code}</div>
                )}
                <div className="text-xs text-slate-500 pt-2">ID: {detailEntryId} · Empresa: {companyId}</div>
              </div>
            ) : detailQuery.data ? (() => {
              const d = detailQuery.data;
              const e = d.entry;
              const vencida = e.dataVencimento && e.dataVencimento.slice(0,10) < hojeStr && e.status !== "pago";
              return (
                <div className="space-y-4">
                  {/* Cabeçalho de status */}
                  <div className={`rounded-lg border-2 p-4 ${
                    e.status === "pago" ? "border-green-300 bg-green-50" :
                    vencida ? "border-red-300 bg-red-50" :
                    "border-orange-300 bg-orange-50"
                  }`}>
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-semibold uppercase tracking-wide mb-1 text-slate-600">
                          {ORIGEM_LABELS[e.origemModulo] ?? e.origemModulo ?? "Lançamento Manual"}
                          {d.ordem?.numeroOc && <span className="ml-2 font-mono text-slate-700">· {formatNumeroOcDisplay(d.ordem.numeroOc)}</span>}
                        </div>
                        <h3 className="text-base font-bold text-slate-900 leading-tight">
                          {e.descricao || e.origemDescricao || e.contaNome || "—"}
                        </h3>
                        {/* Rev. 2396 — Nome do fornecedor (quando preenchido no lançamento) */}
                        {e.fornecedorNome && (
                          <p className="text-xs text-slate-700 font-medium mt-1">🏢 {e.fornecedorNome}</p>
                        )}
                        {e.obraNome && (
                          <p className="text-xs text-slate-600 mt-1">📍 {e.obraNome}</p>
                        )}
                      </div>
                      <div className="text-right flex-shrink-0">
                        <div className="text-2xl font-bold tabular-nums text-slate-900">{formatBRL(Number(e.valorPrevisto))}</div>
                        <div className={`text-xs font-semibold mt-1 ${
                          e.status === "pago" ? "text-green-700" : vencida ? "text-red-700" : "text-orange-700"
                        }`}>
                          {e.status === "pago" ? `✓ Pago em ${fmtDateBR(e.dataPagamento)}` :
                            vencida ? `⚠ Vencido há ${e.diasAtraso} dia(s)` :
                            `Vence em ${fmtDateBR(e.dataVencimento)}`}
                        </div>
                      </div>
                    </div>
                  </div>

                  <Tabs defaultValue="geral" className="w-full">
                    <TabsList className="grid w-full grid-cols-4 h-auto">
                      <TabsTrigger value="geral" className="text-[11px] sm:text-xs px-1 sm:px-3 py-1.5 truncate">
                        <Info className="w-3 h-3 mr-1 flex-shrink-0" /><span className="truncate">Geral</span>
                      </TabsTrigger>
                      <TabsTrigger value="origem" className="text-[11px] sm:text-xs px-1 sm:px-3 py-1.5 truncate" disabled={!d.ordem && !d.fornecedor && !d.origemDetalhes}>
                        <Building2 className="w-3 h-3 mr-1 flex-shrink-0" />
                        <span className="truncate">{(d.origemDetalhes?.funcionarios || d.origemDetalhes?.pjs) ? "Memorial" : "Origem"}</span>
                      </TabsTrigger>
                      <TabsTrigger value="parcelas" className="text-[11px] sm:text-xs px-1 sm:px-3 py-1.5 truncate">
                        <Hash className="w-3 h-3 mr-1 flex-shrink-0" />
                        <span className="truncate">Parcelas{d.parcelas?.length > 1 ? ` (${d.parcelas.length})` : ""}</span>
                      </TabsTrigger>
                      <TabsTrigger value="historico" className="text-[11px] sm:text-xs px-1 sm:px-3 py-1.5 truncate">
                        <History className="w-3 h-3 mr-1 flex-shrink-0" /><span className="truncate">Histórico</span>
                      </TabsTrigger>
                    </TabsList>

                    {/* GERAL */}
                    <TabsContent value="geral" className="mt-4 space-y-3">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        <KV label="Tipo">{e.tipo ?? "—"}</KV>
                        <KV label="Natureza">{e.natureza ?? "—"}</KV>
                        <KV label="Conta Contábil">{e.contaNome ?? "—"}</KV>
                        <KV label="Competência">{fmtDateBR(e.dataCompetencia)}</KV>
                        <KV label="Vencimento" highlight={vencida}>{fmtDateBR(e.dataVencimento)}</KV>
                        <KV label="Pagamento">{e.dataPagamento ? fmtDateBR(e.dataPagamento) : "—"}</KV>
                        <KV label="Valor Previsto">{formatBRL(Number(e.valorPrevisto))}</KV>
                        <KV label="Valor Realizado">{e.valorRealizado != null ? formatBRL(Number(e.valorRealizado)) : "—"}</KV>
                        <KV label="Forma">{e.formaPagamento ?? "—"}</KV>
                        {e.parcelaNumero && (
                          <KV label="Parcela">{e.parcelaNumero}/{e.parcelaTotal}</KV>
                        )}
                        {e.codigoBarras && <KV label="Cód. de Barras"><span className="font-mono text-[11px]">{e.codigoBarras}</span></KV>}
                        {e.chequeNumero && <KV label="Cheque">{e.chequeNumero} ({e.chequeBanco})</KV>}
                        <KV label="Fornecedor / Cliente" highlight={!!e.fornecedorNome}>{e.fornecedorNome ?? "—"}</KV>
                        <KV label="Conciliação">{e.conciliado ? `✓ ${fmtDateBR(e.dataConciliacao)}` : "Não conciliado"}</KV>
                        <KV label="Criado por">{e.criadoPorNome ?? "—"}</KV>
                        {e.aprovadoPorNome && <KV label="Aprovado por">{e.aprovadoPorNome}</KV>}
                        {e.editadoPorNome && (
                          <KV label="Editado por" highlight>
                            {e.editadoPorNome}{e.editadoEm ? ` · ${fmtDateBR(e.editadoEm)}` : ""}
                          </KV>
                        )}
                      </div>

                      {d.bancoEmpresa && (
                        <div className="rounded-lg border border-slate-200 p-3 bg-slate-50">
                          <p className="text-[11px] font-semibold text-slate-600 uppercase tracking-wide mb-1">Conta de Saída (Empresa)</p>
                          <p className="text-sm font-medium text-slate-800">
                            {d.bancoEmpresa.banco} · Ag. {d.bancoEmpresa.agencia} · CC {d.bancoEmpresa.conta}
                            {d.bancoEmpresa.apelido && <span className="text-slate-500 ml-2">({d.bancoEmpresa.apelido})</span>}
                          </p>
                        </div>
                      )}

                      {e.observacoes && (
                        <div className="rounded-lg border border-amber-200 bg-amber-50 p-3">
                          <p className="text-[11px] font-semibold text-amber-700 uppercase tracking-wide mb-1">Observações</p>
                          <p className="text-sm text-amber-900 whitespace-pre-wrap">{e.observacoes}</p>
                        </div>
                      )}

                      {e.motivoCancelamento && (
                        <div className="rounded-lg border border-red-200 bg-red-50 p-3">
                          <p className="text-[11px] font-semibold text-red-700 uppercase tracking-wide mb-1">Motivo do Cancelamento</p>
                          <p className="text-sm text-red-900">{e.motivoCancelamento}</p>
                        </div>
                      )}

                      {e.comprovanteUrl && (
                        <a href={e.comprovanteUrl} target="_blank" rel="noopener noreferrer"
                          className="inline-flex items-center gap-2 text-sm text-blue-700 hover:underline">
                          <Paperclip className="w-4 h-4" />Ver comprovante de pagamento
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      )}

                      {e.anexoUrl && (
                        <a href={e.anexoUrl} target="_blank" rel="noopener noreferrer"
                          className="flex items-center gap-2 text-sm text-emerald-700 hover:underline">
                          <Paperclip className="w-4 h-4" />Ver documento anexado{e.anexoNome ? ` — ${e.anexoNome}` : ""}
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      )}
                    </TabsContent>

                    {/* ORIGEM */}
                    <TabsContent value="origem" className="mt-4 space-y-4">
                      {d.ordem && (
                        <div>
                          <h4 className="text-sm font-semibold text-slate-700 mb-2 flex items-center gap-1">
                            <ShoppingCart className="w-4 h-4 text-blue-600" />Ordem de Compra {formatNumeroOcDisplay(d.ordem.numeroOc)}
                          </h4>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                            <KV label="Status OC">{d.ordem.status} · {d.ordem.aprovacaoStatus}</KV>
                            <KV label="Aprovador">{d.ordem.aprovadorNome ?? "—"}</KV>
                            <KV label="Aprovado em">{d.ordem.aprovadoEm ? fmtDateBR(d.ordem.aprovadoEm.slice(0,10)) : "—"}</KV>
                            <KV label="NF">{d.ordem.numeroNf ?? "—"}</KV>
                            <KV label="Cond. Pagto">{d.ordem.condicaoPagamento ?? "—"}</KV>
                            <KV label="Parcelas">{d.ordem.numeroParcelas ?? 1}</KV>
                            <KV label="Subtotal">{formatBRL(Number(d.ordem.subtotal ?? 0))}</KV>
                            <KV label={`Frete (${d.ordem.freteTipo ?? "—"})`}>{formatBRL(Number(d.ordem.frete ?? 0))}</KV>
                            <KV label="Outras Desp.">{formatBRL(Number(d.ordem.outrasDespesas ?? 0))}</KV>
                            <KV label="Impostos">{formatBRL(Number(d.ordem.impostos ?? 0))}</KV>
                            <KV label="Desconto">{formatBRL(Number(d.ordem.desconto ?? 0))}</KV>
                            <KV label="TOTAL OC" highlight>{formatBRL(Number(d.ordem.total ?? 0))}</KV>
                          </div>
                          {d.ordem.observacoes && (
                            <div className="mt-2 text-xs text-slate-600 italic">{d.ordem.observacoes}</div>
                          )}
                          <div className="flex gap-2 mt-3">
                            {d.ordem.pdfUrl && (
                              <a href={d.ordem.pdfUrl} target="_blank" rel="noopener noreferrer"
                                className="inline-flex items-center gap-1 text-xs text-blue-700 hover:underline border border-blue-200 px-2 py-1 rounded bg-blue-50">
                                <FileText className="w-3 h-3" />PDF da OC<ExternalLink className="w-3 h-3" />
                              </a>
                            )}
                            {Array.isArray(d.ordem.anexos) && d.ordem.anexos.length > 0 && d.ordem.anexos.map((a: any, i: number) => (
                              <a key={i} href={typeof a === "string" ? a : a.url} target="_blank" rel="noopener noreferrer"
                                className="inline-flex items-center gap-1 text-xs text-blue-700 hover:underline border border-slate-200 px-2 py-1 rounded">
                                <Paperclip className="w-3 h-3" />{typeof a === "string" ? `Anexo ${i+1}` : (a.nome ?? a.name ?? `Anexo ${i+1}`)}
                              </a>
                            ))}
                          </div>
                        </div>
                      )}

                      {d.fornecedor && (
                        <div>
                          <h4 className="text-sm font-semibold text-slate-700 mb-2 flex items-center gap-1">
                            <Building2 className="w-4 h-4 text-indigo-600" />Fornecedor
                          </h4>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                            <KV label="Razão Social">{d.fornecedor.razaoSocial}</KV>
                            <KV label="Nome Fantasia">{d.fornecedor.nomeFantasia ?? "—"}</KV>
                            <KV label="CNPJ"><span className="font-mono">{d.fornecedor.cnpj ?? "—"}</span></KV>
                            <KV label="Cidade/UF">{[d.fornecedor.cidade, d.fornecedor.estado].filter(Boolean).join("/") || "—"}</KV>
                            <KV label="Telefone">{d.fornecedor.telefone ?? "—"}</KV>
                            <KV label="E-mail">{d.fornecedor.email ?? "—"}</KV>
                            <KV label="Contato">{d.fornecedor.contatoNome ?? "—"}</KV>
                            <KV label="Banco">{d.fornecedor.banco ?? "—"}</KV>
                            <KV label="Ag./Conta">{[d.fornecedor.agencia, d.fornecedor.conta].filter(Boolean).join(" / ") || "—"}</KV>
                            {d.fornecedor.pix && <KV label="PIX" highlight><span className="font-mono text-[11px]">{d.fornecedor.pix}</span></KV>}
                          </div>
                        </div>
                      )}

                      {/* Rev. 1628 — Origem genérica (cronograma, folha, pj, frota, parceiro, beneficio, almox, medição, seguro) */}
                      {!d.ordem && !d.fornecedor && d.origemDetalhes && (
                        <div>
                          <h4 className="text-sm font-semibold text-slate-700 mb-2 flex items-center gap-1">
                            <Building2 className="w-4 h-4 text-violet-600" />{d.origemDetalhes.titulo}
                          </h4>
                          {d.origemDetalhes.subtitulo && (
                            <p className="text-xs text-slate-600 mb-3">{d.origemDetalhes.subtitulo}</p>
                          )}
                          {d.origemDetalhes.formula && (
                            <div className="rounded-lg border border-violet-200 bg-violet-50 p-3 mb-3">
                              <p className="text-[11px] font-semibold text-violet-700 uppercase tracking-wide mb-1">Fórmula de cálculo</p>
                              <p className="text-xs text-violet-900">{d.origemDetalhes.formula}</p>
                            </div>
                          )}
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                            {d.origemDetalhes.campos.map((c: any, i: number) => (
                              <KV key={i} label={c.label}>
                                {c.value == null || c.value === "" ? "—" :
                                 c.kind === "date" ? fmtDateBR(String(c.value)) :
                                 String(c.value)}
                              </KV>
                            ))}
                          </div>

                          {/* Rev. 1634 — Memorial Funcionários (Folha CLT / Encargos / VR / VA / 13º) */}
                          {Array.isArray(d.origemDetalhes.funcionarios) && d.origemDetalhes.funcionarios.length > 0 && (
                            <div className="mt-4">
                              <h4 className="text-sm font-semibold text-slate-700 mb-2 flex items-center gap-1">
                                <Hash className="w-4 h-4 text-emerald-600" />
                                Funcionários considerados ({d.origemDetalhes.funcionarios.length})
                              </h4>
                              <div className="border border-slate-200 rounded-lg overflow-auto max-h-[60vh]">
                                <table className="w-full text-xs min-w-[820px]">
                                  <thead className="bg-slate-100 sticky top-0">
                                    <tr>
                                      <th className="px-2 py-1.5 text-left font-semibold text-slate-600">#</th>
                                      <th className="px-2 py-1.5 text-left font-semibold text-slate-600">Código</th>
                                      <th className="px-2 py-1.5 text-left font-semibold text-slate-600">Funcionário / Função</th>
                                      <th className="px-2 py-1.5 text-left font-semibold text-slate-600">Obra</th>
                                      <th className="px-2 py-1.5 text-center font-semibold text-slate-600">Tipo</th>
                                      <th className="px-2 py-1.5 text-center font-semibold text-slate-600">Situação</th>
                                      <th className="px-2 py-1.5 text-right font-semibold text-slate-600">Sal. Bruto</th>
                                      <th className="px-2 py-1.5 text-right font-semibold text-slate-600">% Folha</th>
                                      <th className="px-2 py-1.5 text-right font-semibold text-slate-600">Parcela</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {d.origemDetalhes.funcionarios.map((f: any, i: number) => {
                                      const st = String(f.status || "").trim();
                                      const stMap: Record<string, { cls: string; label: string }> = {
                                        Ativo:    { cls: "bg-green-100 text-green-700",   label: "Ativo" },
                                        Ferias:   { cls: "bg-blue-100 text-blue-700",     label: "Férias (custo da empresa)" },
                                        Aviso:    { cls: "bg-amber-100 text-amber-700",   label: "Aviso prévio" },
                                        Afastado: { cls: "bg-rose-100 text-rose-700",     label: "Afastado >15d (INSS)" },
                                        Licenca:  { cls: "bg-rose-100 text-rose-700",     label: "Licença (INSS)" },
                                        Recluso:  { cls: "bg-zinc-200 text-zinc-700",     label: "Recluso (auxílio-reclusão)" },
                                      };
                                      const sd = stMap[st] || { cls: "bg-slate-100 text-slate-600", label: st || "—" };
                                      return (
                                        <tr key={f.id} className="border-t border-slate-100 hover:bg-slate-50 align-top">
                                          <td className="px-2 py-1 text-slate-400 tabular-nums">{i + 1}</td>
                                          <td className="px-2 py-1 font-mono text-[10px] text-slate-700">{f.codigo || f.matricula || "—"}</td>
                                          <td className="px-2 py-1">
                                            <div className="font-medium text-slate-800 leading-tight">{f.nome}</div>
                                            <div className="text-[10px] text-slate-500 leading-tight">{f.cargo && f.cargo !== "—" ? f.cargo : "Função não cadastrada"}</div>
                                          </td>
                                          <td className="px-2 py-1 text-slate-600 text-[10px]">{f.obraAtual}</td>
                                          <td className="px-2 py-1 text-center text-[10px] uppercase text-slate-500">{f.tipoRemuneracao}</td>
                                          <td className="px-2 py-1 text-center">
                                            <span className={`inline-block px-1.5 py-0.5 rounded-full text-[10px] font-semibold whitespace-nowrap ${sd.cls}`}>{sd.label}</span>
                                          </td>
                                          <td className="px-2 py-1 text-right tabular-nums">{formatBRL(Number(f.salarioBruto))}</td>
                                          <td className="px-2 py-1 text-right tabular-nums text-slate-500">{Number(f.percentual).toFixed(2)}%</td>
                                          <td className="px-2 py-1 text-right tabular-nums font-semibold text-emerald-700">{formatBRL(Number(f.parcelaLancamento))}</td>
                                        </tr>
                                      );
                                    })}
                                  </tbody>
                                  <tfoot className="bg-slate-100 sticky bottom-0">
                                    <tr className="font-bold text-slate-700">
                                      <td colSpan={6} className="px-2 py-1.5 text-right">TOTAL</td>
                                      <td className="px-2 py-1.5 text-right tabular-nums">{formatBRL(d.origemDetalhes.funcionarios.reduce((s: number, f: any) => s + Number(f.salarioBruto), 0))}</td>
                                      <td className="px-2 py-1.5 text-right tabular-nums">100%</td>
                                      <td className="px-2 py-1.5 text-right tabular-nums text-emerald-700">{formatBRL(d.origemDetalhes.funcionarios.reduce((s: number, f: any) => s + Number(f.parcelaLancamento), 0))}</td>
                                    </tr>
                                  </tfoot>
                                </table>
                              </div>
                            </div>
                          )}

                          {/* Rev. 1634 — Memorial PJ (lista de prestadores ativos com destaque) */}
                          {Array.isArray(d.origemDetalhes.pjs) && d.origemDetalhes.pjs.length > 0 && (
                            <div className="mt-4">
                              <h4 className="text-sm font-semibold text-slate-700 mb-2 flex items-center gap-1">
                                <Building2 className="w-4 h-4 text-indigo-600" />
                                Prestadores PJ ativos ({d.origemDetalhes.pjs.length})
                              </h4>
                              <div className="border border-slate-200 rounded-lg overflow-hidden max-h-72 overflow-y-auto">
                                <table className="w-full text-xs">
                                  <thead className="bg-slate-100 sticky top-0">
                                    <tr>
                                      <th className="px-2 py-1.5 text-left font-semibold text-slate-600">Razão Social</th>
                                      <th className="px-2 py-1.5 text-left font-semibold text-slate-600">CNPJ</th>
                                      <th className="px-2 py-1.5 text-center font-semibold text-slate-600">Status</th>
                                      <th className="px-2 py-1.5 text-right font-semibold text-slate-600">Valor Mensal</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {d.origemDetalhes.pjs.map((p: any) => (
                                      <tr key={p.id} className={`border-t border-slate-100 ${p.destacado ? "bg-indigo-50 font-semibold" : ""}`}>
                                        <td className="px-2 py-1">{p.nome} {p.destacado && <span className="text-indigo-600 ml-1">←</span>}</td>
                                        <td className="px-2 py-1 font-mono text-[10px]">{p.cnpj}</td>
                                        <td className="px-2 py-1 text-center text-[10px] uppercase text-slate-500">{p.status}</td>
                                        <td className="px-2 py-1 text-right tabular-nums">{formatBRL(Number(p.valor))}</td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            </div>
                          )}
                        </div>
                      )}

                      {d.itens && d.itens.length > 0 && (
                        <div>
                          <h4 className="text-sm font-semibold text-slate-700 mb-2 flex items-center gap-1">
                            <Package className="w-4 h-4 text-amber-600" />Itens da OC ({d.itens.length})
                          </h4>
                          <div className="border border-slate-200 rounded-lg overflow-hidden max-h-72 overflow-y-auto">
                            <table className="w-full text-xs">
                              <thead className="bg-slate-100 sticky top-0">
                                <tr>
                                  <th className="px-2 py-1.5 text-left font-semibold text-slate-600">Cód.</th>
                                  <th className="px-2 py-1.5 text-left font-semibold text-slate-600">Descrição</th>
                                  <th className="px-2 py-1.5 text-center font-semibold text-slate-600">Un.</th>
                                  <th className="px-2 py-1.5 text-right font-semibold text-slate-600">Qtd</th>
                                  <th className="px-2 py-1.5 text-right font-semibold text-slate-600">Entr.</th>
                                  <th className="px-2 py-1.5 text-right font-semibold text-slate-600">Preço</th>
                                  <th className="px-2 py-1.5 text-right font-semibold text-slate-600">Total</th>
                                </tr>
                              </thead>
                              <tbody>
                                {d.itens.map((it: any) => (
                                  <tr key={it.id} className="border-t border-slate-100">
                                    <td className="px-2 py-1 font-mono text-[10px]">{it.insumoCodigo ?? "—"}</td>
                                    <td className="px-2 py-1">{it.descricao}</td>
                                    <td className="px-2 py-1 text-center">{it.unidade ?? "—"}</td>
                                    <td className="px-2 py-1 text-right tabular-nums">{Number(it.quantidade).toLocaleString("pt-BR", {maximumFractionDigits: 3})}</td>
                                    <td className="px-2 py-1 text-right tabular-nums text-slate-500">{Number(it.quantidadeEntregue ?? 0).toLocaleString("pt-BR", {maximumFractionDigits: 3})}</td>
                                    <td className="px-2 py-1 text-right tabular-nums">{formatBRL(Number(it.precoUnitario ?? 0))}</td>
                                    <td className="px-2 py-1 text-right tabular-nums font-semibold">{formatBRL(Number(it.total ?? 0))}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      )}
                    </TabsContent>

                    {/* PARCELAS */}
                    <TabsContent value="parcelas" className="mt-4">
                      <div className="border border-slate-200 rounded-lg overflow-hidden">
                        <table className="w-full text-xs">
                          <thead className="bg-slate-100">
                            <tr>
                              <th className="px-2 py-1.5 text-left font-semibold text-slate-600">Parcela</th>
                              <th className="px-2 py-1.5 text-left font-semibold text-slate-600">Vencimento</th>
                              <th className="px-2 py-1.5 text-right font-semibold text-slate-600">Valor</th>
                              <th className="px-2 py-1.5 text-left font-semibold text-slate-600">Pgto</th>
                              <th className="px-2 py-1.5 text-center font-semibold text-slate-600">Status</th>
                            </tr>
                          </thead>
                          <tbody>
                            {(!d.parcelas || d.parcelas.length === 0) && (
                              <tr className="bg-blue-50 border-t border-slate-100">
                                <td className="px-2 py-1.5 font-semibold">1/1 <span className="text-blue-600 ml-1">←</span></td>
                                <td className="px-2 py-1.5">{fmtDateBR(e.dataVencimento)}</td>
                                <td className="px-2 py-1.5 text-right tabular-nums font-semibold">{formatBRL(Number(e.valorPrevisto))}</td>
                                <td className="px-2 py-1.5">{e.dataPagamento ? `${fmtDateBR(e.dataPagamento)} (${e.formaPagamento ?? "—"})` : "—"}</td>
                                <td className="px-2 py-1.5 text-center">
                                  <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                                    e.status === "pago" ? "bg-green-100 text-green-700" :
                                    e.dataVencimento && String(e.dataVencimento).slice(0,10) < hojeStr ? "bg-red-100 text-red-700" :
                                    "bg-orange-100 text-orange-700"
                                  }`}>{e.status}</span>
                                </td>
                              </tr>
                            )}
                            {d.parcelas?.map((p: any) => (
                              <tr key={p.id} className={`border-t border-slate-100 ${p.id === e.id ? "bg-blue-50" : ""}`}>
                                <td className="px-2 py-1.5 font-semibold">{p.parcelaNumero}/{p.parcelaTotal} {p.id === e.id && <span className="text-blue-600 ml-1">←</span>}</td>
                                <td className="px-2 py-1.5">{fmtDateBR(p.dataVencimento)}</td>
                                <td className="px-2 py-1.5 text-right tabular-nums font-semibold">{formatBRL(Number(p.valorPrevisto))}</td>
                                <td className="px-2 py-1.5">{p.dataPagamento ? `${fmtDateBR(p.dataPagamento)} (${p.formaPagamento ?? "—"})` : "—"}</td>
                                <td className="px-2 py-1.5 text-center">
                                  <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                                    p.status === "pago" ? "bg-green-100 text-green-700" :
                                    p.dataVencimento && p.dataVencimento.slice(0,10) < hojeStr ? "bg-red-100 text-red-700" :
                                    "bg-orange-100 text-orange-700"
                                  }`}>{p.status}</span>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </TabsContent>

                    {/* HISTÓRICO */}
                    <TabsContent value="historico" className="mt-4">
                      {d.auditoria && d.auditoria.length > 0 ? (
                        <div className="space-y-2 max-h-80 overflow-y-auto">
                          {d.auditoria.map((a: any) => (
                            <div key={a.id} className="border-l-2 border-slate-300 pl-3 py-1">
                              <div className="text-xs font-semibold text-slate-700">{a.action}</div>
                              <div className="text-[11px] text-slate-500">
                                {fmtDateBR(a.createdAt.slice(0,10))} · {a.userName ?? "—"} · {a.module}
                              </div>
                              {a.details && <div className="text-xs text-slate-600 mt-0.5">{a.details}</div>}
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-sm text-slate-500 text-center py-6">Nenhum registro de auditoria.</p>
                      )}
                    </TabsContent>
                  </Tabs>
                </div>
              );
            })() : null}

            <DialogFooter className="border-t pt-3">
              <Button variant="outline" onClick={() => setDetailEntryId(null)}>Fechar</Button>
              {detailQuery.data?.entry && detailQuery.data.entry.status !== "pago" && (
                <Button className="bg-green-600 hover:bg-green-700 text-white"
                  onClick={() => { setShowPay(detailQuery.data.entry); setDetailEntryId(null); }}>
                  <CheckCircle className="w-4 h-4 mr-1" />Validar e Pagar
                </Button>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Rev. 1620 — Modal pagamento em lote (Onda 2) */}
        <Dialog open={showBulkPay} onOpenChange={setShowBulkPay}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2"><Zap className="w-4 h-4 text-blue-600" />Pagamento em Lote</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="rounded-lg border border-blue-200 bg-blue-50 p-3">
                <p className="text-xs text-blue-700 font-medium">Você está prestes a marcar como pagos:</p>
                <p className="text-2xl font-bold text-blue-900 tabular-nums mt-1">{selectedIds.size} <span className="text-sm font-normal">títulos</span></p>
                <p className="text-base font-semibold text-blue-800 tabular-nums">{formatBRL(selectedTotal)}</p>
              </div>
              <div>
                <Label>Data do Pagamento</Label>
                <Input type="date" value={bulkDataPagamento} onChange={e => setBulkDataPagamento(e.target.value)} />
              </div>
              <div>
                <Label>Forma de Pagamento</Label>
                <Select value={bulkFormaPagamento} onValueChange={setBulkFormaPagamento}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["pix","ted","boleto","cheque","dinheiro","cartao_credito","debito_automatico"].map(v => (
                      <SelectItem key={v} value={v}>{v.replace(/_/g," ").toUpperCase()}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="text-[11px] text-amber-700 bg-amber-50 border border-amber-200 rounded p-2">
                <strong>Atenção:</strong> A operação aplicará a mesma data e forma de pagamento a todos os títulos. Será registrado no log de auditoria.
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowBulkPay(false)}>Cancelar</Button>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white" disabled={bulkPayMut.isPending || selectedIds.size === 0}
                onClick={() => {
                  // Garantir que só enviamos IDs ainda visíveis/válidos no mês corrente
                  const validIds = Array.from(selectedIds).filter(id =>
                    (mesData as any[]).some((c: any) => c.id === id && c.status !== "pago")
                  );
                  if (validIds.length === 0) {
                    toast({ title: "Nenhum título válido na seleção", variant: "destructive" });
                    return;
                  }
                  bulkPayMut.mutate({
                    ids: validIds,
                    companyId,
                    status: "pago",
                    dataPagamento: bulkDataPagamento,
                    formaPagamento: bulkFormaPagamento,
                  });
                }}>
                {bulkPayMut.isPending ? "Processando..." : `Confirmar ${selectedIds.size} pagamento(s)`}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Rev. 2657 — Modal EDITAR (lançamento manual) */}
        <Dialog open={!!showEdit} onOpenChange={(o) => { if (!o) setShowEdit(null); }}>
          <DialogContent className="max-w-none w-[100vw] h-[100dvh] sm:rounded-none flex flex-col p-0 gap-0">
            <DialogHeader className="px-6 py-4 border-b border-slate-200 shrink-0">
              <DialogTitle className="flex items-center gap-2 text-blue-700">
                <Pencil className="w-5 h-5" />Editar Lançamento
                {showEdit?.origemModulo && showEdit.origemModulo !== "recorrente" && (
                  <span className="text-xs font-medium text-slate-500">· vindo de {ORIGEM_LABELS[showEdit.origemModulo] ?? showEdit.origemModulo}</span>
                )}
              </DialogTitle>
            </DialogHeader>
            {showEdit && (
              <div className="space-y-3 px-6 py-4 overflow-y-auto flex-1 max-w-2xl w-full mx-auto">
                {showEdit.origemModulo && showEdit.origemModulo !== "recorrente" && (
                  <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800">
                    {(showEdit.origemModulo === "compras" || showEdit.origemModulo === "compra_oc") ? (
                      <>
                        <p className="font-semibold mb-0.5">Título vinculado a uma Ordem de Compra</p>
                        <p className="text-[12px] leading-snug">As alterações de <b>Fornecedor</b>, <b>Vencimento</b>, <b>Forma de Pagamento</b> e <b>Observações</b> também serão aplicadas na OC de origem. O <b>valor</b> da OC não é alterado (ele vem dos itens da OC).</p>
                      </>
                    ) : (
                      <>
                        <p className="font-semibold mb-0.5">Título vinculado a {ORIGEM_LABELS[showEdit.origemModulo] ?? showEdit.origemModulo}</p>
                        <p className="text-[12px] leading-snug">As alterações são aplicadas neste título. A sincronização automática com a origem hoje cobre apenas Compras (OC).</p>
                      </>
                    )}
                  </div>
                )}
                <div>
                  <Label className="text-xs text-slate-500">Descrição</Label>
                  <Input value={editForm.descricao} onChange={e => setEditForm(f => ({ ...f, descricao: e.target.value }))}
                    placeholder="Descrição do lançamento" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-xs text-slate-500">Valor (R$)</Label>
                    <Input type="number" step="0.01" value={editForm.valorPrevisto}
                      onChange={e => setEditForm(f => ({ ...f, valorPrevisto: e.target.value }))} placeholder="0,00" />
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500">Forma de Pagamento</Label>
                    <Select value={editForm.formaPagamento || "none"} onValueChange={v => setEditForm(f => ({ ...f, formaPagamento: v === "none" ? "" : v }))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">—</SelectItem>
                        <SelectItem value="pix">PIX</SelectItem>
                        <SelectItem value="ted">TED</SelectItem>
                        <SelectItem value="boleto">Boleto</SelectItem>
                        <SelectItem value="dinheiro">Dinheiro</SelectItem>
                        <SelectItem value="cartao">Cartão</SelectItem>
                        <SelectItem value="cheque">Cheque</SelectItem>
                        <SelectItem value="transferencia">Transferência</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-xs text-slate-500">Competência</Label>
                    <Input type="date" value={editForm.dataCompetencia}
                      onChange={e => setEditForm(f => ({ ...f, dataCompetencia: e.target.value }))} />
                  </div>
                  <div>
                    <Label className="text-xs text-slate-500">Vencimento</Label>
                    <Input type="date" value={editForm.dataVencimento}
                      onChange={e => setEditForm(f => ({ ...f, dataVencimento: e.target.value }))} />
                  </div>
                </div>
                <div>
                  <Label className="text-xs text-slate-500">Categoria / Conta</Label>
                  <Input value={editForm.contaNome} onChange={e => setEditForm(f => ({ ...f, contaNome: e.target.value }))}
                    list="cap-categorias-datalist" placeholder="Categoria contábil" />
                  <datalist id="cap-categorias-datalist">
                    {categoriasOptions.map(n => <option key={n} value={n} />)}
                  </datalist>
                </div>
                <div>
                  <Label className="text-xs text-slate-500">Fornecedor / Cliente</Label>
                  <Input value={editForm.fornecedorNome} onChange={e => setEditForm(f => ({ ...f, fornecedorNome: e.target.value }))}
                    list="cap-fornecedores-datalist" placeholder="Nome do fornecedor / cliente" />
                  <datalist id="cap-fornecedores-datalist">
                    {fornecedoresOptions.map(f => <option key={f.id} value={f.nome} />)}
                  </datalist>
                </div>
                <div>
                  <Label className="text-xs text-slate-500">Obra</Label>
                  <Input value={editForm.obraNome} onChange={e => setEditForm(f => ({ ...f, obraNome: e.target.value }))}
                    placeholder="Obra (opcional)" />
                </div>
                <div>
                  <Label className="text-xs text-slate-500">Observações</Label>
                  <Textarea value={editForm.observacoes} onChange={e => setEditForm(f => ({ ...f, observacoes: e.target.value }))}
                    rows={2} placeholder="Observações (opcional)" />
                </div>
              </div>
            )}
            <DialogFooter className="px-6 py-4 border-t border-slate-200 shrink-0">
              <Button variant="outline" onClick={() => setShowEdit(null)}>Cancelar</Button>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white" disabled={updateEntryMut.isPending} onClick={handleSaveEdit}>
                {updateEntryMut.isPending ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <CheckCircle className="w-4 h-4 mr-1" />}
                Salvar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Rev. 2657 — Modal ANEXAR documento (boleto/NF/foto) */}
        <Dialog open={!!showAnexo} onOpenChange={(o) => { if (!o) setShowAnexo(null); }}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-emerald-700">
                <Paperclip className="w-5 h-5" />Anexar Documento
              </DialogTitle>
            </DialogHeader>
            {showAnexo && (
              <div className="space-y-3">
                <div className="rounded-lg bg-slate-50 border border-slate-200 p-3">
                  <p className="text-sm font-medium text-slate-800">{showAnexo.descricao ?? showAnexo.contaNome ?? "—"}</p>
                  <p className="text-xs text-slate-500">Boleto, nota fiscal, contrato, comprovante ou foto.</p>
                </div>
                <div>
                  <Label className="text-xs text-slate-500">Arquivo (PDF / Word / imagem)</Label>
                  <Input type="file" accept=".pdf,.doc,.docx,image/*" disabled={uploadingAnexo}
                    onChange={e => { const f = e.target.files?.[0]; if (f) handleUploadAnexo(f); }} />
                  {uploadingAnexo && (
                    <p className="text-xs text-slate-500 mt-1 flex items-center gap-1"><Loader2 className="w-3 h-3 animate-spin" />Enviando...</p>
                  )}
                  {anexoUrl && !uploadingAnexo && (
                    <a href={anexoUrl} target="_blank" rel="noopener noreferrer"
                      className="text-xs text-emerald-700 hover:underline mt-1 inline-flex items-center gap-1">
                      <Paperclip className="w-3 h-3" />{anexoNome || "documento"}<ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowAnexo(null)}>Cancelar</Button>
              <Button className="bg-emerald-600 hover:bg-emerald-700 text-white" disabled={anexarMut.isPending || uploadingAnexo || !anexoUrl} onClick={handleSaveAnexo}>
                {anexarMut.isPending ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <CheckCircle className="w-4 h-4 mr-1" />}
                Salvar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Rev. 2228 — Modal EXCLUIR (duplicidade) */}
        <Dialog open={!!showDelete} onOpenChange={(o) => { if (!o) { setShowDelete(null); setMotivoDelete(""); } }}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-red-700">
                <Trash2 className="w-5 h-5" />Excluir Lançamento
              </DialogTitle>
            </DialogHeader>
            {showDelete && (
              <div className="space-y-3">
                <div className="rounded-lg border border-red-200 bg-red-50 p-3">
                  <p className="text-xs text-red-700 font-semibold uppercase tracking-wide mb-1">Atenção — exclusão definitiva</p>
                  <p className="text-sm font-medium text-slate-800">{showDelete.descricao ?? showDelete.contaNome ?? "—"}</p>
                  {showDelete.obraNome && <p className="text-xs text-slate-600">📍 {showDelete.obraNome}</p>}
                  <div className="flex items-center justify-between mt-2 pt-2 border-t border-red-200">
                    <span className="text-xs text-slate-600">Vencimento: {fmtDateBR(showDelete.dataVencimento)}</span>
                    <span className="text-base font-bold text-red-700 tabular-nums">{formatBRL(Number(showDelete.valorPrevisto ?? 0))}</span>
                  </div>
                </div>
                <div>
                  <Label className="text-sm">Motivo da exclusão <span className="text-red-600">*</span></Label>
                  <Textarea value={motivoDelete} onChange={(e) => setMotivoDelete(e.target.value)}
                    placeholder="Ex.: Lançamento em duplicidade com OC-2026-0214" rows={3} className="mt-1" />
                  <p className="text-[11px] text-slate-500 mt-1">Mínimo 5 caracteres. Quem excluiu, quando e o motivo ficam registrados no log de auditoria.</p>
                </div>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => { setShowDelete(null); setMotivoDelete(""); }}>Cancelar</Button>
              <Button className="bg-red-600 hover:bg-red-700 text-white"
                disabled={deleteMut.isPending || motivoDelete.trim().length < 5}
                onClick={() => deleteMut.mutate({ id: showDelete.id, companyId, motivo: motivoDelete.trim() })}>
                {deleteMut.isPending ? "Excluindo..." : "Confirmar exclusão"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Rev. 2228 — Modal ESTORNAR pagamento (baixa errada) */}
        <Dialog open={!!showEstorno} onOpenChange={(o) => { if (!o) { setShowEstorno(null); setMotivoEstorno(""); } }}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-amber-700">
                <RotateCcw className="w-5 h-5" />Estornar Pagamento
              </DialogTitle>
            </DialogHeader>
            {showEstorno && (
              <div className="space-y-3">
                <div className="rounded-lg border border-amber-200 bg-amber-50 p-3">
                  <p className="text-xs text-amber-700 font-semibold uppercase tracking-wide mb-1">O lançamento voltará para "A Pagar"</p>
                  <p className="text-sm font-medium text-slate-800">{showEstorno.descricao ?? showEstorno.contaNome ?? "—"}</p>
                  {showEstorno.obraNome && <p className="text-xs text-slate-600">📍 {showEstorno.obraNome}</p>}
                  <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-amber-200 text-xs">
                    <div><span className="text-slate-500">Pago em:</span> <span className="font-medium text-slate-800">{fmtDateBR(showEstorno.dataPagamento)}</span></div>
                    <div className="text-right"><span className="font-bold text-green-700 tabular-nums">{formatBRL(Number(showEstorno.valorRealizado ?? showEstorno.valorPrevisto ?? 0))}</span></div>
                  </div>
                  <p className="text-[11px] text-amber-700 mt-2">Data de pagamento, valor realizado, forma e comprovante serão limpos.</p>
                </div>
                <div>
                  <Label className="text-sm">Motivo do estorno <span className="text-red-600">*</span></Label>
                  <Textarea value={motivoEstorno} onChange={(e) => setMotivoEstorno(e.target.value)}
                    placeholder="Ex.: Baixa lançada por engano — pagamento não foi efetuado" rows={3} className="mt-1" />
                  <p className="text-[11px] text-slate-500 mt-1">Mínimo 5 caracteres. Estorno fica registrado no histórico do lançamento e no log de auditoria.</p>
                </div>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => { setShowEstorno(null); setMotivoEstorno(""); }}>Cancelar</Button>
              <Button className="bg-amber-600 hover:bg-amber-700 text-white"
                disabled={estornoMut.isPending || motivoEstorno.trim().length < 5}
                onClick={() => estornoMut.mutate({ id: showEstorno.id, companyId, motivo: motivoEstorno.trim() })}>
                {estornoMut.isPending ? "Estornando..." : "Confirmar estorno"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Modal pagar */}
        <Dialog open={!!showPay} onOpenChange={() => setShowPay(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader><DialogTitle>Registrar Pagamento</DialogTitle></DialogHeader>
            {showPay && (
              <div className="space-y-3">
                <div className="bg-gray-50 rounded-lg p-3">
                  <p className="text-sm font-medium text-gray-800">{showPay.descricao ?? showPay.contaNome ?? "—"}</p>
                  {showPay.obraNome && <p className="text-xs text-gray-500">{showPay.obraNome}</p>}
                  <p className="text-lg font-bold text-orange-700 mt-1">{formatBRL(Number(showPay.valorPrevisto))}</p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <Label>Data do Pagamento</Label>
                    <Input type="date" value={dataPagamento} onChange={e => setDataPagamento(e.target.value)} />
                  </div>
                  <div>
                    <Label>Forma de Pagamento</Label>
                    <Select value={formaPagamento} onValueChange={setFormaPagamento}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {["pix","ted","boleto","cheque","dinheiro","cartao_credito","debito_automatico"].map(v => (
                          <SelectItem key={v} value={v}>{v.replace(/_/g," ").toUpperCase()}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Rev. 2655 — Valor + Juros − Descontos + Outros → Total */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <Label>Valor</Label>
                    <Input type="number" step="0.01" value={valorPagar} onChange={e => setValorPagar(e.target.value)} />
                  </div>
                  <div>
                    <Label>Juros</Label>
                    <Input type="number" step="0.01" placeholder="0,00" value={jurosPay} onChange={e => setJurosPay(e.target.value)} />
                  </div>
                  <div>
                    <Label>Descontos</Label>
                    <Input type="number" step="0.01" placeholder="0,00" value={descontosPay} onChange={e => setDescontosPay(e.target.value)} />
                  </div>
                  <div>
                    <Label>Outros (±)</Label>
                    <Input type="number" step="0.01" placeholder="0,00" value={outrosPay} onChange={e => setOutrosPay(e.target.value)} />
                  </div>
                </div>
                <div className="flex items-center justify-between bg-green-50 border border-green-200 rounded-lg px-3 py-2">
                  <span className="text-sm font-medium text-green-800">Total a pagar</span>
                  <span className="text-lg font-bold text-green-700">{formatBRL(totalPagar)}</span>
                </div>

                {/* Rev. 2660 — Conta Bancária + Comprovante lado a lado (reduz altura → sem rolagem) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <Label>Conta Bancária</Label>
                    <Select
                      value={contaBancariaId != null ? String(contaBancariaId) : "none"}
                      onValueChange={v => setContaBancariaId(v === "none" ? null : Number(v))}
                    >
                      <SelectTrigger><SelectValue placeholder="Selecione a conta" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">— Não informar —</SelectItem>
                        {(bankAccounts ?? []).filter((a: any) => a.ativo).map((a: any) => (
                          <SelectItem key={a.id} value={String(a.id)}>
                            {[a.descricao || a.banco, a.agencia ? `Ag ${a.agencia}` : null, a.conta ? `CC ${a.conta}` : null].filter(Boolean).join(" · ")}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Rev. 2655 — Comprovante (PDF/Word/imagem) */}
                  <div>
                    <Label>Comprovante / Documento</Label>
                    <Input type="file" accept=".pdf,.doc,.docx,image/*"
                      onChange={e => { const f = e.target.files?.[0]; if (f) handleUploadComprovante(f); }} disabled={uploadingComp} />
                    {uploadingComp && <p className="text-xs text-gray-500 mt-1">Enviando…</p>}
                    {comprovanteUrl && !uploadingComp && (
                      <p className="text-xs text-green-700 mt-1">
                        Anexado: <a href={comprovanteUrl} target="_blank" rel="noreferrer" className="underline">{comprovanteNome || "ver arquivo"}</a>
                      </p>
                    )}
                  </div>
                </div>

                {/* Rev. 2655 — Cheque: próprio/terceiros + dados do cheque */}
                {formaPagamento === "cheque" && (
                  <div className="border border-blue-200 bg-blue-50/50 rounded-lg p-3 space-y-3">
                    <div>
                      <Label>Tipo de Cheque</Label>
                      <Select value={chequeTipo || "none"} onValueChange={v => setChequeTipo(v === "none" ? "" : v)}>
                        <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">— Selecione —</SelectItem>
                          <SelectItem value="proprio">Próprio</SelectItem>
                          <SelectItem value="terceiros">De terceiros</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    {chequeTipo === "proprio" && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <Label>Nº do Cheque</Label>
                          <Input value={chequeNumero} onChange={e => setChequeNumero(e.target.value)} placeholder="Ex.: 000123" />
                        </div>
                        <div>
                          <Label>Bom para</Label>
                          <Input type="date" value={chequeDataBomPara} onChange={e => setChequeDataBomPara(e.target.value)} />
                        </div>
                      </div>
                    )}
                    {chequeTipo === "terceiros" && (
                      <div className="space-y-3">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div>
                            <Label>Nº do Cheque</Label>
                            <Input value={chequeNumero} onChange={e => setChequeNumero(e.target.value)} placeholder="Ex.: 000123" />
                          </div>
                          <div>
                            <Label>Titular</Label>
                            <Input value={chequeTitular} onChange={e => setChequeTitular(e.target.value)} placeholder="Nome do emitente" />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                          <div>
                            <Label>Banco</Label>
                            <Input value={chequeBanco} onChange={e => setChequeBanco(e.target.value)} />
                          </div>
                          <div>
                            <Label>Agência</Label>
                            <Input value={chequeAgencia} onChange={e => setChequeAgencia(e.target.value)} />
                          </div>
                          <div>
                            <Label>Conta</Label>
                            <Input value={chequeConta} onChange={e => setChequeConta(e.target.value)} />
                          </div>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div>
                            <Label>Emissão</Label>
                            <Input type="date" value={chequeDataEmissao} onChange={e => setChequeDataEmissao(e.target.value)} />
                          </div>
                          <div>
                            <Label>Bom para</Label>
                            <Input type="date" value={chequeDataBomPara} onChange={e => setChequeDataBomPara(e.target.value)} />
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Rev. 2655 — Observações */}
                <div>
                  <Label>Observações</Label>
                  <Textarea rows={2} value={obsPay} onChange={e => setObsPay(e.target.value)} placeholder="Observações da baixa (opcional)" />
                </div>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowPay(null)}>Cancelar</Button>
              <Button className="bg-green-600 hover:bg-green-700 text-white" disabled={payMut.isPending || uploadingComp}
                onClick={() => payMut.mutate({
                  id: showPay.id, companyId, status: "pago", dataPagamento, formaPagamento, contaBancariaId,
                  valorRealizado: totalPagar,
                  juros: jurosPay ? Number(String(jurosPay).replace(",", ".")) : undefined,
                  descontos: descontosPay ? Number(String(descontosPay).replace(",", ".")) : undefined,
                  outros: outrosPay ? Number(String(outrosPay).replace(",", ".")) : undefined,
                  observacoes: obsPay || undefined,
                  comprovanteUrl: comprovanteUrl || undefined,
                  chequeTipo: formaPagamento === "cheque" ? (chequeTipo || undefined) : undefined,
                  chequeNumero: formaPagamento === "cheque" ? (chequeNumero || undefined) : undefined,
                  chequeBanco: formaPagamento === "cheque" ? (chequeBanco || undefined) : undefined,
                  chequeAgencia: formaPagamento === "cheque" ? (chequeAgencia || undefined) : undefined,
                  chequeConta: formaPagamento === "cheque" ? (chequeConta || undefined) : undefined,
                  chequeTitular: formaPagamento === "cheque" ? (chequeTitular || undefined) : undefined,
                  chequeDataEmissao: formaPagamento === "cheque" ? (chequeDataEmissao || undefined) : undefined,
                  chequeDataBomPara: formaPagamento === "cheque" ? (chequeDataBomPara || undefined) : undefined,
                })}>
                {payMut.isPending ? "Registrando..." : "Confirmar Pagamento"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

      </div>
    </DashboardLayout>
  );
}
