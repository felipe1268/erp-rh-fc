import { useState, useRef, useEffect, useCallback, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { useCompany } from "@/contexts/CompanyContext";
import { removeAccents } from "@/lib/searchUtils";
import DashboardLayout from "@/components/DashboardLayout";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Wrench, Package, Search, Loader2, Upload, CheckCircle,
  AlertCircle, Plus, Pencil, Trash2, X, Check, Tag,
  ChevronDown, ChevronRight, ChevronsDown, ChevronsUp,
  Square, CheckSquare, MinusSquare, RotateCcw,
} from "lucide-react";

function formatBRL(v: number) {
  return v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}
function parseBRL(s: string) {
  return parseFloat(s.replace(/\./g, "").replace(",", ".")) || 0;
}
function n(v: any) { return parseFloat(v || "0"); }

const EMPTY_FORM      = { codigo: "", descricao: "", unidade: "", tipo: "", precoUnitario: "", precoMin: "" };
const EMPTY_COMP_FORM = { codigo: "", descricao: "", unidade: "", tipo: "", custoUnitMat: "", custoUnitMdo: "", custoUnitTotal: "" };

/* ════════════════════════════════════════════════════════════════
   COMPONENTE: Dropdown searchable de grupo
   ════════════════════════════════════════════════════════════════ */
function GrupoDropdown({
  value,
  onChange,
  grupos,
  placeholder = "Selecionar grupo...",
  className = "",
}: {
  value: string;
  onChange: (v: string) => void;
  grupos: { id: number; nome: string }[];
  placeholder?: string;
  className?: string;
}) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const ref = useRef<HTMLDivElement>(null);

  // Fecha ao clicar fora
  useEffect(() => {
    function handler(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const filtrados = grupos.filter(g => !q || removeAccents(g.nome).includes(removeAccents(q)));

  function select(nome: string) {
    onChange(nome);
    setOpen(false);
    setQ("");
  }

  return (
    <div ref={ref} className={`relative ${className}`}>
      <div
        className="flex items-center gap-1 h-7 px-2 border rounded text-xs cursor-pointer bg-white hover:border-emerald-400 focus-within:border-emerald-400 focus-within:ring-1 focus-within:ring-emerald-200"
        onClick={() => setOpen(o => !o)}
      >
        {open ? (
          <input
            autoFocus
            className="flex-1 outline-none text-xs bg-transparent"
            placeholder="Buscar grupo..."
            value={q}
            onChange={e => { setQ(e.target.value); }}
            onClick={e => e.stopPropagation()}
            onKeyDown={e => {
              if (e.key === "Escape") { setOpen(false); setQ(""); }
              if (e.key === "Enter" && filtrados.length > 0) select(filtrados[0].nome);
            }}
          />
        ) : (
          <span className={`flex-1 truncate ${value ? "text-foreground" : "text-muted-foreground"}`}>
            {value || placeholder}
          </span>
        )}
        <ChevronDown className="h-3 w-3 text-muted-foreground flex-shrink-0" />
      </div>
      {open && (
        <div className="absolute z-50 top-full left-0 mt-0.5 w-full min-w-[220px] bg-white border rounded-md shadow-lg max-h-52 overflow-y-auto">
          <div
            className="px-3 py-1.5 text-xs text-muted-foreground hover:bg-slate-50 cursor-pointer border-b"
            onClick={() => select("")}
          >
            — Sem grupo —
          </div>
          {filtrados.length === 0 ? (
            <div className="px-3 py-2 text-xs text-muted-foreground">Nenhum grupo encontrado.</div>
          ) : (
            filtrados.map(g => (
              <div
                key={g.id}
                onClick={() => select(g.nome)}
                className={`px-3 py-1.5 text-xs cursor-pointer hover:bg-emerald-50 ${g.nome === value ? "bg-emerald-50 font-medium text-emerald-700" : ""}`}
              >
                {g.nome}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

/* ════════════════════════════════════════════════════════════════
   COMPONENTE: Filtro de grupo (barra de busca + seletor)
   ════════════════════════════════════════════════════════════════ */
function GrupoFiltro({
  value,
  onChange,
  grupos,
}: {
  value: string | null;
  onChange: (v: string | null) => void;
  grupos: { id: number; nome: string }[];
}) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handler(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) { setOpen(false); setQ(""); }
    }
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const filtrados = grupos.filter(g => !q || removeAccents(g.nome).includes(removeAccents(q)));

  function select(nome: string | null) {
    onChange(nome);
    setOpen(false);
    setQ("");
  }

  return (
    <div ref={ref} className="relative">
      {/* Campo visual */}
      <div
        className={`flex items-center gap-2 h-9 px-3 border rounded-md text-sm cursor-pointer bg-white transition-colors
          ${open ? "border-emerald-400 ring-1 ring-emerald-200" : "border-input hover:border-emerald-300"}
          ${value ? "text-emerald-700 border-emerald-300 bg-emerald-50" : "text-muted-foreground"}`}
        style={{ minWidth: 200 }}
        onClick={() => setOpen(o => !o)}
      >
        <Tag className="h-3.5 w-3.5 flex-shrink-0" />
        {open ? (
          <input
            autoFocus
            className="flex-1 outline-none bg-transparent text-sm text-foreground placeholder:text-muted-foreground"
            placeholder="Digite o grupo..."
            value={q}
            onChange={e => setQ(e.target.value)}
            onClick={e => e.stopPropagation()}
            onKeyDown={e => {
              if (e.key === "Escape") { setOpen(false); setQ(""); }
              if (e.key === "Enter" && filtrados.length > 0) select(filtrados[0].nome);
            }}
          />
        ) : (
          <span className="flex-1 truncate text-sm">{value ?? "Filtrar por grupo"}</span>
        )}
        {value && !open && (
          <button
            onClick={e => { e.stopPropagation(); select(null); }}
            className="ml-auto rounded-full hover:bg-emerald-200 p-0.5"
          >
            <X className="h-3 w-3" />
          </button>
        )}
        {!value && <ChevronDown className="h-3.5 w-3.5 flex-shrink-0 ml-auto" />}
      </div>

      {/* Dropdown */}
      {open && (
        <div className="absolute z-50 top-full left-0 mt-1 w-full min-w-[240px] bg-white border rounded-md shadow-lg max-h-64 overflow-y-auto">
          <div
            className="px-3 py-2 text-sm text-muted-foreground hover:bg-slate-50 cursor-pointer border-b"
            onClick={() => select(null)}
          >
            Todos os grupos
          </div>
          {filtrados.length === 0 ? (
            <div className="px-3 py-3 text-sm text-muted-foreground text-center">Nenhum grupo encontrado.</div>
          ) : (
            filtrados.map(g => (
              <div
                key={g.id}
                onClick={() => select(g.nome)}
                className={`px-3 py-2 text-sm cursor-pointer hover:bg-emerald-50
                  ${g.nome === value ? "bg-emerald-50 font-medium text-emerald-700" : ""}`}
              >
                {g.nome}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

/* ════════════════════════════════════════════════════════════════
   SUB-VIEW: Cadastro de Categorias
   ════════════════════════════════════════════════════════════════ */
function CategoriasView({ companyId }: { companyId: number }) {
  const [editingId, setEditingId] = useState<number | "new" | null>(null);
  const [editNome, setEditNome] = useState("");
  const [saveError, setSaveError] = useState<string | null>(null);

  const utils = trpc.useUtils();
  const { data: grupos = [], isLoading } =
    trpc.orcamento.listarGruposInsumos.useQuery({ companyId }, { enabled: companyId > 0 });

  const salvarMut = trpc.orcamento.salvarGrupoInsumo.useMutation({
    onSuccess: () => {
      utils.orcamento.listarGruposInsumos.invalidate({ companyId });
      setEditingId(null); setSaveError(null);
    },
    onError: (err) => setSaveError(err.message),
  });
  const excluirMut = trpc.orcamento.excluirGrupoInsumo.useMutation({
    onSuccess: () => utils.orcamento.listarGruposInsumos.invalidate({ companyId }),
  });

  function startEdit(g: any) { setEditingId(g.id); setEditNome(g.nome); setSaveError(null); }
  function startNew() { setEditingId("new"); setEditNome(""); setSaveError(null); }
  function cancel() { setEditingId(null); setSaveError(null); }
  function save() {
    if (!editNome.trim()) { setSaveError("Nome obrigatório."); return; }
    salvarMut.mutate({
      companyId,
      id: editingId !== "new" ? (editingId as number) : undefined,
      nome: editNome,
    });
  }

  return (
    <>
      <div className="flex items-center gap-3 mb-5">
        <div className="p-2 rounded-lg bg-violet-100">
          <Tag className="h-5 w-5 text-violet-600" />
        </div>
        <div>
          <h1 className="text-xl font-bold">Categorias de Insumos</h1>
          <p className="text-sm text-muted-foreground">Grupos padronizados para classificar insumos</p>
        </div>
        <span className="ml-auto text-sm text-muted-foreground font-mono mr-2">{grupos.length} categorias</span>
        <Button size="sm" className="gap-1.5 bg-violet-600 hover:bg-violet-700 text-white"
          onClick={startNew} disabled={editingId === "new"}>
          <Plus className="h-4 w-4" /> Nova Categoria
        </Button>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-20"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
      ) : (
        <Card className="max-w-xl">
          <div className="divide-y">
            {/* Linha de nova categoria */}
            {editingId === "new" && (
              <div className="flex items-center gap-2 px-4 py-2.5 bg-violet-50">
                <Input
                  autoFocus
                  className="h-7 text-sm flex-1"
                  placeholder="Nome da categoria..."
                  value={editNome}
                  onChange={e => setEditNome(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter") save(); if (e.key === "Escape") cancel(); }}
                />
                {saveError && <span className="text-red-500 text-xs">{saveError}</span>}
                <button onClick={save} disabled={salvarMut.isPending}
                  className="p-1.5 rounded hover:bg-violet-200 text-violet-700" title="Salvar">
                  {salvarMut.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                </button>
                <button onClick={cancel} className="p-1.5 rounded hover:bg-slate-200 text-slate-500" title="Cancelar">
                  <X className="h-4 w-4" />
                </button>
              </div>
            )}

            {grupos.length === 0 && editingId !== "new" ? (
              <div className="text-center py-16 text-muted-foreground">
                <Tag className="h-8 w-8 mx-auto mb-2 opacity-20" />
                <p className="text-sm">Nenhuma categoria cadastrada.</p>
              </div>
            ) : (
              grupos.map(g => (
                <div key={g.id} className="flex items-center gap-2 px-4 py-2.5 group hover:bg-slate-50">
                  {editingId === g.id ? (
                    <>
                      <Input
                        autoFocus
                        className="h-7 text-sm flex-1"
                        value={editNome}
                        onChange={e => setEditNome(e.target.value)}
                        onKeyDown={e => { if (e.key === "Enter") save(); if (e.key === "Escape") cancel(); }}
                      />
                      {saveError && <span className="text-red-500 text-xs">{saveError}</span>}
                      <button onClick={save} disabled={salvarMut.isPending}
                        className="p-1.5 rounded hover:bg-emerald-100 text-emerald-700">
                        {salvarMut.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                      </button>
                      <button onClick={cancel} className="p-1.5 rounded hover:bg-slate-200 text-slate-500">
                        <X className="h-4 w-4" />
                      </button>
                    </>
                  ) : (
                    <>
                      <span className="flex-1 text-sm">{g.nome}</span>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => startEdit(g)}
                          className="p-1.5 rounded hover:bg-blue-100 text-blue-600">
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={() => { if (confirm(`Excluir categoria "${g.nome}"?`)) excluirMut.mutate({ companyId, id: g.id }); }}
                          className="p-1.5 rounded hover:bg-red-100 text-red-500">
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </>
                  )}
                </div>
              ))
            )}
          </div>
        </Card>
      )}
    </>
  );
}

/* ════════════════════════════════════════════════════════════════
   InsumoSubRows — carregado sob demanda quando a composição é expandida
   ════════════════════════════════════════════════════════════════ */
function InsumoSubRows({ companyId, composicaoCodigo }: { companyId: number; composicaoCodigo: string }) {
  const [editingInsId, setEditingInsId] = useState<number | null>(null);
  const [editInsQty,   setEditInsQty]   = useState("");
  const [addingIns,    setAddingIns]    = useState(false);
  const [insSearch,    setInsSearch]    = useState("");
  const [insSelected,  setInsSelected]  = useState<any | null>(null);
  const [addInsQty,    setAddInsQty]    = useState("1");
  const [showInsDrop,  setShowInsDrop]  = useState(false);

  const utils = trpc.useUtils();
  const { data: linhas = [], isLoading } = trpc.orcamento.listarComposicaoInsumosCatalogo.useQuery(
    { companyId, composicaoCodigo },
    { enabled: companyId > 0 }
  );
  const { data: insumosSearch = [] } = trpc.orcamento.buscarInsumosCatalogo.useQuery(
    { companyId, q: insSearch },
    { enabled: companyId > 0 && addingIns }
  );

  const inv = () => utils.orcamento.listarComposicaoInsumosCatalogo.invalidate({ companyId, composicaoCodigo });
  const atualizarQtyMut = trpc.orcamento.atualizarQuantidadeInsumoComposicao.useMutation({
    onSuccess: () => { inv(); setEditingInsId(null); setEditInsQty(""); },
  });
  const adicionarInsMut = trpc.orcamento.adicionarInsumoComposicao.useMutation({
    onSuccess: () => { inv(); setAddingIns(false); setInsSearch(""); setInsSelected(null); setAddInsQty("1"); setShowInsDrop(false); },
  });
  const removerInsMut = trpc.orcamento.removerInsumoComposicao.useMutation({ onSuccess: inv });

  if (isLoading) {
    return (
      <tr className="border-b border-dashed bg-slate-50/70 text-[10px] text-slate-400">
        <td colSpan={11} className="px-8 py-2 flex items-center gap-2">
          <Loader2 className="h-3 w-3 animate-spin" /> Carregando insumos...
        </td>
      </tr>
    );
  }

  return (
    <>
      {(linhas as any[]).map((ins: any, idx: number) => {
        const isEditingQty = editingInsId === ins.id;
        return (
          <tr key={`ins-${ins.id}-${idx}`}
            className="border-b border-dashed bg-slate-50/70 text-[10px] text-slate-600 group/ins">
            <td className="px-2" />
            <td className="px-1 py-1.5">
              <div className="flex justify-center">
                <div className="w-px h-full min-h-[12px] bg-blue-200 mx-auto" />
              </div>
            </td>
            <td className="px-2 py-1.5 font-mono text-[9px] text-slate-400">{ins.insumoCodigo || "—"}</td>
            <td className="px-3 py-1.5 text-slate-600">{ins.insumoDescricao || "—"}</td>
            <td className="px-3 py-1.5 tabular-nums">
              {isEditingQty ? (
                <div className="flex items-center gap-1">
                  <input autoFocus
                    className="w-20 border rounded px-1 py-0.5 text-[10px] text-right font-mono focus:outline-none focus:ring-1 focus:ring-blue-400"
                    value={editInsQty}
                    onChange={e => setEditInsQty(e.target.value)}
                    onKeyDown={e => {
                      if (e.key === "Enter") atualizarQtyMut.mutate({ companyId, id: ins.id, quantidade: editInsQty });
                      if (e.key === "Escape") { setEditingInsId(null); setEditInsQty(""); }
                    }}
                  />
                  <button onClick={() => atualizarQtyMut.mutate({ companyId, id: ins.id, quantidade: editInsQty })}
                    disabled={atualizarQtyMut.isPending}
                    className="p-0.5 rounded hover:bg-blue-100 text-blue-600">
                    {atualizarQtyMut.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : <Check className="h-3 w-3" />}
                  </button>
                  <button onClick={() => { setEditingInsId(null); setEditInsQty(""); }}
                    className="p-0.5 rounded hover:bg-slate-200 text-slate-400">
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ) : (
                <span className="cursor-pointer hover:underline hover:text-blue-600"
                  title="Clique para editar quantidade"
                  onClick={() => { setEditingInsId(ins.id); setEditInsQty(n(ins.quantidade).toFixed(4)); }}>
                  {n(ins.quantidade).toFixed(4)}
                </span>
              )}
            </td>
            <td className="px-3 py-1.5 text-center text-slate-400">{ins.unidade || "—"}</td>
            <td className="px-3 py-1.5 text-right text-blue-500 tabular-nums">{formatBRL(n(ins.precoUnitario))}</td>
            <td className="px-3 py-1.5 text-right text-slate-400 tabular-nums">{n(ins.alocacaoMat).toFixed(4)}</td>
            <td className="px-3 py-1.5 text-right text-slate-400 tabular-nums">{n(ins.alocacaoMdo).toFixed(4)}</td>
            <td className="px-3 py-1.5 text-right font-semibold text-slate-600 tabular-nums">{formatBRL(n(ins.custoUnitTotal))}</td>
            <td className="px-2 py-1.5">
              <button title="Remover insumo da composição"
                onClick={() => { if (confirm("Remover este insumo da composição?")) removerInsMut.mutate({ companyId, id: ins.id }); }}
                className="opacity-0 group-hover/ins:opacity-100 transition-opacity p-0.5 rounded hover:bg-red-100 text-red-400">
                <Trash2 className="h-3 w-3" />
              </button>
            </td>
          </tr>
        );
      })}

      {/* Linha de adicionar insumo */}
      {addingIns ? (
        <tr className="border-b border-dashed bg-blue-50/60 text-[10px]">
          <td className="px-2" />
          <td className="px-1 py-2">
            <div className="flex justify-center">
              <div className="w-px h-full min-h-[12px] bg-blue-200 mx-auto" />
            </div>
          </td>
          <td colSpan={3} className="px-2 py-2">
            <div className="relative flex flex-col gap-1">
              <div className="flex items-center gap-1.5">
                <input autoFocus placeholder="Buscar insumo por código ou descrição..."
                  className="flex-1 border rounded px-2 py-1 text-[10px] focus:outline-none focus:ring-1 focus:ring-blue-400 bg-white"
                  value={insSearch}
                  onChange={e => { setInsSearch(e.target.value); setInsSelected(null); setShowInsDrop(true); }}
                  onFocus={() => setShowInsDrop(true)}
                />
                <input type="text" placeholder="Qtd"
                  className="w-16 border rounded px-1 py-1 text-[10px] text-right font-mono focus:outline-none focus:ring-1 focus:ring-blue-400 bg-white"
                  value={addInsQty}
                  onChange={e => setAddInsQty(e.target.value)}
                />
                <button disabled={!insSelected || adicionarInsMut.isPending}
                  onClick={() => { if (insSelected) adicionarInsMut.mutate({ companyId, composicaoCodigo, insumoCodigo: insSelected.codigo, quantidade: addInsQty }); }}
                  className="p-1 rounded hover:bg-blue-200 text-blue-600 disabled:opacity-30">
                  {adicionarInsMut.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
                </button>
                <button onClick={() => { setAddingIns(false); setInsSearch(""); setInsSelected(null); setShowInsDrop(false); }}
                  className="p-1 rounded hover:bg-slate-200 text-slate-400">
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
              {showInsDrop && (insumosSearch as any[]).length > 0 && !insSelected && (
                <div className="absolute top-8 left-0 right-20 z-50 bg-white border rounded shadow-lg max-h-48 overflow-y-auto">
                  {(insumosSearch as any[]).map((ins: any) => (
                    <button key={ins.id}
                      className="w-full text-left px-2 py-1.5 hover:bg-blue-50 border-b last:border-b-0 flex items-center gap-2"
                      onMouseDown={e => { e.preventDefault(); setInsSelected(ins); setInsSearch(`[${ins.codigo}] ${ins.descricao}`); setShowInsDrop(false); }}>
                      <span className="font-mono text-[9px] text-slate-400 w-16 shrink-0">{ins.codigo}</span>
                      <span className="text-[10px] text-slate-700 truncate">{ins.descricao}</span>
                      <span className="ml-auto text-[9px] text-slate-400 shrink-0">{ins.unidade}</span>
                    </button>
                  ))}
                </div>
              )}
              {insSelected && (
                <p className="text-[9px] text-blue-600">✓ {insSelected.descricao} — {formatBRL(n(insSelected.precoUnitario))}/{insSelected.unidade}</p>
              )}
            </div>
          </td>
          <td colSpan={6} />
        </tr>
      ) : (
        <tr className="border-b border-dashed bg-slate-50/40 text-[10px]">
          <td colSpan={11} className="px-4 py-1.5">
            <button onClick={() => { setAddingIns(true); setInsSearch(""); setInsSelected(null); setAddInsQty("1"); setShowInsDrop(false); }}
              className="flex items-center gap-1 text-blue-500 hover:text-blue-700 hover:underline">
              <Plus className="h-3 w-3" /> Adicionar insumo à composição
            </button>
          </td>
        </tr>
      )}
    </>
  );
}

/* ════════════════════════════════════════════════════════════════
   SUB-VIEW: Composições
   ════════════════════════════════════════════════════════════════ */
const PAGE_SIZE = 50;

function ComposicoesView({ companyId }: { companyId: number }) {
  const [search, setSearch]        = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [tipoFilter, setTipoFilter] = useState<string | null>(null);
  const [expanded, setExpanded]    = useState<Set<number>>(new Set());
  const [editingId, setEditingId]  = useState<number | "new" | null>(null);
  const [editForm, setEditForm]    = useState(EMPTY_COMP_FORM);
  const [saveError, setSaveError]  = useState<string | null>(null);
  const [jobId, setJobId]          = useState<string | null>(null);
  const [jobTotal, setJobTotal]    = useState(0);
  const [importError, setImportError] = useState<string | null>(null);
  const [selected, setSelected]    = useState<Set<number>>(new Set());
  const [page, setPage]            = useState(0);
  const fileRef = useRef<HTMLInputElement>(null);

  // Debounce de 300ms no filtro de busca
  useEffect(() => {
    const t = setTimeout(() => { setDebouncedSearch(search); setPage(0); }, 300);
    return () => clearTimeout(t);
  }, [search]);

  // Reset página ao trocar filtro de tipo
  useEffect(() => { setPage(0); }, [tipoFilter]);

  const utils = trpc.useUtils();
  const { data: composicoes = [], isLoading } =
    trpc.orcamento.listarComposicoesCatalogo.useQuery({ companyId }, { enabled: companyId > 0 });

  function toggleExpand(id: number) {
    setExpanded(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  const { data: novoCodigo } = trpc.orcamento.gerarCodigoComposicao.useQuery(
    { companyId }, { enabled: companyId > 0 && editingId === "new" }
  );
  useEffect(() => {
    if (editingId === "new" && novoCodigo && !editForm.codigo) {
      setEditForm(f => ({ ...f, codigo: novoCodigo }));
    }
  }, [novoCodigo, editingId]);

  /* Polling de importação (reusa o mesmo endpoint de progresso) */
  const { data: progresso } = trpc.orcamento.progressoImportacao.useQuery(
    { jobId: jobId ?? "" },
    {
      enabled: !!jobId,
      refetchInterval: (query: any) => {
        const data = query?.state?.data;
        if (!data || data.status === "running") return 600;
        return false;
      },
    }
  );
  useEffect(() => {
    if (!progresso) return;
    if (progresso.status === "done") utils.orcamento.listarComposicoesCatalogo.invalidate({ companyId });
    if (progresso.status === "error") setImportError(progresso.error ?? "Erro desconhecido.");
  }, [progresso?.status]);

  const invalidate = useCallback(() => utils.orcamento.listarComposicoesCatalogo.invalidate({ companyId }), [companyId]);

  const importMut = trpc.orcamento.importarComposicoesCatalogo.useMutation({
    onSuccess: (res) => { setJobId(res.jobId); setJobTotal(res.total); setImportError(null); },
    onError: (err) => setImportError(err.message),
  });
  const salvarMut = trpc.orcamento.salvarComposicao.useMutation({
    onSuccess: () => { invalidate(); setEditingId(null); setSaveError(null); },
    onError: (err) => setSaveError(err.message),
  });
  const excluirMut = trpc.orcamento.excluirComposicao.useMutation({
    onSuccess: () => invalidate(),
  });
  const excluirBulkMut = trpc.orcamento.excluirComposicoesBulk.useMutation({
    onSuccess: () => { invalidate(); setSelected(new Set()); },
  });
  const excluirTodosMut = trpc.orcamento.excluirTodasComposicoes.useMutation({
    onSuccess: () => { invalidate(); setSelected(new Set()); },
  });

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setJobId(null); setImportError(null);
    const reader = new FileReader();
    reader.onload = (ev) => {
      const base64 = (ev.target?.result as string).split(",")[1];
      if (!base64) return;
      importMut.mutate({ companyId, fileBase64: base64, fileName: file.name });
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  }

  function startEdit(c: any) {
    setEditingId(c.id); setSaveError(null);
    setEditForm({
      codigo:        c.codigo ?? "",
      descricao:     c.descricao ?? "",
      unidade:       c.unidade ?? "",
      tipo:          c.tipo ?? "",
      custoUnitMat:  n(c.custoUnitMat).toFixed(4).replace(".", ","),
      custoUnitMdo:  n(c.custoUnitMdo).toFixed(4).replace(".", ","),
      custoUnitTotal: n(c.custoUnitTotal).toFixed(4).replace(".", ","),
    });
  }
  function startNew() { setEditingId("new"); setSaveError(null); setEditForm({ ...EMPTY_COMP_FORM, codigo: novoCodigo ?? "" }); }
  function cancelEdit() { setEditingId(null); setSaveError(null); }
  function handleSave() {
    if (!editForm.descricao.trim()) { setSaveError("Descrição obrigatória."); return; }
    if (!editForm.codigo.trim())    { setSaveError("Código obrigatório."); return; }
    salvarMut.mutate({
      companyId,
      id: editingId !== "new" ? (editingId as number) : undefined,
      codigo: editForm.codigo, descricao: editForm.descricao,
      unidade: editForm.unidade, tipo: editForm.tipo,
      custoUnitMat:   String(parseBRL(editForm.custoUnitMat)),
      custoUnitMdo:   String(parseBRL(editForm.custoUnitMdo)),
      custoUnitTotal: String(parseBRL(editForm.custoUnitTotal)),
    });
  }

  function field(key: keyof typeof EMPTY_COMP_FORM, className?: string) {
    return (
      <Input
        className={`h-6 text-xs px-1.5 py-0 ${className ?? ""}`}
        value={editForm[key]}
        onChange={e => setEditForm(f => ({ ...f, [key]: e.target.value }))}
        onKeyDown={e => { if (e.key === "Enter") handleSave(); if (e.key === "Escape") cancelEdit(); }}
      />
    );
  }

  const isImporting = importMut.isPending || (!!jobId && progresso?.status === "running");
  const pct   = progresso?.pct ?? 0;
  const done  = progresso?.done ?? 0;
  const total = progresso?.total ?? jobTotal;

  /* Filtro de tipo derivado dos dados */
  const tiposDisponiveis = Array.from(new Set((composicoes as any[]).map((c: any) => c.tipo).filter(Boolean))).sort();
  const tipoGrupos = tiposDisponiveis.map((t: any) => ({ id: 0, nome: t }));

  const q = removeAccents(debouncedSearch);
  const filt = (composicoes as any[]).filter(c =>
    (!tipoFilter || c.tipo === tipoFilter) &&
    (!q || removeAccents(c.descricao || '').includes(q) || removeAccents(c.codigo || '').includes(q) || removeAccents(c.tipo || '').includes(q))
  );
  const totalPages = Math.ceil(filt.length / PAGE_SIZE);
  const pageFilt   = filt.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  const filtIds = filt.map((c: any) => c.id as number);
  const allFiltSelected = filtIds.length > 0 && filtIds.every(id => selected.has(id));
  const someFiltSelected = filtIds.some(id => selected.has(id)) && !allFiltSelected;

  function toggleRow(id: number) {
    setSelected(prev => { const next = new Set(prev); next.has(id) ? next.delete(id) : next.add(id); return next; });
  }
  function toggleAll() {
    if (allFiltSelected) {
      setSelected(prev => { const next = new Set(prev); filtIds.forEach(id => next.delete(id)); return next; });
    } else {
      setSelected(prev => { const next = new Set(prev); filtIds.forEach(id => next.add(id)); return next; });
    }
  }
  function clearSelection() { setSelected(new Set()); }
  function handleExcluirSelecionados() {
    const ids = [...selected];
    if (!confirm(`Excluir ${ids.length} composição(ões) selecionada(s)?`)) return;
    excluirBulkMut.mutate({ companyId, ids });
  }
  function handleExcluirTodas() {
    if (!confirm(`Tem certeza que deseja apagar TODAS as ${(composicoes as any[]).length} composições do catálogo? Esta ação não pode ser desfeita.`)) return;
    excluirTodosMut.mutate({ companyId });
  }

  const isBulkLoading = excluirBulkMut.isPending || excluirTodosMut.isPending;

  const allFiltExpanded = filt.length > 0 && filt.every((c: any) => expanded.has(c.id));
  function toggleExpandAll() {
    if (allFiltExpanded) {
      setExpanded(new Set());
    } else {
      setExpanded(new Set(filt.map((c: any) => c.id)));
    }
  }

  /* ── Renderiza linha de composição + sub-linhas de insumos ── */
  function renderCompRow(c: any) {
    const isSel  = selected.has(c.id);
    const isExp  = expanded.has(c.id);
    const hasIns = (c.totalInsumos ?? 0) > 0;

    /* Modo edição */
    if (editingId === c.id) {
      return (
        <tr key={`edit-${c.id}`} className="border-b bg-blue-50">
          <td className="px-2 py-1" />
          <td className="px-2 py-1" />
          <td className="px-2 py-1">{field("codigo", "font-mono w-24")}</td>
          <td className="px-2 py-1">{field("descricao", "min-w-[260px]")}</td>
          <td className="px-2 py-1">{field("tipo", "w-20")}</td>
          <td className="px-2 py-1">{field("unidade", "w-12 text-center")}</td>
          <td className="px-2 py-1">{field("custoUnitMat", "w-24 text-right")}</td>
          <td className="px-2 py-1">{field("custoUnitMdo", "w-24 text-right")}</td>
          <td className="px-2 py-1">{field("custoUnitTotal", "w-24 text-right")}</td>
          <td className="px-2 py-1 text-center" />
          <td className="px-2 py-1">
            <div className="flex items-center gap-1">
              {saveError && <span className="text-red-500 text-[10px] max-w-[80px] truncate">{saveError}</span>}
              <button onClick={handleSave} disabled={salvarMut.isPending}
                className="p-1 rounded hover:bg-blue-200 text-blue-700">
                {salvarMut.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
              </button>
              <button onClick={cancelEdit} className="p-1 rounded hover:bg-slate-200 text-slate-500">
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          </td>
        </tr>
      );
    }

    return (
      <>
        {/* ── Linha da composição ── */}
        <tr key={`comp-${c.id}`}
          className={`border-b transition-colors group ${isSel ? "bg-blue-50 hover:bg-blue-100" : "hover:bg-muted/30"}`}>
          {/* Checkbox */}
          <td className="px-2 py-2">
            <button onClick={() => toggleRow(c.id)}
              className={`text-slate-400 hover:text-blue-600 transition-colors ${isSel ? "text-blue-600" : ""}`}>
              {isSel ? <CheckSquare className="h-4 w-4" /> : <Square className="h-4 w-4" />}
            </button>
          </td>
          {/* Expand */}
          <td className="px-1 py-2">
            <button
              onClick={() => toggleExpand(c.id)}
              title={isExp ? "Fechar insumos" : (hasIns ? "Ver insumos" : "Expandir para adicionar insumos")}
              className="p-1 rounded transition-colors hover:bg-blue-100 text-blue-400">
              {isExp
                ? <ChevronDown className="h-3.5 w-3.5" />
                : <ChevronRight className="h-3.5 w-3.5" />}
              {hasIns && <span className="text-[9px] ml-0.5 text-slate-400">{c.totalInsumos}</span>}
            </button>
          </td>
          {/* Código */}
          <td className="px-2 py-2 font-mono text-[10px] font-semibold text-blue-700">{c.codigo || "—"}</td>
          {/* Descrição */}
          <td className="px-3 py-2 font-medium">{c.descricao}</td>
          {/* Tipo */}
          <td className="px-3 py-2">
            {c.tipo && <Badge variant="outline" className="text-[10px]">{c.tipo}</Badge>}
          </td>
          {/* Un */}
          <td className="px-3 py-2 text-center text-muted-foreground">{c.unidade || "—"}</td>
          {/* Custos */}
          <td className="px-3 py-2 text-right text-blue-600 tabular-nums">{formatBRL(n(c.custoUnitMat))}</td>
          <td className="px-3 py-2 text-right text-orange-500 tabular-nums">{formatBRL(n(c.custoUnitMdo))}</td>
          <td className="px-3 py-2 text-right font-bold tabular-nums">{formatBRL(n(c.custoUnitTotal))}</td>
          {/* Orçamentos */}
          <td className="px-3 py-2 text-center">
            <span className="inline-flex items-center justify-center w-7 h-5 rounded-full bg-slate-100 text-slate-600 font-medium text-[10px]">
              {c.totalOrcamentos ?? 0}
            </span>
          </td>
          {/* Actions */}
          <td className="px-2 py-1">
            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              <button onClick={() => startEdit(c)} className="p-1 rounded hover:bg-blue-100 text-blue-600">
                <Pencil className="h-3.5 w-3.5" />
              </button>
              <button
                onClick={() => { if (confirm("Excluir esta composição?")) excluirMut.mutate({ companyId, id: c.id }); }}
                className="p-1 rounded hover:bg-red-100 text-red-500">
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          </td>
        </tr>

        {/* ── Sub-linhas de insumos carregadas sob demanda ── */}
        {isExp && <InsumoSubRows companyId={companyId} composicaoCodigo={c.codigo ?? ''} />}

      </>
    );
  }

  return (
    <>
      {/* Cabeçalho */}
      <div className="flex items-center gap-3 mb-5 flex-wrap">
        <div className="p-2 rounded-lg bg-blue-100">
          <Wrench className="h-5 w-5 text-blue-600" />
        </div>
        <div>
          <h1 className="text-xl font-bold">Composições</h1>
          <p className="text-sm text-muted-foreground">Catálogo central de composições da empresa</p>
        </div>
        <span className="ml-auto text-sm text-muted-foreground font-mono mr-2">
          {filt.length}/{(composicoes as any[]).length} registros
        </span>
        <input ref={fileRef} type="file" accept=".xlsx,.xlsm,.xls" className="hidden" onChange={handleFileChange} />
        <Button size="sm" variant="outline"
          className="gap-1.5 border-blue-300 text-blue-700 hover:bg-blue-50"
          onClick={() => fileRef.current?.click()} disabled={isImporting}>
          {isImporting
            ? <><Loader2 className="h-4 w-4 animate-spin" /> Importando...</>
            : <><Upload className="h-4 w-4" /> Importar</>}
        </Button>
        <Button size="sm" className="gap-1.5 bg-blue-600 hover:bg-blue-700 text-white"
          onClick={startNew} disabled={editingId === "new"}>
          <Plus className="h-4 w-4" /> Nova Composição
        </Button>
      </div>

      {/* Progresso de importação */}
      {jobId && progresso && progresso.status !== "done" && progresso.status !== "error" && (
        <div className="mb-4 p-4 rounded-lg bg-blue-50 border border-blue-200">
          <div className="flex items-center justify-between text-sm text-blue-800 mb-2">
            <span className="font-medium flex items-center gap-2"><Loader2 className="h-4 w-4 animate-spin" /> Importando composições...</span>
            <span className="font-mono font-bold">{pct}%</span>
          </div>
          <div className="w-full bg-blue-200 rounded-full h-3 overflow-hidden">
            <div className="bg-blue-500 h-3 rounded-full transition-all duration-300" style={{ width: `${pct}%` }} />
          </div>
          <p className="text-xs text-blue-700 mt-1.5">
            {done} de {total} composições · {progresso.inseridos ?? 0} inseridas · {progresso.atualizados ?? 0} atualizadas
          </p>
        </div>
      )}
      {progresso?.status === "done" && jobId && (
        <div className="flex items-center gap-2 mb-4 p-3 rounded-lg bg-blue-50 border border-blue-200 text-sm text-blue-800">
          <CheckCircle className="h-4 w-4 flex-shrink-0" />
          <span>Importação concluída: <strong>{progresso.total}</strong> composições — <strong>{progresso.inseridos}</strong> inseridas, <strong>{progresso.atualizados}</strong> atualizadas.</span>
          <button onClick={() => setJobId(null)} className="ml-auto">✕</button>
        </div>
      )}
      {importError && (
        <div className="flex items-center gap-2 mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-800">
          <AlertCircle className="h-4 w-4 flex-shrink-0" />
          <span>{importError}</span>
          <button onClick={() => setImportError(null)} className="ml-auto">✕</button>
        </div>
      )}

      {/* Busca + Filtro de tipo */}
      <div className="flex gap-3 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input className="pl-9" placeholder="Buscar por descrição, código ou tipo..."
            value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        {tipoGrupos.length > 0 && (
          <GrupoFiltro value={tipoFilter} onChange={setTipoFilter} grupos={tipoGrupos as any[]} />
        )}
      </div>

      {/* Tabela */}
      {isLoading ? (
        <div className="flex justify-center py-20"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
      ) : (
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b bg-slate-50 text-muted-foreground">
                  <th className="px-2 py-2 w-8">
                    <button onClick={toggleAll} className="text-slate-400 hover:text-blue-600 transition-colors">
                      {allFiltSelected
                        ? <CheckSquare className="h-4 w-4 text-blue-600" />
                        : someFiltSelected
                          ? <MinusSquare className="h-4 w-4 text-blue-400" />
                          : <Square className="h-4 w-4" />}
                    </button>
                  </th>
                  <th className="w-8">
                    <button
                      onClick={toggleExpandAll}
                      title={allFiltExpanded ? "Fechar todas" : "Expandir todas"}
                      className="p-1 rounded hover:bg-blue-100 text-blue-400 transition-colors">
                      {allFiltExpanded
                        ? <ChevronsUp className="h-3.5 w-3.5" />
                        : <ChevronsDown className="h-3.5 w-3.5" />}
                    </button>
                  </th>
                  <th className="text-left px-2 py-2 w-24">Código</th>
                  <th className="text-left px-3 py-2 min-w-[260px]">Descrição</th>
                  <th className="text-left px-3 py-2 w-28">Tipo / Qtd</th>
                  <th className="text-center px-3 py-2 w-12">Un</th>
                  <th className="text-right px-3 py-2 w-28 text-blue-600">Custo Mat / PU</th>
                  <th className="text-right px-3 py-2 w-28 text-orange-500">Custo MO / Aloc.Mat</th>
                  <th className="text-right px-3 py-2 w-28 font-semibold">Total / Aloc.MO</th>
                  <th className="text-right px-3 py-2 w-24 text-slate-500">Orç / C.Total</th>
                  <th className="w-16" />
                </tr>
              </thead>
              <tbody>
                {/* Linha de nova composição */}
                {editingId === "new" && (
                  <tr className="border-b bg-blue-50">
                    <td className="px-2 py-1" /><td className="px-2 py-1" />
                    <td className="px-2 py-1">{field("codigo", "font-mono w-24")}</td>
                    <td className="px-2 py-1">{field("descricao", "min-w-[260px]")}</td>
                    <td className="px-2 py-1">{field("tipo", "w-20")}</td>
                    <td className="px-2 py-1">{field("unidade", "w-12 text-center")}</td>
                    <td className="px-2 py-1">{field("custoUnitMat", "w-24 text-right")}</td>
                    <td className="px-2 py-1">{field("custoUnitMdo", "w-24 text-right")}</td>
                    <td className="px-2 py-1">{field("custoUnitTotal", "w-24 text-right")}</td>
                    <td className="px-2 py-1" />
                    <td className="px-2 py-1">
                      <div className="flex items-center gap-1">
                        {saveError && <span className="text-red-500 text-[10px]">{saveError}</span>}
                        <button onClick={handleSave} disabled={salvarMut.isPending}
                          className="p-1 rounded hover:bg-blue-200 text-blue-700">
                          {salvarMut.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
                        </button>
                        <button onClick={cancelEdit} className="p-1 rounded hover:bg-slate-200 text-slate-500">
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                )}
                {filt.length === 0 && editingId !== "new" ? (
                  <tr>
                    <td colSpan={11} className="py-16 text-center text-muted-foreground">
                      <Wrench className="h-8 w-8 mx-auto mb-2 opacity-20" />
                      <p className="text-sm">{search || tipoFilter ? "Nenhuma composição encontrada." : "Nenhuma composição cadastrada ainda."}</p>
                      {!search && !tipoFilter && <p className="text-xs mt-1">Use "Importar" ou clique em "Nova Composição".</p>}
                    </td>
                  </tr>
                ) : pageFilt.map((c: any) => renderCompRow(c))}
              </tbody>
            </table>
          </div>

          {/* Paginação */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between px-4 py-3 border-t text-sm text-muted-foreground">
              <span>
                {page * PAGE_SIZE + 1}–{Math.min((page + 1) * PAGE_SIZE, filt.length)} de {filt.length} composições
              </span>
              <div className="flex items-center gap-1">
                <button onClick={() => setPage(0)} disabled={page === 0}
                  className="px-2 py-1 rounded hover:bg-slate-100 disabled:opacity-30 text-xs">«</button>
                <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0}
                  className="px-2 py-1 rounded hover:bg-slate-100 disabled:opacity-30 text-xs">‹ Anterior</button>
                <span className="px-3 font-medium text-xs">{page + 1} / {totalPages}</span>
                <button onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))} disabled={page >= totalPages - 1}
                  className="px-2 py-1 rounded hover:bg-slate-100 disabled:opacity-30 text-xs">Próxima ›</button>
                <button onClick={() => setPage(totalPages - 1)} disabled={page >= totalPages - 1}
                  className="px-2 py-1 rounded hover:bg-slate-100 disabled:opacity-30 text-xs">»</button>
              </div>
            </div>
          )}
        </Card>
      )}

      {/* ── Barra flutuante de ações em massa ── */}
      <div className={`fixed bottom-6 left-1/2 -translate-x-1/2 z-50 transition-all duration-200
        ${selected.size > 0
          ? "opacity-100 translate-y-0 pointer-events-auto"
          : "opacity-0 translate-y-4 pointer-events-none"}`}>
        <div className="flex items-center gap-3 px-5 py-3 bg-slate-900 text-white rounded-2xl shadow-2xl text-sm">
          <span className="font-medium">
            <span className="text-blue-300 font-bold">{selected.size}</span> selecionada{selected.size !== 1 ? "s" : ""}
          </span>
          <button onClick={clearSelection} className="text-slate-400 hover:text-white text-xs underline underline-offset-2">
            Limpar
          </button>
          <div className="w-px h-4 bg-slate-600" />
          <button onClick={handleExcluirSelecionados} disabled={isBulkLoading}
            className="flex items-center gap-1.5 text-red-400 hover:text-red-300 font-medium transition-colors disabled:opacity-50">
            {excluirBulkMut.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
            Excluir selecionadas
          </button>
          <div className="w-px h-4 bg-slate-600" />
          <button onClick={handleExcluirTodas} disabled={isBulkLoading}
            className="flex items-center gap-1.5 text-red-600 hover:text-red-400 font-medium transition-colors disabled:opacity-50">
            {excluirTodosMut.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
            Apagar todas
          </button>
        </div>
      </div>
    </>
  );
}

/* ════════════════════════════════════════════════════════════════
   SUB-VIEW: Insumos
   ════════════════════════════════════════════════════════════════ */
function InsumosView({ companyId, onGerenciarCategorias }: { companyId: number; onGerenciarCategorias: () => void }) {
  const [search, setSearch]        = useState("");
  const [catFilter, setCatFilter]  = useState<string | null>(null);
  const [editingId, setEditingId]  = useState<number | "new" | null>(null);
  const [editForm, setEditForm]    = useState(EMPTY_FORM);
  const [saveError, setSaveError]  = useState<string | null>(null);
  const [jobId, setJobId]          = useState<string | null>(null);
  const [jobTotal, setJobTotal]    = useState(0);
  const [importError, setImportError] = useState<string | null>(null);
  const [selected, setSelected]    = useState<Set<number>>(new Set());
  const fileRef = useRef<HTMLInputElement>(null);

  // ── Parâmetros de encargos ──────────────────────────────────
  const [editingParams, setEditingParams] = useState(false);
  const [lsEdit, setLsEdit] = useState("");
  const [heEdit, setHeEdit] = useState("");

  const utils = trpc.useUtils();
  const { data: insumos = [], isLoading } =
    trpc.orcamento.listarInsumosCatalogo.useQuery({ companyId }, { enabled: companyId > 0 });
  const { data: grupos = [] } =
    trpc.orcamento.listarGruposInsumos.useQuery({ companyId }, { enabled: companyId > 0 });

  const { data: params } = trpc.orcamento.getParametros.useQuery({ companyId }, { enabled: companyId > 0 });
  const salvarParamsMut = trpc.orcamento.salvarParametros.useMutation({
    onSuccess: () => { utils.orcamento.getParametros.invalidate({ companyId }); setEditingParams(false); },
  });

  const ls = parseFloat(params?.ls ?? '0');
  const he = parseFloat(params?.he ?? '0');
  const fatorEnc = (1 + ls / 100) * (1 + he / 100);
  const isMaoDeObra = (unidade: string | null | undefined) =>
    (unidade ?? '').trim().toLowerCase() === 'h';
  const precoComEnc = (base: number, unidade: string | null | undefined) =>
    isMaoDeObra(unidade) ? base * fatorEnc : base;

  const { data: novoCodigo } = trpc.orcamento.gerarCodigoInsumo.useQuery(
    { companyId }, { enabled: companyId > 0 && editingId === "new" }
  );
  useEffect(() => {
    if (editingId === "new" && novoCodigo && !editForm.codigo) {
      setEditForm(f => ({ ...f, codigo: novoCodigo }));
    }
  }, [novoCodigo, editingId]);

  /* Polling de importação */
  const { data: progresso } = trpc.orcamento.progressoImportacao.useQuery(
    { jobId: jobId ?? "" },
    {
      enabled: !!jobId,
      refetchInterval: (query: any) => {
        const data = query?.state?.data;
        if (!data || data.status === "running") return 600;
        return false;
      },
    }
  );
  useEffect(() => {
    if (!progresso) return;
    if (progresso.status === "done") utils.orcamento.listarInsumosCatalogo.invalidate({ companyId });
    if (progresso.status === "error") setImportError(progresso.error ?? "Erro desconhecido.");
  }, [progresso?.status]);

  const invalidate = useCallback(() => utils.orcamento.listarInsumosCatalogo.invalidate({ companyId }), [companyId]);

  const importMut = trpc.orcamento.importarInsumosCatalogo.useMutation({
    onSuccess: (res) => { setJobId(res.jobId); setJobTotal(res.total); setImportError(null); },
    onError: (err) => setImportError(err.message),
  });
  const salvarMut = trpc.orcamento.salvarInsumo.useMutation({
    onSuccess: () => { invalidate(); setEditingId(null); setSaveError(null); },
    onError: (err) => setSaveError(err.message),
  });
  const excluirMut = trpc.orcamento.excluirInsumo.useMutation({
    onSuccess: () => invalidate(),
  });
  const excluirBulkMut = trpc.orcamento.excluirInsumosBulk.useMutation({
    onSuccess: () => { invalidate(); setSelected(new Set()); },
  });
  const excluirTodosMut = trpc.orcamento.excluirTodosInsumos.useMutation({
    onSuccess: () => { invalidate(); setSelected(new Set()); },
  });

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setJobId(null); setImportError(null);
    const reader = new FileReader();
    reader.onload = (ev) => {
      const base64 = (ev.target?.result as string).split(",")[1];
      if (!base64) return;
      importMut.mutate({ companyId, fileBase64: base64, fileName: file.name });
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  }

  function startEdit(ins: any) {
    setEditingId(ins.id); setSaveError(null);
    setEditForm({
      codigo:        ins.codigo ?? "",
      descricao:     ins.descricao ?? "",
      unidade:       ins.unidade ?? "",
      tipo:          ins.tipo ?? "",
      precoUnitario: n(ins.precoMedio).toFixed(4).replace(".", ","),
      precoMin:      n(ins.precoMin).toFixed(4).replace(".", ","),
    });
  }
  function startNew() { setEditingId("new"); setSaveError(null); setEditForm({ ...EMPTY_FORM, codigo: novoCodigo ?? "" }); }
  function cancelEdit() { setEditingId(null); setSaveError(null); }
  function handleSave() {
    if (!editForm.descricao.trim()) { setSaveError("Descrição obrigatória."); return; }
    if (!editForm.codigo.trim())    { setSaveError("Código obrigatório."); return; }
    salvarMut.mutate({
      companyId,
      id: editingId !== "new" ? (editingId as number) : undefined,
      codigo: editForm.codigo, descricao: editForm.descricao,
      unidade: editForm.unidade, tipo: editForm.tipo,
      precoUnitario: String(parseBRL(editForm.precoUnitario)),
      precoMin: String(parseBRL(editForm.precoMin)),
    });
  }

  function field(key: keyof typeof EMPTY_FORM, className?: string) {
    return (
      <Input
        className={`h-6 text-xs px-1.5 py-0 ${className ?? ""}`}
        value={editForm[key]}
        onChange={e => setEditForm(f => ({ ...f, [key]: e.target.value }))}
        onKeyDown={e => { if (e.key === "Enter") handleSave(); if (e.key === "Escape") cancelEdit(); }}
      />
    );
  }

  /* ── Seleção ── */
  const isImporting = importMut.isPending || (!!jobId && progresso?.status === "running");
  const pct   = progresso?.pct ?? 0;
  const done  = progresso?.done ?? 0;
  const total = progresso?.total ?? jobTotal;

  const q = removeAccents(search);
  const filt = (insumos as any[]).filter(i =>
    (!catFilter || i.tipo === catFilter) &&
    (!q || removeAccents(i.descricao || '').includes(q) || removeAccents(i.codigo || '').includes(q) || removeAccents(i.tipo || '').includes(q))
  );

  const filtIds = filt.map((i: any) => i.id as number);
  const allFiltSelected = filtIds.length > 0 && filtIds.every(id => selected.has(id));
  const someFiltSelected = filtIds.some(id => selected.has(id)) && !allFiltSelected;

  function toggleRow(id: number) {
    setSelected(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }
  function toggleAll() {
    if (allFiltSelected) {
      setSelected(prev => { const next = new Set(prev); filtIds.forEach(id => next.delete(id)); return next; });
    } else {
      setSelected(prev => { const next = new Set(prev); filtIds.forEach(id => next.add(id)); return next; });
    }
  }
  function clearSelection() { setSelected(new Set()); }

  function handleExcluirSelecionados() {
    const ids = [...selected];
    if (!confirm(`Excluir ${ids.length} insumo(s) selecionado(s)?`)) return;
    excluirBulkMut.mutate({ companyId, ids });
  }
  function handleExcluirTodos() {
    if (!confirm(`Tem certeza que deseja apagar TODOS os ${insumos.length} insumos do catálogo? Esta ação não pode ser desfeita.`)) return;
    excluirTodosMut.mutate({ companyId });
  }

  const isBulkLoading = excluirBulkMut.isPending || excluirTodosMut.isPending;

  /* ── Render row ── */
  function renderRow(i: any) {
    const isSel = selected.has(i.id);
    if (editingId === i.id) {
      return (
        <tr key={i.id} className="border-b bg-emerald-50">
          <td className="px-3 py-1" />
          <td className="px-2 py-1">{field("codigo", "font-mono w-24")}</td>
          <td className="px-2 py-1">{field("descricao", "min-w-[260px]")}</td>
          <td className="px-2 py-1">
            <GrupoDropdown value={editForm.tipo} onChange={v => setEditForm(f => ({ ...f, tipo: v }))}
              grupos={grupos as any[]} className="w-40" />
          </td>
          <td className="px-2 py-1">{field("unidade", "w-12 text-center")}</td>
          <td className="px-2 py-1">{field("precoUnitario", "w-24 text-right")}</td>
          <td className="px-2 py-1 text-right">
            <span className="text-xs font-semibold text-blue-700 tabular-nums px-1.5">
              {formatBRL(precoComEnc(parseBRL(editForm.precoUnitario), editForm.unidade))}
            </span>
          </td>
          <td className="px-2 py-1 text-center">
            <span className="inline-flex items-center justify-center w-7 h-5 rounded-full bg-slate-100 text-slate-600 font-medium text-[10px]">
              {i.totalOrcamentos}
            </span>
          </td>
          <td className="px-2 py-1">
            <div className="flex items-center gap-1">
              {saveError && <span className="text-red-500 text-[10px] max-w-[80px] truncate">{saveError}</span>}
              <button onClick={handleSave} disabled={salvarMut.isPending}
                className="p-1 rounded hover:bg-emerald-200 text-emerald-700">
                {salvarMut.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
              </button>
              <button onClick={cancelEdit} className="p-1 rounded hover:bg-slate-200 text-slate-500">
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          </td>
        </tr>
      );
    }
    return (
      <tr key={i.id}
        className={`border-b transition-colors group ${isSel ? "bg-blue-50 hover:bg-blue-100" : "hover:bg-muted/30"}`}>
        {/* Checkbox */}
        <td className="px-3 py-2">
          <button onClick={() => toggleRow(i.id)}
            className={`text-slate-400 hover:text-blue-600 transition-colors ${isSel ? "text-blue-600" : ""}`}>
            {isSel ? <CheckSquare className="h-4 w-4" /> : <Square className="h-4 w-4" />}
          </button>
        </td>
        <td className="px-4 py-2 font-mono text-[10px] text-slate-500">{i.codigo || "—"}</td>
        <td className="px-3 py-2">{i.descricao}</td>
        <td className="px-3 py-2">
          {i.tipo && <Badge variant="outline" className="text-[10px]">{i.tipo}</Badge>}
        </td>
        <td className="px-3 py-2 text-center text-muted-foreground">{i.unidade || "—"}</td>
        <td className="px-3 py-2 text-right text-slate-400 tabular-nums">{formatBRL(n(i.precoMedio))}</td>
        <td className="px-3 py-2 text-right font-semibold tabular-nums text-blue-700">{formatBRL(precoComEnc(n(i.precoMedio), i.unidade))}</td>
        <td className="px-3 py-2 text-center">
          <span className="inline-flex items-center justify-center w-7 h-5 rounded-full bg-slate-100 text-slate-600 font-medium text-[10px]">
            {i.totalOrcamentos}
          </span>
        </td>
        <td className="px-2 py-1">
          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <button onClick={() => startEdit(i)} className="p-1 rounded hover:bg-blue-100 text-blue-600">
              <Pencil className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={() => { if (confirm("Excluir este insumo?")) excluirMut.mutate({ companyId, id: i.id }); }}
              className="p-1 rounded hover:bg-red-100 text-red-500">
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </div>
        </td>
      </tr>
    );
  }

  return (
    <>
      {/* Cabeçalho */}
      <div className="flex items-center gap-3 mb-5">
        <div className="p-2 rounded-lg bg-emerald-100">
          <Package className="h-5 w-5 text-emerald-600" />
        </div>
        <div>
          <h1 className="text-xl font-bold">Insumos</h1>
          <p className="text-sm text-muted-foreground">Catálogo central de insumos da empresa</p>
        </div>
        <span className="ml-auto text-sm text-muted-foreground font-mono mr-2">
          {filt.length}/{insumos.length} registros
        </span>
        <Button size="sm" variant="outline"
          className="gap-1.5 border-violet-300 text-violet-700 hover:bg-violet-50"
          onClick={onGerenciarCategorias}>
          <Tag className="h-4 w-4" /> Categorias
        </Button>
        <input ref={fileRef} type="file" accept=".xlsx,.xlsm,.xls" className="hidden" onChange={handleFileChange} />
        <Button size="sm" variant="outline"
          className="gap-1.5 border-emerald-300 text-emerald-700 hover:bg-emerald-50"
          onClick={() => fileRef.current?.click()} disabled={isImporting}>
          {isImporting
            ? <><Loader2 className="h-4 w-4 animate-spin" /> Importando...</>
            : <><Upload className="h-4 w-4" /> Importar</>}
        </Button>
        <Button size="sm" className="gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white"
          onClick={startNew} disabled={editingId === "new"}>
          <Plus className="h-4 w-4" /> Novo Insumo
        </Button>
      </div>

      {/* Progresso de importação */}
      {jobId && progresso && progresso.status !== "done" && progresso.status !== "error" && (
        <div className="mb-4 p-4 rounded-lg bg-emerald-50 border border-emerald-200">
          <div className="flex items-center justify-between text-sm text-emerald-800 mb-2">
            <span className="font-medium flex items-center gap-2"><Loader2 className="h-4 w-4 animate-spin" /> Importando insumos...</span>
            <span className="font-mono font-bold">{pct}%</span>
          </div>
          <div className="w-full bg-emerald-200 rounded-full h-3 overflow-hidden">
            <div className="bg-emerald-500 h-3 rounded-full transition-all duration-300" style={{ width: `${pct}%` }} />
          </div>
          <p className="text-xs text-emerald-700 mt-1.5">
            {done} de {total} insumos · {progresso.inseridos ?? 0} inseridos · {progresso.atualizados ?? 0} atualizados
          </p>
        </div>
      )}
      {progresso?.status === "done" && jobId && (
        <div className="flex items-center gap-2 mb-4 p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-sm text-emerald-800">
          <CheckCircle className="h-4 w-4 flex-shrink-0" />
          <span>Importação concluída: <strong>{progresso.total}</strong> insumos — <strong>{progresso.inseridos}</strong> inseridos, <strong>{progresso.atualizados}</strong> atualizados.</span>
          <button onClick={() => setJobId(null)} className="ml-auto">✕</button>
        </div>
      )}
      {importError && (
        <div className="flex items-center gap-2 mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-800">
          <AlertCircle className="h-4 w-4 flex-shrink-0" />
          <span>{importError}</span>
          <button onClick={() => setImportError(null)} className="ml-auto">✕</button>
        </div>
      )}

      {/* Busca + Filtro de grupo */}
      <div className="flex gap-3 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input className="pl-9" placeholder="Buscar por descrição, código ou grupo..."
            value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <GrupoFiltro value={catFilter} onChange={setCatFilter} grupos={grupos as any[]} />
      </div>

      {/* ── Banner de Encargos Sociais ──────────────────────────── */}
      <div className="mb-4 px-5 py-3 rounded-lg border border-blue-100 bg-blue-50/60 flex items-center gap-6 flex-wrap">
        {editingParams ? (
          <>
            <span className="text-xs font-semibold text-slate-600 uppercase tracking-wide">Encargos Sociais</span>
            <div className="flex items-center gap-2">
              <label className="text-xs font-medium text-slate-600">L.S. =</label>
              <input autoFocus
                className="w-20 border rounded px-2 py-0.5 text-sm text-right font-mono focus:outline-none focus:ring-1 focus:ring-blue-400"
                value={lsEdit} onChange={e => setLsEdit(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter") salvarParamsMut.mutate({ companyId, ls: String(parseBRL(lsEdit)), he: String(parseBRL(heEdit)) }); if (e.key === "Escape") setEditingParams(false); }}
              />
              <span className="text-xs text-slate-500">%</span>
            </div>
            <div className="flex items-center gap-2">
              <label className="text-xs font-medium text-slate-600">H.E. (reajuste) =</label>
              <input
                className="w-20 border rounded px-2 py-0.5 text-sm text-right font-mono focus:outline-none focus:ring-1 focus:ring-blue-400"
                value={heEdit} onChange={e => setHeEdit(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter") salvarParamsMut.mutate({ companyId, ls: String(parseBRL(lsEdit)), he: String(parseBRL(heEdit)) }); if (e.key === "Escape") setEditingParams(false); }}
              />
              <span className="text-xs text-slate-500">%</span>
            </div>
            <div className="flex items-center gap-1 ml-auto">
              <button
                onClick={() => salvarParamsMut.mutate({ companyId, ls: String(parseBRL(lsEdit)), he: String(parseBRL(heEdit)) })}
                disabled={salvarParamsMut.isPending}
                className="p-1.5 rounded hover:bg-blue-200 text-blue-700">
                {salvarParamsMut.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
              </button>
              <button onClick={() => setEditingParams(false)} className="p-1.5 rounded hover:bg-slate-200 text-slate-500">
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          </>
        ) : (
          <>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Encargos Sociais</span>
            <div className="flex items-center gap-1.5">
              <span className="text-sm font-bold text-slate-700">L.S. =</span>
              <span className="text-sm font-bold text-blue-700 tabular-nums">{ls.toFixed(2).replace('.', ',')}%</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-sm font-bold text-slate-700">H.E. (reajuste) =</span>
              <span className="text-sm font-bold text-blue-700 tabular-nums">{he.toFixed(2).replace('.', ',')}%</span>
            </div>
            {(ls > 0 || he > 0) && (
              <span className="text-xs text-slate-400">
                Fator: ×{fatorEnc.toFixed(4)}{' '}
                <span className="text-slate-300">|</span>{' '}
                <span title="Encargos aplicados apenas em insumos com unidade hora (h)">aplica em Un = h</span>
              </span>
            )}
            <button
              onClick={() => { setLsEdit(ls.toFixed(2).replace('.', ',')); setHeEdit(he.toFixed(2).replace('.', ',')); setEditingParams(true); }}
              className="ml-auto flex items-center gap-1.5 text-xs text-blue-600 hover:text-blue-800 hover:underline">
              <Pencil className="h-3 w-3" /> Editar
            </button>
          </>
        )}
      </div>

      {/* Tabela */}
      {isLoading ? (
        <div className="flex justify-center py-20"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
      ) : (
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b bg-slate-50 text-muted-foreground">
                  {/* Checkbox "selecionar todos" */}
                  <th className="px-3 py-2 w-8">
                    <button onClick={toggleAll} title={allFiltSelected ? "Desselecionar todos" : "Selecionar todos visíveis"}
                      className="text-slate-400 hover:text-blue-600 transition-colors">
                      {allFiltSelected
                        ? <CheckSquare className="h-4 w-4 text-blue-600" />
                        : someFiltSelected
                          ? <MinusSquare className="h-4 w-4 text-blue-400" />
                          : <Square className="h-4 w-4" />
                      }
                    </button>
                  </th>
                  <th className="text-left px-4 py-2 w-24">Código</th>
                  <th className="text-left px-3 py-2 min-w-[260px]">Descrição</th>
                  <th className="text-left px-3 py-2 w-36">Grupo</th>
                  <th className="text-center px-3 py-2 w-12">Un</th>
                  <th className="text-right px-3 py-2 w-28 text-slate-500">Preço Base</th>
                  <th className="text-right px-3 py-2 w-28 font-semibold">
                    <span>Preço c/enc.</span>
                    {(ls > 0 || he > 0) && (
                      <div className="text-[9px] font-normal text-blue-500 leading-tight">
                        {ls > 0 && <span>LS {ls.toFixed(2)}%</span>}
                        {ls > 0 && he > 0 && <span> · </span>}
                        {he > 0 && <span>HE {he.toFixed(2)}%</span>}
                      </div>
                    )}
                  </th>
                  <th className="text-center px-3 py-2 w-20">Orçamentos</th>
                  <th className="w-16" />
                </tr>
              </thead>
              <tbody>
                {/* Linha de novo insumo */}
                {editingId === "new" && (
                  <tr className="border-b bg-blue-50">
                    <td className="px-3 py-1" />
                    <td className="px-2 py-1">{field("codigo", "font-mono w-24")}</td>
                    <td className="px-2 py-1">{field("descricao", "min-w-[260px]")}</td>
                    <td className="px-2 py-1">
                      <GrupoDropdown value={editForm.tipo} onChange={v => setEditForm(f => ({ ...f, tipo: v }))}
                        grupos={grupos as any[]} className="w-40" />
                    </td>
                    <td className="px-2 py-1">{field("unidade", "w-12 text-center")}</td>
                    <td className="px-2 py-1">{field("precoUnitario", "w-24 text-right")}</td>
                    <td className="px-2 py-1 text-right">
                      <span className="text-xs font-semibold text-blue-700 tabular-nums px-1.5">
                        {formatBRL(precoComEnc(parseBRL(editForm.precoUnitario), editForm.unidade))}
                      </span>
                    </td>
                    <td className="px-2 py-1" />
                    <td className="px-2 py-1">
                      <div className="flex items-center gap-1">
                        {saveError && <span className="text-red-500 text-[10px]">{saveError}</span>}
                        <button onClick={handleSave} disabled={salvarMut.isPending}
                          className="p-1 rounded hover:bg-blue-200 text-blue-700">
                          {salvarMut.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
                        </button>
                        <button onClick={cancelEdit} className="p-1 rounded hover:bg-slate-200 text-slate-500">
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                )}

                {filt.length === 0 && editingId !== "new" ? (
                  <tr>
                    <td colSpan={9} className="py-16 text-center text-muted-foreground">
                      <Package className="h-8 w-8 mx-auto mb-2 opacity-20" />
                      <p className="text-sm">{search || catFilter ? "Nenhum insumo encontrado." : "Nenhum insumo cadastrado ainda."}</p>
                      {!search && !catFilter && <p className="text-xs mt-1">Use "Importar" ou clique em "Novo Insumo".</p>}
                    </td>
                  </tr>
                ) : filt.map((i: any) => renderRow(i))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* ── Barra flutuante de ações em massa ── */}
      {(selected.size > 0 || true) && (
        <div className={`fixed bottom-6 left-1/2 -translate-x-1/2 z-50 transition-all duration-200
          ${selected.size > 0
            ? "opacity-100 translate-y-0 pointer-events-auto"
            : "opacity-0 translate-y-4 pointer-events-none"}`}>
          <div className="flex items-center gap-3 px-5 py-3 bg-slate-900 text-white rounded-2xl shadow-2xl text-sm">
            <span className="font-medium">
              <span className="text-blue-300 font-bold">{selected.size}</span> selecionado{selected.size !== 1 ? "s" : ""}
            </span>
            <button onClick={clearSelection}
              className="text-slate-400 hover:text-white text-xs underline underline-offset-2">
              Limpar
            </button>
            <div className="w-px h-4 bg-slate-600" />
            <button
              onClick={handleExcluirSelecionados}
              disabled={isBulkLoading}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-red-600 hover:bg-red-500 rounded-lg text-xs font-medium transition-colors disabled:opacity-50">
              {excluirBulkMut.isPending
                ? <Loader2 className="h-3.5 w-3.5 animate-spin" />
                : <Trash2 className="h-3.5 w-3.5" />}
              Excluir selecionados
            </button>
            <div className="w-px h-4 bg-slate-600" />
            <button
              onClick={handleExcluirTodos}
              disabled={isBulkLoading}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-700 hover:bg-red-900 border border-red-800 rounded-lg text-xs font-medium text-red-300 hover:text-red-200 transition-colors disabled:opacity-50">
              {excluirTodosMut.isPending
                ? <Loader2 className="h-3.5 w-3.5 animate-spin" />
                : <Trash2 className="h-3.5 w-3.5" />}
              Apagar todos ({insumos.length})
            </button>
          </div>
        </div>
      )}
    </>
  );
}

/* ════════════════════════════════════════════════════════════════
   COMPONENTE: EncargosView
   ════════════════════════════════════════════════════════════════ */
function EncargosView({ companyId }: { companyId: number }) {
  const utils = trpc.useUtils();
  const { data: rows = [], isLoading } = trpc.orcamento.listarEncargos.useQuery(
    { companyId }, { enabled: companyId > 0 }
  );
  const salvarMut = trpc.orcamento.salvarEncargo.useMutation({
    onSuccess: () => utils.orcamento.listarEncargos.invalidate({ companyId }),
  });
  const restaurarMut = trpc.orcamento.restaurarEncargos.useMutation({
    onSuccess: () => {
      utils.orcamento.listarEncargos.invalidate({ companyId });
      utils.orcamento.getParametros.invalidate({ companyId });
    },
  });

  const [editingId, setEditingId] = useState<number | null>(null);
  const [editVal, setEditVal] = useState("");

  const DEFAULT_VALORES: Record<string, number> = {
    A1: 20.00, A2: 8.00,  A3: 2.50,  A4: 1.50,  A5: 1.00,
    A6: 0.20,  A7: 3.00,  A8: 0.60,  A9: 0.00,  A10: 0.00,
    B1: 8.33,  B2: 11.11, B3: 1.94,  B4: 1.39,  B5: 0.00,
    B6: 0.00,  B7: 0.00,  B8: 0.00,  B9: 16.91, B10: 3.13, B11: 1.99,
    C1: 9.12,  C2: 0.33,  C3: 3.20,  C4: 0.00,
    E1: 0.73,  E2: 0.03,  E3: 0.00,
    F1: 0.00,  F2: 0.00,  F3: 0.00,  F4: 0.00,  F5: 0.00,
    F6: 1.17,  F7: 0.00,  F8: 0.00,  F9: 0.00,  F10: 0.00, F11: 0.00,
  };
  const isModified = (codigo: string, valor: string) =>
    Math.abs(parseFloat(valor || '0') - (DEFAULT_VALORES[codigo] ?? 0)) > 0.0001;
  const anyModified = rows.some(r => isModified(r.codigo ?? '', r.valor ?? '0'));

  function startEdit(id: number, val: string) {
    setEditingId(id);
    setEditVal(parseFloat(val || '0').toFixed(2).replace('.', ','));
  }

  function commitEdit(id: number) {
    const v = parseFloat(editVal.replace(',', '.')) || 0;
    salvarMut.mutate({ companyId, id, valor: v.toFixed(4) });
    setEditingId(null);
  }

  const byGrupo = (g: string) => rows.filter(r => r.grupo === g);
  const subTotal = (g: string) => byGrupo(g).reduce((s, r) => s + parseFloat(r.valor || '0'), 0);
  const subA = subTotal('A'), subB = subTotal('B'), subC = subTotal('C');
  const subE = subTotal('E'), subF = subTotal('F');
  const groupD = (subA * subB) / 100;
  const total = subA + subB + subC + groupD + subE + subF;

  const fmtPct = (v: number) => v.toFixed(2).replace('.', ',') + '%';

  function GrupoHeader({ label, descricao, color }: { label: string; descricao: string; color: string }) {
    return (
      <tr className={color}>
        <td className="px-4 py-2 w-12 font-bold text-xs">{label}</td>
        <td className="px-4 py-2 font-bold text-xs" colSpan={2}>{descricao}</td>
        <td className="px-4 py-2 w-36 text-right font-bold text-xs">Mensalistas</td>
      </tr>
    );
  }

  function ItemRows({ grupo }: { grupo: string }) {
    return (
      <>
        {byGrupo(grupo).map(r => {
          const modified = isModified(r.codigo ?? '', r.valor ?? '0');
          return (
            <tr key={r.id} className={`border-b group ${modified ? 'bg-red-50 hover:bg-red-100' : 'hover:bg-slate-50'}`}>
              <td className={`px-4 py-1.5 text-xs font-mono w-12 ${modified ? 'text-red-700 font-semibold' : 'text-slate-500'}`}>
                {r.codigo}
              </td>
              <td className={`px-4 py-1.5 text-xs ${modified ? 'text-red-700' : 'text-slate-800'}`}>
                {r.descricao}
              </td>
              <td className="px-4 py-1.5 w-8" />
              <td className="px-4 py-1.5 text-right w-36">
                {editingId === r.id ? (
                  <input
                    autoFocus
                    className="w-20 border rounded px-1.5 py-0.5 text-xs text-right font-mono focus:outline-none focus:ring-1 focus:ring-blue-400 ml-auto block"
                    value={editVal}
                    onChange={e => setEditVal(e.target.value)}
                    onBlur={() => commitEdit(r.id)}
                    onKeyDown={e => {
                      if (e.key === 'Enter') commitEdit(r.id);
                      if (e.key === 'Escape') setEditingId(null);
                    }}
                  />
                ) : (
                  <button
                    onClick={() => startEdit(r.id, r.valor ?? '0')}
                    className={`text-xs tabular-nums hover:underline cursor-pointer group-hover:font-medium ${modified ? 'text-red-700 font-semibold' : 'text-slate-600 hover:text-blue-600'}`}
                    title="Clique para editar">
                    {fmtPct(parseFloat(r.valor || '0'))}
                  </button>
                )}
              </td>
            </tr>
          );
        })}
      </>
    );
  }

  function SubtotalRow({ label, value, highlight = false }: { label: string; value: number; highlight?: boolean }) {
    return (
      <tr className={highlight ? "bg-yellow-50 border-b border-yellow-200" : "border-b bg-slate-50"}>
        <td className="px-4 py-1.5" colSpan={3}>
          <span className="text-xs font-semibold text-slate-700">{label}</span>
        </td>
        <td className={`px-4 py-1.5 text-right text-xs font-bold tabular-nums ${highlight ? 'text-yellow-700' : 'text-slate-700'}`}>
          {fmtPct(value)}
        </td>
      </tr>
    );
  }

  if (isLoading) return (
    <div className="flex justify-center py-20">
      <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
    </div>
  );

  return (
    <div>
      <div className="mb-5 flex items-start justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-800">Encargos Sociais</h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            Clique em qualquer percentual para editar. O total é aplicado automaticamente nos insumos de mão de obra (Un = h).
          </p>
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={() => {
              if (window.confirm('Restaurar todos os encargos para os valores padrão do sistema? Isso sobrescreverá as alterações feitas.')) {
                restaurarMut.mutate({ companyId });
              }
            }}
            disabled={restaurarMut.isPending}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-500 hover:text-slate-700 border border-slate-200 hover:border-slate-300 rounded-md transition-colors"
            title="Restaurar valores padrão da planilha">
            {restaurarMut.isPending
              ? <Loader2 className="h-3.5 w-3.5 animate-spin" />
              : <RotateCcw className="h-3.5 w-3.5" />}
            Restaurar Padrão
          </button>
          <div className="text-right">
            <div className="text-xs text-slate-500">Total L.S.</div>
            <div className="text-2xl font-bold text-blue-700 tabular-nums">{fmtPct(total)}</div>
          </div>
        </div>
      </div>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            {/* ── GRUPO A ── */}
            <tbody>
              <GrupoHeader label="A" descricao="Encargos Sociais Básicos" color="bg-slate-100 border-b border-slate-200" />
              <ItemRows grupo="A" />
              <SubtotalRow label="Subtotal A" value={subA} highlight />

              {/* ── GRUPO B ── */}
              <GrupoHeader label="B" descricao="Encargos que recebem incidência de A" color="bg-slate-100 border-b border-slate-200" />
              <ItemRows grupo="B" />
              <SubtotalRow label="Subtotal B" value={subB} highlight />

              {/* ── GRUPO C ── */}
              <GrupoHeader label="C" descricao="Encargos ligados à demissão do trabalhador" color="bg-slate-100 border-b border-slate-200" />
              <ItemRows grupo="C" />
              <SubtotalRow label="Subtotal D" value={subC} highlight />

              {/* ── GRUPO D (calculado) ── */}
              <tr className="bg-slate-100 border-b border-slate-200">
                <td className="px-4 py-2 w-12 font-bold text-xs">D</td>
                <td className="px-4 py-2 font-bold text-xs" colSpan={3}>Grupo D = (A×B)</td>
              </tr>
              <tr className="border-b bg-slate-50">
                <td className="px-4 py-1.5 text-xs text-slate-400 font-mono w-12">D</td>
                <td className="px-4 py-1.5 text-xs text-slate-500 italic">
                  Incidência dos encargos do grupo A sobre o grupo B
                  <span className="ml-2 text-[10px] text-slate-400 not-italic">(= {fmtPct(subA)} × {fmtPct(subB)} / 100)</span>
                </td>
                <td className="px-4 py-1.5 w-8" />
                <td className="px-4 py-1.5 text-right text-xs tabular-nums text-slate-500">{fmtPct(groupD)}</td>
              </tr>
              <SubtotalRow label="Subtotal D" value={groupD} highlight />

              {/* ── GRUPO E ── */}
              <GrupoHeader label="E" descricao="Grupo E" color="bg-slate-100 border-b border-slate-200" />
              <ItemRows grupo="E" />
              <SubtotalRow label="Subtotal D'" value={subE} highlight />

              {/* ── GRUPO F ── */}
              <GrupoHeader label="F" descricao="Complementares" color="bg-slate-100 border-b border-slate-200" />
              <ItemRows grupo="F" />
              <SubtotalRow label="Subtotal E" value={subF} highlight />

              {/* ── TOTAL ── */}
              <tr className="bg-blue-700 text-white">
                <td className="px-4 py-3" colSpan={3}>
                  <span className="font-bold text-sm">Total A + B + C + D + D' + E</span>
                </td>
                <td className="px-4 py-3 text-right font-bold text-sm tabular-nums">{fmtPct(total)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </Card>

      <div className="mt-3 flex items-start gap-6 flex-wrap">
        <p className="text-[10px] text-slate-400 flex-1">
          * Grupo D é calculado automaticamente como (Subtotal A × Subtotal B) / 100. Os demais valores são editáveis (clique no percentual).
        </p>
        {anyModified && (
          <div className="flex items-center gap-2 text-[11px] text-red-600 bg-red-50 border border-red-200 rounded px-3 py-1.5">
            <span className="inline-block w-3 h-3 rounded-sm bg-red-200 border border-red-400 flex-shrink-0" />
            Linhas em vermelho indicam valores alterados em relação ao padrão do sistema.
            Use <strong>Restaurar Padrão</strong> para reverter.
          </div>
        )}
      </div>
    </div>
  );
}

/* ════════════════════════════════════════════════════════════════
   PÁGINA PRINCIPAL
   ════════════════════════════════════════════════════════════════ */
export default function BibliotecaOrcamento() {
  const { selectedCompanyId } = useCompany();
  const companyId = selectedCompanyId ? parseInt(selectedCompanyId) : 0;
  const isInsumos   = typeof window !== "undefined" && window.location.pathname.includes("insumos");
  const isEncargos  = typeof window !== "undefined" && window.location.pathname.includes("encargos");
  const [showCategorias, setShowCategorias] = useState(false);
  const [insumoTab, setInsumoTab] = useState<'lista' | 'encargos'>(isEncargos ? 'encargos' : 'lista');

  return (
    <DashboardLayout>
      <div className="p-6 max-w-screen-xl mx-auto">
        {!isInsumos && !isEncargos ? (
          <ComposicoesView companyId={companyId} />
        ) : showCategorias ? (
          <div>
            <button
              onClick={() => setShowCategorias(false)}
              className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-5"
            >
              ← Voltar para Insumos
            </button>
            <CategoriasView companyId={companyId} />
          </div>
        ) : (
          <>
            {/* ── Tab bar ── */}
            <div className="flex gap-1 border-b mb-6">
              <button
                onClick={() => setInsumoTab('lista')}
                className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px transition-colors ${
                  insumoTab === 'lista'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}>
                Insumos
              </button>
              <button
                onClick={() => setInsumoTab('encargos')}
                className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px transition-colors ${
                  insumoTab === 'encargos'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}>
                Encargos Sociais
              </button>
            </div>

            {insumoTab === 'lista' ? (
              <InsumosView companyId={companyId} onGerenciarCategorias={() => setShowCategorias(true)} />
            ) : (
              <EncargosView companyId={companyId} />
            )}
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
