import React, { useState, useMemo } from "react";
import { useLocation } from "wouter";
import DashboardLayout from "@/components/DashboardLayout";
import { DraggableCommandBar } from "@/components/DraggableCommandBar";
import { trpc } from "@/lib/trpc";
import { useCompany } from "@/contexts/CompanyContext";
import { usePermissions } from "@/contexts/PermissionsContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Plus, Search, Loader2, CalendarRange, Building2, User, DollarSign,
  TrendingUp, Clock, CheckCircle2, AlertTriangle, Trash2, Eye, MapPin, ArrowLeft, Pencil,
  Info, FolderPlus, FileText, CheckCircle,
} from "lucide-react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle,
  AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction,
} from "@/components/ui/alert-dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

const n = (v: any) => parseFloat(v || "0") || 0;

function formatBRL(v: number) {
  return v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function statusBadge(status: string) {
  const s = status?.toLowerCase() ?? "";
  if (s.includes("conclu")) return "bg-emerald-100 text-emerald-700";
  if (s.includes("atraso") || s.includes("suspen")) return "bg-red-100 text-red-700";
  if (s.includes("parado")) return "bg-gray-100 text-gray-600";
  return "bg-blue-100 text-blue-700";
}
function statusIcon(status: string) {
  const s = status?.toLowerCase() ?? "";
  if (s.includes("conclu")) return <CheckCircle2 className="h-3.5 w-3.5" />;
  if (s.includes("atraso") || s.includes("suspen")) return <AlertTriangle className="h-3.5 w-3.5" />;
  return <Clock className="h-3.5 w-3.5" />;
}

const STATUS_OPTIONS = [
  "Em andamento", "Concluído", "Suspenso", "Atrasado", "Planejamento",
];

export default function PlanejamentoLista() {
  const [, setLocation] = useLocation();
  const { selectedCompanyId } = useCompany();
  const companyId = selectedCompanyId ? parseInt(selectedCompanyId) : 0;
  const { isAdminMaster, isSensitiveHidden, isSomenteVisualizacao, canCreatePage, canEditPage, canDeletePage } = usePermissions();
  const hideFinancial = !isAdminMaster && isSensitiveHidden("planejamento", "valores_planejamento");
  const canCreate = isAdminMaster || canCreatePage("planejamento", "projetos");
  const canEdit = isAdminMaster || canEditPage("planejamento", "projetos");
  const canDelete = isAdminMaster || canDeletePage("planejamento", "projetos");

  const [busca, setBusca] = useState("");
  const [modalAberto, setModalAberto] = useState(false);
  const [excluindo, setExcluindo] = useState<number | null>(null);
  const [confirmExclusao, setConfirmExclusao] = useState<{ id: number; nome: string; cliente?: string | null } | null>(null);

  // Formulário novo projeto
  const [form, setForm] = useState({
    obraId: "",
    status: "Em andamento",
    descricao: "",
  });

  // Edição de projeto existente
  const [editandoProjeto, setEditandoProjeto] = useState<any | null>(null);
  const [formEdit, setFormEdit] = useState({
    nome: "",
    cliente: "",
    local: "",
    responsavel: "",
    dataInicio: "",
    dataTerminoContratual: "",
    valorContrato: "",
    status: "Em andamento",
    descricao: "",
  });

  function abrirEdicao(proj: any) {
    const obraVinculada = (obras as any[]).find((o: any) => o.id === proj.obraId);
    setFormEdit({
      nome:                  proj.nome ?? "",
      cliente:               proj.cliente || obraVinculada?.cliente || "",
      local:                 proj.local || (obraVinculada
                               ? [
                                   obraVinculada.endereco,
                                   [obraVinculada.cidade, obraVinculada.estado].filter(Boolean).join(" / "),
                                 ].filter(Boolean).join(", ")
                               : ""),
      responsavel:           proj.responsavel || obraVinculada?.responsavel || "",
      dataInicio:            proj.dataInicio ?? "",
      dataTerminoContratual: proj.dataTerminoContratual ?? "",
      valorContrato:         proj.valorContrato ? String(n(proj.valorContrato)) : (obraVinculada?.valorContrato ? String(n(obraVinculada.valorContrato)) : ""),
      status:                proj.status ?? "Em andamento",
      descricao:             proj.descricao ?? "",
    });
    setEditandoProjeto(proj);
  }

  const utils = trpc.useUtils();
  const { data: projetos = [], isLoading } = trpc.planejamento.listarProjetos.useQuery(
    { companyId }, { enabled: !!companyId }
  );
  const { data: obras = [] } = trpc.obras.list.useQuery(
    { companyId }, { enabled: !!companyId }
  );
  const { data: orcamentos = [] } = trpc.orcamento.list.useQuery(
    { companyId }, { enabled: !!companyId }
  );

  // Obras que já possuem planejamento — filtradas do select
  const obraIdsComPlanejamento = useMemo(() =>
    new Set((projetos as any[]).map((p: any) => p.obraId).filter(Boolean)),
  [projetos]);

  // Apenas obras que possuem orçamento cadastrado
  const obraIdsComOrcamento = useMemo(() =>
    new Set((orcamentos as any[]).map((o: any) => o.obraId).filter(Boolean)),
  [orcamentos]);

  const obrasDisponiveis = useMemo(() =>
    (obras as any[]).filter((o: any) =>
      !obraIdsComPlanejamento.has(o.id) && obraIdsComOrcamento.has(o.id)
    ),
  [obras, obraIdsComPlanejamento, obraIdsComOrcamento]);

  const obraSelecionada = useMemo(() =>
    (obras as any[]).find((o: any) => String(o.id) === form.obraId) ?? null,
  [obras, form.obraId]);

  // Orçamento vinculado automaticamente pela obra selecionada
  const orcamentoAutoVinculado = useMemo(() => {
    if (!obraSelecionada) return null;
    return (orcamentos as any[]).find((o: any) => o.obraId === obraSelecionada.id) ?? null;
  }, [orcamentos, obraSelecionada]);

  const criarMutation = trpc.planejamento.criarProjeto.useMutation({
    onSuccess: () => { utils.planejamento.listarProjetos.invalidate(); setModalAberto(false); resetForm(); },
    onError: (err) => { alert(err.message || "Erro ao criar planejamento."); },
  });
  const excluirMutation = trpc.planejamento.excluirProjeto.useMutation({
    onSuccess: () => { utils.planejamento.listarProjetos.invalidate(); setExcluindo(null); setConfirmExclusao(null); },
    onError: (err) => { alert(err.message || "Erro ao excluir o projeto."); setConfirmExclusao(null); },
  });

  const editarMutation = trpc.planejamento.atualizarProjeto.useMutation({
    onSuccess: () => { utils.planejamento.listarProjetos.invalidate(); setEditandoProjeto(null); },
    onError: (err) => { alert(err.message || "Erro ao salvar as alterações."); },
  });

  function handleEditar() {
    if (!editandoProjeto) return;
    editarMutation.mutate({
      id:                    editandoProjeto.id,
      nome:                  formEdit.nome || undefined,
      cliente:               formEdit.cliente || undefined,
      local:                 formEdit.local || undefined,
      responsavel:           formEdit.responsavel || undefined,
      dataInicio:            formEdit.dataInicio || undefined,
      dataTerminoContratual: formEdit.dataTerminoContratual || undefined,
      valorContrato:         formEdit.valorContrato ? n(formEdit.valorContrato) : undefined,
      status:                formEdit.status || undefined,
      descricao:             formEdit.descricao || undefined,
    });
  }

  function resetForm() {
    setForm({ obraId: "", status: "Em andamento", descricao: "" });
  }

  function handleCriar() {
    if (!obraSelecionada) return;
    const local = [obraSelecionada.cidade, obraSelecionada.estado].filter(Boolean).join(" / ")
      || obraSelecionada.endereco || undefined;
    criarMutation.mutate({
      companyId,
      obraId:                obraSelecionada.id,
      nome:                  obraSelecionada.nome,
      cliente:               obraSelecionada.cliente || undefined,
      local:                 local,
      responsavel:           obraSelecionada.responsavel || undefined,
      dataInicio:            obraSelecionada.dataInicio || undefined,
      dataTerminoContratual: obraSelecionada.dataPrevisaoFim || undefined,
      valorContrato:         obraSelecionada.valorContrato ? parseFloat(obraSelecionada.valorContrato) : undefined,
      status:                form.status,
      descricao:             form.descricao || undefined,
      orcamentoId:           orcamentoAutoVinculado?.id ?? undefined,
    });
  }

  const filtrados = projetos.filter(p =>
    [p.nome, p.cliente, p.local, p.responsavel].some(v =>
      v?.toLowerCase().includes(busca.toLowerCase())
    )
  );

  return (
    <DashboardLayout>
      <div className="p-5">
        {/* Cabeçalho */}
        <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
          <div className="flex items-center gap-3">
            <Button
              variant="outline" size="sm"
              className="gap-1.5 text-slate-600"
              onClick={() => window.history.back()}
            >
              <ArrowLeft className="h-4 w-4" />
              Voltar
            </Button>
            <div>
              <h1 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                <CalendarRange className="h-5 w-5 text-blue-600" />
                Planejamento de Obras
              </h1>
              <p className="text-xs text-slate-500 mt-0.5">
                Cronograma · Curva S · REFIS · Controle de Avanço
              </p>
            </div>
          </div>
          <DraggableCommandBar barId="planejamento-lista" items={[
            ...(canCreate ? [{ id: "novo-projeto", node: <Button onClick={() => setModalAberto(true)} className="gap-2 bg-blue-600 hover:bg-blue-700"><Plus className="h-4 w-4" /> Novo Projeto</Button> }] : []),
          ]} />
        </div>

        {/* KPIs rápidos */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
          {[
            { label: "Total de Projetos", value: projetos.length, icon: <Building2 className="h-4 w-4" />, color: "text-blue-600", bg: "bg-blue-50" },
            { label: "Em Andamento", value: projetos.filter(p => p.status?.toLowerCase().replace(/_/g, " ").includes("andamento")).length, icon: <TrendingUp className="h-4 w-4" />, color: "text-emerald-600", bg: "bg-emerald-50" },
            { label: "Com Atraso", value: projetos.filter(p => {
              const st = (p.status || "").toLowerCase().replace(/_/g, " ");
              if (st.includes("conclu")) return false;
              const prazo = p.dataTerminoContratual;
              if (!prazo) return false;
              const hoje = new Date().toISOString().split("T")[0];
              return String(prazo).slice(0, 10) < hoje;
            }).length, icon: <AlertTriangle className="h-4 w-4" />, color: "text-red-600", bg: "bg-red-50" },
            ...(!hideFinancial ? [{ label: "Valor Total", value: formatBRL(projetos.reduce((s, p) => s + (n(p.valorContrato) || n((p as any).orcamentoValorNegociado) || n((p as any).orcamentoTotalVenda)), 0)), icon: <DollarSign className="h-4 w-4" />, color: "text-purple-600", bg: "bg-purple-50" }] : []),
          ].map((k, i) => (
            <div key={i} className="bg-white rounded-xl border border-slate-100 shadow-sm p-3 flex items-start gap-3">
              <div className={`w-8 h-8 rounded-lg ${k.bg} ${k.color} flex items-center justify-center shrink-0`}>
                {k.icon}
              </div>
              <div>
                <p className="text-[10px] text-slate-500 leading-tight">{k.label}</p>
                <p className={`text-base font-bold ${k.color} leading-tight mt-0.5`}>{k.value}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Busca */}
        <div className="relative mb-4 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input
            placeholder="Buscar projeto, cliente, local..."
            value={busca}
            onChange={e => setBusca(e.target.value)}
            className="pl-9 text-sm"
          />
        </div>

        {/* Lista */}
        {isLoading ? (
          <div className="flex items-center justify-center py-20 gap-2 text-slate-400">
            <Loader2 className="h-5 w-5 animate-spin" />
            <span>Carregando projetos...</span>
          </div>
        ) : filtrados.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-slate-400 gap-3">
            <CalendarRange className="h-10 w-10 opacity-30" />
            <p className="text-sm font-medium">Nenhum projeto de planejamento encontrado</p>
            <Button variant="outline" size="sm" onClick={() => setModalAberto(true)} className="gap-1.5">
              <Plus className="h-3.5 w-3.5" /> Criar primeiro projeto
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {filtrados.map(projeto => (
              <div key={projeto.id}
                className="bg-white rounded-xl border border-slate-100 shadow-sm hover:shadow-md hover:border-blue-200 transition-all cursor-pointer group"
                onClick={() => setLocation(`/planejamento/${projeto.id}`)}
              >
                <div className="p-4">
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <h3 className="font-semibold text-slate-800 text-sm leading-tight line-clamp-2 flex-1">
                      {projeto.nome}
                    </h3>
                    <span className={`inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded-full shrink-0 ${statusBadge(projeto.status ?? "")}`}>
                      {statusIcon(projeto.status ?? "")}
                      {projeto.status}
                    </span>
                  </div>

                  <div className="space-y-1.5 text-xs text-slate-500">
                    {projeto.cliente && (
                      <div className="flex items-center gap-1.5">
                        <Building2 className="h-3.5 w-3.5 shrink-0" />
                        <span className="truncate">{projeto.cliente}</span>
                      </div>
                    )}
                    {projeto.responsavel && (
                      <div className="flex items-center gap-1.5">
                        <User className="h-3.5 w-3.5 shrink-0" />
                        <span className="truncate">{projeto.responsavel}</span>
                      </div>
                    )}
                    {(projeto.dataInicio || projeto.dataTerminoContratual) && (
                      <div className="flex items-center gap-1.5">
                        <CalendarRange className="h-3.5 w-3.5 shrink-0" />
                        <span>
                          {projeto.dataInicio ?? "—"} → {projeto.dataTerminoContratual ?? "—"}
                        </span>
                      </div>
                    )}
                    {!hideFinancial && (n(projeto.valorContrato) > 0 || n((projeto as any).orcamentoValorNegociado) > 0 || n((projeto as any).orcamentoTotalVenda) > 0) && (
                      <div className="flex items-center gap-1.5 font-semibold text-emerald-700">
                        <DollarSign className="h-3.5 w-3.5 shrink-0" />
                        <span>{formatBRL(n(projeto.valorContrato) || n((projeto as any).orcamentoValorNegociado) || n((projeto as any).orcamentoTotalVenda))}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="border-t border-slate-100 px-4 py-2 flex items-center justify-between">
                  <span className="text-[10px] text-slate-400">
                    Criado {new Date(projeto.criadoEm ?? "").toLocaleDateString("pt-BR")}
                  </span>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={e => { e.stopPropagation(); setLocation(`/planejamento/${projeto.id}`); }}
                      className="p-1 rounded hover:bg-blue-50 text-blue-500"
                      title="Abrir"
                    >
                      <Eye className="h-3.5 w-3.5" />
                    </button>
                    {canEdit && (
                    <button
                      onClick={e => { e.stopPropagation(); abrirEdicao(projeto); }}
                      className="p-1 rounded hover:bg-amber-50 text-amber-500"
                      title="Editar"
                    >
                      <Pencil className="h-3.5 w-3.5" />
                    </button>
                    )}
                    {canDelete && (
                    <button
                      onClick={e => { e.stopPropagation(); setConfirmExclusao({ id: projeto.id, nome: projeto.nome, cliente: projeto.cliente }); }}
                      className="p-1 rounded hover:bg-red-50 text-red-400"
                      title="Excluir"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ── Modal Editar Projeto ──────────────────────────────────────────── */}
        <Dialog open={!!editandoProjeto} onOpenChange={open => { if (!open) setEditandoProjeto(null); }}>
          <DialogContent className="max-w-lg" style={{ background: "#ffffff", color: "#111827" }}>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Pencil className="h-4 w-4 text-amber-500" />
                Editar Projeto
              </DialogTitle>
            </DialogHeader>

            <div className="grid grid-cols-1 gap-4 mt-1">
              {/* Nome */}
              <div>
                <Label className="text-xs font-medium">Nome do Projeto</Label>
                <Input
                  value={formEdit.nome}
                  onChange={e => setFormEdit(f => ({ ...f, nome: e.target.value }))}
                  className="mt-1 text-sm"
                />
              </div>

              {/* Cliente + Responsável */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs font-medium">Cliente</Label>
                  <Input
                    value={formEdit.cliente}
                    onChange={e => setFormEdit(f => ({ ...f, cliente: e.target.value }))}
                    className="mt-1 text-sm"
                    placeholder="Nome do cliente"
                  />
                </div>
                <div>
                  <Label className="text-xs font-medium">Responsável</Label>
                  <Input
                    value={formEdit.responsavel}
                    onChange={e => setFormEdit(f => ({ ...f, responsavel: e.target.value }))}
                    className="mt-1 text-sm"
                    placeholder="Engenheiro responsável"
                  />
                </div>
              </div>

              {/* Local */}
              <div>
                <Label className="text-xs font-medium">Local / Endereço</Label>
                <Input
                  value={formEdit.local}
                  onChange={e => setFormEdit(f => ({ ...f, local: e.target.value }))}
                  className="mt-1 text-sm"
                  placeholder="Cidade / Estado ou endereço"
                />
              </div>

              {/* Datas */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs font-medium">Data de Início</Label>
                  <Input
                    type="date"
                    value={formEdit.dataInicio}
                    onChange={e => setFormEdit(f => ({ ...f, dataInicio: e.target.value }))}
                    className="mt-1 text-sm"
                  />
                </div>
                <div>
                  <Label className="text-xs font-medium">Término Contratual</Label>
                  <Input
                    type="date"
                    value={formEdit.dataTerminoContratual}
                    onChange={e => setFormEdit(f => ({ ...f, dataTerminoContratual: e.target.value }))}
                    className="mt-1 text-sm"
                  />
                </div>
              </div>

              {/* Valor do contrato + Status */}
              <div className={`grid ${hideFinancial ? 'grid-cols-1' : 'grid-cols-2'} gap-3`}>
                {!hideFinancial && (
                <div>
                  <Label className="text-xs font-medium">Valor do Contrato (R$)</Label>
                  <Input
                    type="number"
                    min={0}
                    step={0.01}
                    value={formEdit.valorContrato}
                    onChange={e => setFormEdit(f => ({ ...f, valorContrato: e.target.value }))}
                    className="mt-1 text-sm"
                    placeholder="0,00"
                  />
                </div>
                )}
                <div>
                  <Label className="text-xs font-medium">Status da Obra</Label>
                  <select
                    value={formEdit.status}
                    onChange={e => setFormEdit(f => ({ ...f, status: e.target.value }))}
                    className="mt-1 w-full border border-input rounded-md px-3 py-2 text-sm bg-background"
                  >
                    {STATUS_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>

              {/* Observações */}
              <div>
                <Label className="text-xs font-medium">Observações</Label>
                <textarea
                  value={formEdit.descricao}
                  onChange={e => setFormEdit(f => ({ ...f, descricao: e.target.value }))}
                  placeholder="Informações adicionais..."
                  className="mt-1 w-full border border-input rounded-md px-3 py-2 text-sm bg-background resize-none"
                  rows={2}
                />
              </div>

              <div className="flex gap-2 justify-end pt-1">
                <Button variant="outline" onClick={() => setEditandoProjeto(null)}>Cancelar</Button>
                <Button
                  disabled={!formEdit.nome || editarMutation.isPending}
                  onClick={handleEditar}
                  className="bg-amber-600 hover:bg-amber-700"
                >
                  {editarMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Salvar Alterações"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* ───────────────────────────────────────────────────────────────
            Modal novo projeto — Rev. 2428
            Identidade FC (faixa #1B2A4A no header), shadcn Select/Textarea,
            min-w-0 estratégico (mata scroll horizontal causado por nomes
            longos de obra), DialogFooter separado com border-t.
            ─────────────────────────────────────────────────────────────── */}
        <Dialog open={modalAberto} onOpenChange={open => { setModalAberto(open); if (!open) resetForm(); }}>
          <DialogContent className="max-w-lg p-0 gap-0 overflow-hidden">
            {/* Faixa azul FC */}
            <div
              className="flex items-center gap-3 px-6 py-4 border-b border-[#0f1a30]"
              style={{
                background: "linear-gradient(135deg, #1B2A4A 0%, #243456 100%)",
                printColorAdjust: "exact",
              }}
            >
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-white/10 border border-white/15">
                <FolderPlus className="h-5 w-5 text-white" />
              </div>
              <div className="min-w-0">
                <DialogTitle className="text-white text-base font-semibold leading-tight tracking-wide">
                  Novo Projeto de Planejamento
                </DialogTitle>
                <p className="text-[11px] text-white/60 mt-0.5 tracking-wider uppercase">
                  Cronograma · Curva S · REFIS · Controle de Avanço
                </p>
              </div>
            </div>

            {/* Body */}
            <div className="px-6 py-5 space-y-4 max-h-[70vh] overflow-y-auto">

              {obrasDisponiveis.length === 0 && (
                <div className="flex gap-2.5 rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800">
                  <Info className="h-4 w-4 shrink-0 text-amber-500 mt-0.5" />
                  <div className="min-w-0">
                    <p className="font-semibold mb-0.5">Nenhuma obra disponível para planejamento</p>
                    <p className="text-amber-700 leading-relaxed">
                      Para criar um planejamento, a obra precisa ter um <strong>orçamento cadastrado e vinculado</strong>.
                      Acesse <strong>Orçamento</strong> no menu, cadastre o orçamento da obra e volte aqui.
                    </p>
                  </div>
                </div>
              )}

              {/* Seleção da Obra */}
              <div className="space-y-1.5 min-w-0">
                <Label className="text-xs font-semibold text-slate-700 uppercase tracking-wide">
                  Selecionar Obra <span className="text-red-500">*</span>
                </Label>
                <Select
                  value={form.obraId}
                  onValueChange={v => setForm(f => ({ ...f, obraId: v }))}
                  disabled={obrasDisponiveis.length === 0}
                >
                  <SelectTrigger className="w-full min-w-0 h-10 bg-white">
                    <SelectValue placeholder="— Selecione uma obra —" className="truncate" />
                  </SelectTrigger>
                  <SelectContent className="max-w-[min(28rem,var(--radix-select-content-available-width))]">
                    {obrasDisponiveis.map((o: any) => (
                      <SelectItem key={o.id} value={String(o.id)} className="items-start">
                        <span className="block min-w-0 whitespace-normal break-words leading-snug">
                          <span className="font-medium">{o.nome}</span>
                          {o.cliente ? <span className="text-muted-foreground"> · {o.cliente}</span> : null}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Preview dos dados da obra selecionada */}
              {obraSelecionada && (
                <div
                  className="rounded-lg border border-slate-200 p-3.5 space-y-2 text-xs text-slate-700 min-w-0"
                  style={{ background: "linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%)" }}
                >
                  {obraSelecionada.cliente && (
                    <div className="flex items-center gap-2 min-w-0">
                      <Building2 className="h-3.5 w-3.5 text-[#1B2A4A] shrink-0" />
                      <span className="truncate">{obraSelecionada.cliente}</span>
                    </div>
                  )}
                  {obraSelecionada.responsavel && (
                    <div className="flex items-center gap-2 min-w-0">
                      <User className="h-3.5 w-3.5 text-[#1B2A4A] shrink-0" />
                      <span className="truncate">{obraSelecionada.responsavel}</span>
                    </div>
                  )}
                  {(obraSelecionada.cidade || obraSelecionada.estado || obraSelecionada.endereco) && (
                    <div className="flex items-center gap-2 min-w-0">
                      <MapPin className="h-3.5 w-3.5 text-[#1B2A4A] shrink-0" />
                      <span className="truncate">
                        {[obraSelecionada.cidade, obraSelecionada.estado].filter(Boolean).join(" / ")
                          || obraSelecionada.endereco}
                      </span>
                    </div>
                  )}
                  {(obraSelecionada.dataInicio || obraSelecionada.dataPrevisaoFim) && (
                    <div className="flex items-center gap-2 min-w-0">
                      <CalendarRange className="h-3.5 w-3.5 text-[#1B2A4A] shrink-0" />
                      <span className="truncate">
                        {obraSelecionada.dataInicio ?? "—"} → {obraSelecionada.dataPrevisaoFim ?? "—"}
                      </span>
                    </div>
                  )}
                  {!hideFinancial && obraSelecionada.valorContrato && n(obraSelecionada.valorContrato) > 0 && (
                    <div className="flex items-center gap-2 min-w-0 pt-1.5 border-t border-slate-200/70">
                      <DollarSign className="h-3.5 w-3.5 text-emerald-600 shrink-0" />
                      <span className="font-semibold text-emerald-700">
                        {formatBRL(n(obraSelecionada.valorContrato))}
                      </span>
                    </div>
                  )}
                </div>
              )}

              {/* Orçamento auto-vinculado + Status */}
              <div className="grid grid-cols-2 gap-3 min-w-0">
                <div className="space-y-1.5 min-w-0">
                  <Label className="text-xs font-semibold text-slate-700 uppercase tracking-wide">
                    Orçamento vinculado
                  </Label>
                  <div className={`h-10 w-full border rounded-md px-3 flex items-center gap-2 text-xs min-w-0 ${
                    orcamentoAutoVinculado
                      ? "border-emerald-300 bg-emerald-50 text-emerald-800"
                      : "border-slate-200 bg-slate-50 text-slate-400 italic"
                  }`}>
                    {orcamentoAutoVinculado
                      ? <CheckCircle className="h-3.5 w-3.5 text-emerald-600 shrink-0" />
                      : <FileText className="h-3.5 w-3.5 text-slate-300 shrink-0" />}
                    <span className="truncate font-medium">
                      {orcamentoAutoVinculado
                        ? (orcamentoAutoVinculado.descricao ?? orcamentoAutoVinculado.codigo ?? `#${orcamentoAutoVinculado.id}`)
                        : "Nenhum orçamento"}
                    </span>
                  </div>
                </div>
                <div className="space-y-1.5 min-w-0">
                  <Label className="text-xs font-semibold text-slate-700 uppercase tracking-wide">
                    Status
                  </Label>
                  <Select
                    value={form.status}
                    onValueChange={v => setForm(f => ({ ...f, status: v }))}
                  >
                    <SelectTrigger className="w-full h-10 bg-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {STATUS_OPTIONS.map(s => (
                        <SelectItem key={s} value={s}>{s}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Observações */}
              <div className="space-y-1.5 min-w-0">
                <Label className="text-xs font-semibold text-slate-700 uppercase tracking-wide">
                  Observações <span className="font-normal text-slate-400 normal-case">(opcional)</span>
                </Label>
                <Textarea
                  value={form.descricao}
                  onChange={e => setForm(f => ({ ...f, descricao: e.target.value }))}
                  placeholder="Informações adicionais sobre o projeto..."
                  className="resize-none text-sm bg-white"
                  rows={2}
                />
              </div>
            </div>

            {/* Footer */}
            <DialogFooter className="px-6 py-4 border-t border-slate-200 bg-slate-50/60 gap-2 sm:gap-2">
              <Button
                variant="outline"
                onClick={() => { setModalAberto(false); resetForm(); }}
                disabled={criarMutation.isPending}
              >
                Cancelar
              </Button>
              <Button
                disabled={!form.obraId || criarMutation.isPending}
                onClick={handleCriar}
                className="bg-[#1B2A4A] hover:bg-[#243456] text-white gap-2 min-w-[130px]"
              >
                {criarMutation.isPending
                  ? <><Loader2 className="h-4 w-4 animate-spin" /> Criando...</>
                  : <><FolderPlus className="h-4 w-4" /> Criar Projeto</>}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* ── AlertDialog Excluir Projeto (substitui window.confirm nativo) ── */}
        <AlertDialog
          open={!!confirmExclusao}
          onOpenChange={(open) => { if (!open && !excluirMutation.isPending) setConfirmExclusao(null); }}
        >
          <AlertDialogContent className="max-w-md">
            <AlertDialogHeader>
              <AlertDialogTitle className="flex items-center gap-2 text-red-600">
                <AlertTriangle className="h-5 w-5" />
                Excluir projeto
              </AlertDialogTitle>
              <AlertDialogDescription asChild>
                <div className="space-y-3 pt-1 text-sm text-slate-600">
                  <p>
                    Tem certeza de que deseja excluir o projeto{" "}
                    <span className="font-semibold text-slate-900">"{confirmExclusao?.nome}"</span>
                    {confirmExclusao?.cliente ? <> — <span className="text-slate-700">{confirmExclusao.cliente}</span></> : null}?
                  </p>
                  <div className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
                    <strong>Atenção:</strong> esta ação remove permanentemente o cronograma, curva S, REFIS e demais dados vinculados ao projeto. <span className="font-semibold">Não pode ser desfeita.</span>
                  </div>
                </div>
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={excluirMutation.isPending}>Cancelar</AlertDialogCancel>
              <AlertDialogAction
                onClick={(e) => {
                  e.preventDefault();
                  if (confirmExclusao) excluirMutation.mutate({ id: confirmExclusao.id });
                }}
                disabled={excluirMutation.isPending}
                className="bg-red-600 hover:bg-red-700 focus:ring-red-600"
              >
                {excluirMutation.isPending
                  ? <><Loader2 className="h-4 w-4 animate-spin mr-2" />Excluindo...</>
                  : <><Trash2 className="h-4 w-4 mr-2" />Excluir projeto</>}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </DashboardLayout>
  );
}
