import { useState, useMemo, useRef, useCallback, useEffect } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import FullScreenDialog from "@/components/FullScreenDialog";
import PrintFooterLGPD from "@/components/PrintFooterLGPD";
import RaioXFuncionario from "@/components/RaioXFuncionario";
import { PersonPhoto } from "@/components/PersonPhoto";
import { trpc } from "@/lib/trpc";
import { useCompany } from "@/contexts/CompanyContext";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { fmtNum } from "@/lib/formatters";
import {
  AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle,
  AlertDialogDescription, AlertDialogFooter, AlertDialogCancel,
} from "@/components/ui/alert-dialog";
import {
  Clock, Plus, CheckCircle, CheckCircle2, XCircle, AlertTriangle, Send,
  Calendar, Users, Building2, FileText, Loader2, Eye, RotateCcw, MessageSquare, Trash2, History, Ban,
  TrendingUp, DollarSign, HardHat, Search, X, PenTool, UserCheck, UserX, ClipboardCheck, SquarePen,
  ShieldAlert, Camera, Video, Upload,
} from "lucide-react";

type TabType = "solicitar" | "aprovacoes" | "historico";

const STATUS_COLORS: Record<string, string> = {
  pendente: "bg-yellow-100 text-yellow-800 border-yellow-300",
  aprovada: "bg-green-100 text-green-800 border-green-300",
  rejeitada: "bg-red-100 text-red-800 border-red-300",
  cancelada: "bg-gray-100 text-gray-800 border-gray-300",
};

const STATUS_LABELS: Record<string, string> = {
  pendente: "Pendente",
  aprovada: "Aprovada",
  rejeitada: "Rejeitada",
  cancelada: "Cancelada",
};

function SignatureModal({ open, onClose, employeeName, solicitacao, onConfirm, isPending }: {
  open: boolean;
  onClose: () => void;
  employeeName: string;
  solicitacao: any;
  onConfirm: (base64: string) => void;
  isPending: boolean;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasDrawn, setHasDrawn] = useState(false);

  const getCtx = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    return canvas.getContext("2d");
  }, []);

  const initCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * 2;
    canvas.height = rect.height * 2;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.scale(2, 2);
    ctx.strokeStyle = "#1a1a2e";
    ctx.lineWidth = 2.5;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, rect.width, rect.height);
  }, []);

  useEffect(() => {
    if (open) {
      setTimeout(initCanvas, 100);
      setHasDrawn(false);
    }
  }, [open, initCanvas]);

  const getPos = useCallback((e: React.TouchEvent | React.MouseEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    if ("touches" in e && e.touches.length > 0) {
      return { x: e.touches[0].clientX - rect.left, y: e.touches[0].clientY - rect.top };
    }
    const me = e as React.MouseEvent;
    return { x: me.clientX - rect.left, y: me.clientY - rect.top };
  }, []);

  const startDraw = useCallback((e: React.TouchEvent | React.MouseEvent) => {
    e.preventDefault();
    const ctx = getCtx();
    if (!ctx) return;
    const pos = getPos(e);
    ctx.beginPath();
    ctx.moveTo(pos.x, pos.y);
    setIsDrawing(true);
    setHasDrawn(true);
  }, [getCtx, getPos]);

  const draw = useCallback((e: React.TouchEvent | React.MouseEvent) => {
    if (!isDrawing) return;
    e.preventDefault();
    const ctx = getCtx();
    if (!ctx) return;
    const pos = getPos(e);
    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();
  }, [isDrawing, getCtx, getPos]);

  const endDraw = useCallback(() => { setIsDrawing(false); }, []);

  const clearCanvas = useCallback(() => {
    initCanvas();
    setHasDrawn(false);
  }, [initCanvas]);

  const handleConfirm = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !hasDrawn) return;
    const dataUrl = canvas.toDataURL("image/png");
    onConfirm(dataUrl);
  }, [hasDrawn, onConfirm]);

  if (!open) return null;

  const sol = solicitacao;
  const dataFormatada = sol.dataSolicitacao
    ? new Date(sol.dataSolicitacao + "T12:00:00").toLocaleDateString("pt-BR", { weekday: "long", day: "2-digit", month: "long", year: "numeric" })
    : "-";

  return (
    <div className="fixed inset-0 z-[200] bg-white flex flex-col">
      <div className="bg-gradient-to-r from-blue-700 to-blue-900 text-white px-4 py-3 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-3">
          <PenTool className="h-5 w-5" />
          <div>
            <p className="text-sm font-bold">Confirmação de Presença — Hora Extra</p>
            <p className="text-xs opacity-80">FC Engenharia</p>
          </div>
        </div>
        <button onClick={onClose} className="text-white/80 hover:text-white p-1">
          <X className="h-5 w-5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4 max-w-lg mx-auto w-full">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 space-y-1">
          <p className="text-sm font-bold text-blue-900">Dados da Hora Extra</p>
          <p className="text-xs text-blue-800"><strong>Data:</strong> {dataFormatada}</p>
          <p className="text-xs text-blue-800"><strong>Horário:</strong> {sol.horaInicio || "?"} às {sol.horaFim || "?"}</p>
          <p className="text-xs text-blue-800"><strong>Motivo:</strong> {sol.motivo || "-"}</p>
          {sol.obraNome && <p className="text-xs text-blue-800"><strong>Obra:</strong> {sol.obraNome}</p>}
        </div>

        <div className="bg-gray-50 border border-gray-200 rounded-lg p-3">
          <p className="text-sm font-bold text-gray-900 mb-1">Funcionário</p>
          <p className="text-lg font-bold">{employeeName}</p>
        </div>

        <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
          <p className="text-xs text-amber-900 font-medium leading-relaxed">
            Eu, <strong>{employeeName}</strong>, declaro estar ciente da convocação para realização de horas extras
            na data e horário acima informados, conforme Art. 59 da CLT e Acordo Coletivo de Trabalho vigente.
            Comprometo-me a comparecer ao local de trabalho no horário determinado.
          </p>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-sm font-bold text-gray-700">Assinatura Digital</p>
            <button
              onClick={clearCanvas}
              className="text-xs text-blue-600 hover:underline flex items-center gap-1"
            >
              <RotateCcw className="h-3 w-3" /> Limpar
            </button>
          </div>
          <div className="border-2 border-dashed border-gray-300 rounded-lg overflow-hidden bg-white" style={{ touchAction: "none" }}>
            <canvas
              ref={canvasRef}
              className="w-full cursor-crosshair"
              style={{ height: "180px" }}
              onMouseDown={startDraw}
              onMouseMove={draw}
              onMouseUp={endDraw}
              onMouseLeave={endDraw}
              onTouchStart={startDraw}
              onTouchMove={draw}
              onTouchEnd={endDraw}
            />
          </div>
          {!hasDrawn && (
            <p className="text-xs text-center text-muted-foreground">Assine acima com o dedo ou caneta stylus</p>
          )}
        </div>
      </div>

      <div className="border-t bg-gray-50 px-4 py-3 flex gap-3 max-w-lg mx-auto w-full">
        <Button variant="outline" className="flex-1" onClick={onClose} disabled={isPending}>
          Cancelar
        </Button>
        <Button
          className="flex-1 bg-green-600 hover:bg-green-700"
          disabled={!hasDrawn || isPending}
          onClick={handleConfirm}
        >
          {isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <CheckCircle className="h-4 w-4 mr-2" />}
          Confirmar Presença
        </Button>
      </div>

      <div className="bg-gray-100 px-4 py-2 text-center">
        <p className="text-[10px] text-muted-foreground">
          Registro eletrônico protegido pela LGPD (Lei nº 13.709/2018). Data/hora e IP armazenados para validade jurídica.
        </p>
      </div>
    </div>
  );
}

export default function SolicitacaoHE() {
  const { selectedCompanyId, isConstrutoras, getCompanyIdsForQuery} = useCompany();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<TabType>("solicitar");
  const [filterStatus, setFilterStatus] = useState<string>("todas");
  const [filterMes, setFilterMes] = useState<string>("");
  const [raioXEmployeeId, setRaioXEmployeeId] = useState<number | null>(null);
  const [heHistoryEmployeeId, setHeHistoryEmployeeId] = useState<number | null>(null);
  const [heHistoryEmployeeName, setHeHistoryEmployeeName] = useState<string>("");
  const [detailSolId, setDetailSolId] = useState<number | null>(null);
  const [adminObs, setAdminObs] = useState("");
  const [rejectReason, setRejectReason] = useState("");
  const [showRejectForm, setShowRejectForm] = useState(false);
  const [buscaAtividade, setBuscaAtividade] = useState("");

  // Form state
  const [formData, setFormData] = useState({
    obraId: "",
    planejamentoAtividadeIds: [] as string[],
    dataSolicitacao: "",
    horaInicio: "",
    horaFim: "",
    motivo: "",
    observacoes: "",
    funcionarioIds: [] as number[],
  });

  const companyId = selectedCompanyId ? parseInt(selectedCompanyId, 10) || 0 : 0;
  const companyIds = getCompanyIdsForQuery();

  // Queries
  const obrasQuery = trpc.obras.listActive.useQuery(
    { companyId },
    { enabled: companyId > 0 || companyIds.length > 0 }
  );
  const atividadesQuery = trpc.planejamento.getAtividadesForObra.useQuery(
    { obraId: formData.obraId ? parseInt(formData.obraId) : 0 },
    { enabled: !!formData.obraId }
  );
  const employeesQuery = trpc.employees.list.useQuery(
    { companyId, excludeTerminated: true },
    { enabled: companyId > 0 || companyIds.length > 0 }
  );
  const listQuery = trpc.heSolicitacoes.list.useQuery(
    { companyId, status: filterStatus as any, mesReferencia: filterMes || undefined },
    { enabled: companyId > 0 || companyIds.length > 0 }
  );
  // Query separada para pendentes SEM filtro de mês (para aba Aprovações)
  const pendentesQuery = trpc.heSolicitacoes.list.useQuery(
    { companyId, status: "pendente" as any },
    { enabled: companyId > 0 || companyIds.length > 0 }
  );
  const countsQuery = trpc.heSolicitacoes.counts.useQuery(
    { companyId },
    { enabled: companyId > 0 || companyIds.length > 0 }
  );
  const avisoPrevioQuery = trpc.heSolicitacoes.empregadosEmAvisoPrevio.useQuery(
    { companyId },
    { enabled: companyId > 0 }
  );
  const heHistoryQuery = trpc.heSolicitacoes.historyByEmployee.useQuery(
    { companyId, employeeId: heHistoryEmployeeId! },
    { enabled: !!heHistoryEmployeeId && companyId > 0 }
  );

  const utils = trpc.useUtils();

  // Rev. 1271 — Marca as solicitações de HE como "vistas" pelo usuário
  // assim que a página é aberta (faz sumir a bolinha vermelha do menu).
  const markSeenMut = trpc.notifications.markRequestsSeen.useMutation({
    onSuccess: () => { utils.notifications.pendingRequestCounts.invalidate(); },
  });
  useEffect(() => {
    markSeenMut.mutate({ key: "he_solicitacao" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Mutations
  const createMut = trpc.heSolicitacoes.create.useMutation({
    onSuccess: () => {
      toast.success("Solicitação de HE criada com sucesso!");
      utils.heSolicitacoes.list.invalidate();
      utils.heSolicitacoes.counts.invalidate();
      setFormData({ obraId: "", dataSolicitacao: "", horaInicio: "", horaFim: "", motivo: "", observacoes: "", funcionarioIds: [] });
      setActiveTab("historico");
    },
    onError: (err) => toast.error(err.message),
  });

  // Query para detalhes da solicitação selecionada
  const detailQuery = trpc.heSolicitacoes.getById.useQuery(
    { id: detailSolId! },
    { enabled: !!detailSolId }
  );

  const approveMut = trpc.heSolicitacoes.approve.useMutation({
    onSuccess: (res) => {
      toast.success(res.reversao ? "Solicitação revertida para APROVADA!" : "Solicitação aprovada!");
      utils.heSolicitacoes.list.invalidate();
      utils.heSolicitacoes.counts.invalidate();
      utils.heSolicitacoes.getById.invalidate();
      setDetailSolId(null);
      setAdminObs("");
      setShowRejectForm(false);
    },
    onError: (err) => toast.error(err.message),
  });

  const rejectMut = trpc.heSolicitacoes.reject.useMutation({
    onSuccess: (res) => {
      toast.success(res.reversao ? "Solicitação revertida para REJEITADA!" : "Solicitação rejeitada.");
      utils.heSolicitacoes.list.invalidate();
      utils.heSolicitacoes.counts.invalidate();
      utils.heSolicitacoes.getById.invalidate();
      setDetailSolId(null);
      setAdminObs("");
      setRejectReason("");
      setShowRejectForm(false);
    },
    onError: (err) => toast.error(err.message),
  });

  const cancelMut = trpc.heSolicitacoes.cancel.useMutation({
    onSuccess: () => {
      toast.success("Solicitação cancelada.");
      utils.heSolicitacoes.list.invalidate();
      utils.heSolicitacoes.counts.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const deleteMut = trpc.heSolicitacoes.delete.useMutation({
    onSuccess: () => {
      toast.success("Solicitação excluída permanentemente.");
      utils.heSolicitacoes.list.invalidate();
      utils.heSolicitacoes.counts.invalidate();
      setDetailSolId(null);
    },
    onError: (err) => toast.error(err.message),
  });

  const [editingId, setEditingId] = useState<number | null>(null);
  const [editingHadAtividades, setEditingHadAtividades] = useState(false);

  const updateMut = trpc.heSolicitacoes.update.useMutation({
    onSuccess: () => {
      toast.success("Solicitação atualizada com sucesso!");
      utils.heSolicitacoes.list.invalidate();
      utils.heSolicitacoes.counts.invalidate();
      utils.heSolicitacoes.getById.invalidate();
      setEditingId(null);
      setFormData({ obraId: "", planejamentoAtividadeIds: [], dataSolicitacao: "", horaInicio: "", horaFim: "", motivo: "", observacoes: "", funcionarioIds: [] });
      setActiveTab("historico");
    },
    onError: (err) => toast.error(err.message),
  });

  const reverterMut = trpc.heSolicitacoes.reverterAprovacao.useMutation({
    onSuccess: (data) => {
      toast.success(`Aprovação revertida! Status anterior: ${data.statusAnterior}`);
      utils.heSolicitacoes.list.invalidate();
      utils.heSolicitacoes.counts.invalidate();
      utils.heSolicitacoes.getById.invalidate();
      setShowRevertDialog(false);
      setRevertMotivo("");
    },
    onError: (err) => toast.error(err.message),
  });
  const [showRevertDialog, setShowRevertDialog] = useState(false);
  const [revertMotivo, setRevertMotivo] = useState("");

  const [confirmDeleteId, setConfirmDeleteId] = useState<number | null>(null);
  const [buscaFunc, setBuscaFunc] = useState("");
  const [verTodosFuncionarios, setVerTodosFuncionarios] = useState(false);

  const [assinaturaEmployeeId, setAssinaturaEmployeeId] = useState<number | null>(null);
  const [assinaturaEmployeeName, setAssinaturaEmployeeName] = useState("");
  const [modoComparecimento, setModoComparecimento] = useState(false);
  const [verAssinatura, setVerAssinatura] = useState<number | null>(null);
  const [ausenciaDialog, setAusenciaDialog] = useState<{ employeeId: number; nome: string; solicitacaoId: number; dataSolicitacao?: string; bulk?: { employeeId: number; nome: string }[] } | null>(null);
  const [justificativaTexto, setJustificativaTexto] = useState("");

  const confirmQ = trpc.heSolicitacoes.getConfirmacoes.useQuery(
    { solicitacaoId: detailSolId! },
    { enabled: !!detailSolId }
  );

  const confirmarMut = trpc.heSolicitacoes.confirmarPresenca.useMutation({
    onSuccess: (data: any) => {
      if (data.primeiraAssinatura) {
        toast.success("Presença confirmada! Assinatura salva como memorial para futuras comparações.");
      } else if (data.assinaturaDivergente) {
        toast.warning(`⚠️ ATENÇÃO: Assinatura divergente do memorial! Similaridade: ${data.similaridade}%. Verificar identidade do funcionário.`, { duration: 8000 });
      } else {
        toast.success(`Presença confirmada! Assinatura compatível (${data.similaridade}% similaridade).`);
      }
      utils.heSolicitacoes.getConfirmacoes.invalidate();
      setAssinaturaEmployeeId(null);
      setAssinaturaEmployeeName("");
    },
    onError: (err) => toast.error(err.message),
  });

  const comparecMut = trpc.heSolicitacoes.registrarComparecimento.useMutation({
    onSuccess: () => {
      toast.success("Comparecimento registrado!");
      utils.heSolicitacoes.getConfirmacoes.invalidate();
      setModoComparecimento(false);
    },
    onError: (err) => toast.error(err.message),
  });

  const provaAltMut = trpc.heSolicitacoes.enviarProvaAlternativa.useMutation({
    onSuccess: () => {
      toast.success("Prova alternativa anexada! Divergência resolvida.");
      utils.heSolicitacoes.getConfirmacoes.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const handleProvaAlternativa = useCallback((confirmacaoId: number) => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*,video/*";
    input.onchange = async (e: any) => {
      const file = e.target.files?.[0];
      if (!file) return;
      if (file.size > 10 * 1024 * 1024) {
        toast.error("Arquivo muito grande. Máximo 10MB.");
        return;
      }
      const tipo = file.type.startsWith("video") ? "video" as const : "foto" as const;
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = reader.result as string;
        provaAltMut.mutate({ confirmacaoId, provaBase64: base64, tipo });
      };
      reader.readAsDataURL(file);
    };
    input.click();
  }, [provaAltMut]);

  const activeEmployees = useMemo(() => {
    return (employeesQuery.data || []).filter((e: any) => e.status === "Ativo" && !e.deletedAt);
  }, [employeesQuery.data]);

  const avisoPrevioSet = useMemo(() => {
    const ids = new Set<number>();
    (avisoPrevioQuery.data || []).forEach((a: any) => ids.add(a.employeeId));
    return ids;
  }, [avisoPrevioQuery.data]);

  // Query para buscar funcionários alocados na obra via tabela obraFuncionarios
  const obraFuncsQuery = trpc.obras.funcionarios.useQuery(
    { obraId: formData.obraId ? parseInt(formData.obraId) : 0 },
    { enabled: !!formData.obraId && parseInt(formData.obraId) > 0 }
  );

  const obraEmployees = useMemo(() => {
    if (!formData.obraId) return activeEmployees;
    const alocadosIds = new Set((obraFuncsQuery.data || []).map((f: any) => f.employeeId || f.id));
    const filtered = activeEmployees.filter((e: any) => 
      alocadosIds.has(e.id) || String(e.obraAtualId) === formData.obraId
    );
    return filtered;
  }, [activeEmployees, formData.obraId, obraFuncsQuery.data]);

  const displayEmployees = useMemo(() => {
    if (verTodosFuncionarios || !formData.obraId) return activeEmployees;
    return obraEmployees;
  }, [verTodosFuncionarios, formData.obraId, activeEmployees, obraEmployees]);

  const obrasMap = useMemo(() => {
    const m: Record<number, string> = {};
    (obrasQuery.data || []).forEach((o: any) => { m[o.id] = o.nome; });
    return m;
  }, [obrasQuery.data]);

  // Usa a query dedicada sem filtro de mês para mostrar TODAS as pendentes
  const pendentes = useMemo(() => {
    return pendentesQuery.data || [];
  }, [pendentesQuery.data]);

  const isAdminMaster = user?.role === "admin_master";

  function handleStartEdit(sol: any) {
    const hasAtividades = Array.isArray(sol.atividadesVinculadas) && sol.atividadesVinculadas.length > 0;
    setFormData({
      obraId: sol.obraId ? String(sol.obraId) : "",
      planejamentoAtividadeIds: hasAtividades ? sol.atividadesVinculadas.map((a: any) => String(a.id)) : [],
      dataSolicitacao: sol.dataSolicitacao || "",
      horaInicio: sol.horaInicio || "",
      horaFim: sol.horaFim || "",
      motivo: sol.motivo || "",
      observacoes: sol.observacoes || "",
      funcionarioIds: (sol.funcionarios || []).map((f: any) => f.employeeId),
    });
    setEditingId(sol.id);
    setEditingHadAtividades(!hasAtividades);
    setDetailSolId(null);
    setActiveTab("solicitar");
  }

  function handleCancelEdit() {
    setEditingId(null);
    setFormData({ obraId: "", planejamentoAtividadeIds: [], dataSolicitacao: "", horaInicio: "", horaFim: "", motivo: "", observacoes: "", funcionarioIds: [] });
  }

  function handleSubmit() {
    if (!companyId) return;
    if (!formData.dataSolicitacao) { toast.error("Informe a data da HE"); return; }
    if (!formData.motivo || formData.motivo.length < 5) { toast.error("Informe o motivo (mínimo 5 caracteres)"); return; }
    if (formData.funcionarioIds.length === 0) { toast.error("Selecione pelo menos 1 funcionário"); return; }

    if (editingId) {
      const sendAtividades = editingHadAtividades && formData.planejamentoAtividadeIds.length === 0
        ? undefined
        : (formData.planejamentoAtividadeIds.length > 0 ? formData.planejamentoAtividadeIds.map(Number) : undefined);
      updateMut.mutate({
        id: editingId,
        companyId, companyIds,
        obraId: formData.obraId ? parseInt(formData.obraId) : undefined,
        planejamentoAtividadeIds: sendAtividades,
        dataSolicitacao: formData.dataSolicitacao,
        horaInicio: formData.horaInicio || undefined,
        horaFim: formData.horaFim || undefined,
        motivo: formData.motivo,
        observacoes: formData.observacoes || undefined,
        funcionarioIds: formData.funcionarioIds,
      });
    } else {
      createMut.mutate({ companyId, companyIds, obraId: formData.obraId ? parseInt(formData.obraId) : undefined,
        planejamentoAtividadeIds: formData.planejamentoAtividadeIds.length > 0 ? formData.planejamentoAtividadeIds.map(Number) : undefined,
        dataSolicitacao: formData.dataSolicitacao,
        horaInicio: formData.horaInicio || undefined,
        horaFim: formData.horaFim || undefined,
        motivo: formData.motivo,
        observacoes: formData.observacoes || undefined,
        funcionarioIds: formData.funcionarioIds,
      });
    }
  }

  function handleApproveFromDialog() {
    if (!detailSolId) return;
    approveMut.mutate({ id: detailSolId, observacaoAdmin: adminObs || undefined });
  }

  function handleRejectFromDialog() {
    if (!detailSolId) return;
    if (!rejectReason || rejectReason.length < 5) {
      toast.error("Motivo da rejeição obrigatório (mínimo 5 caracteres)");
      return;
    }
    rejectMut.mutate({ id: detailSolId, motivoRejeicao: rejectReason, observacaoAdmin: adminObs || undefined });
  }

  function openDetail(solId: number) {
    setDetailSolId(solId);
    setAdminObs("");
    setRejectReason("");
    setShowRejectForm(false);
  }

  function handleCancel(id: number) {
    if (!confirm("Confirma o cancelamento desta solicitação?")) return;
    cancelMut.mutate({ id });
  }

  function toggleEmployee(empId: number) {
    setFormData(prev => ({
      ...prev,
      funcionarioIds: prev.funcionarioIds.includes(empId)
        ? prev.funcionarioIds.filter(id => id !== empId)
        : [...prev.funcionarioIds, empId],
    }));
  }

  function openHEHistory(empId: number, empName: string) {
    setHeHistoryEmployeeId(empId);
    setHeHistoryEmployeeName(empName);
  }

  function selectAllEmployees() {
    const allIds = displayEmployees.filter((e: any) => !avisoPrevioSet.has(e.id)).map((e: any) => e.id);
    setFormData(prev => ({ ...prev, funcionarioIds: allIds }));
  }

  function deselectAllEmployees() {
    setFormData(prev => ({ ...prev, funcionarioIds: [] }));
  }

  const tabs: { key: TabType; label: string; icon: any; badge?: number }[] = [
    { key: "solicitar", label: "Nova Solicitação", icon: Plus },
    { key: "aprovacoes", label: "Aprovações", icon: CheckCircle, badge: countsQuery.data?.pendentes || 0 },
    { key: "historico", label: "Histórico", icon: FileText },
  ];

  return (
    <DashboardLayout>
      <div className="p-4 md:p-6 space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-lg md:text-2xl font-bold flex items-center gap-2">
            <Clock className="h-5 w-5 md:h-6 md:w-6 text-blue-600" />
            Solicitação de Horas Extras
          </h1>
          <p className="text-xs md:text-sm text-muted-foreground mt-1">
            Art. 59 CLT — Horas extras com autorização prévia do Admin Master
          </p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Card className="border-l-4 border-l-yellow-500 cursor-pointer hover:shadow-md transition-shadow" onClick={() => { setActiveTab("historico"); setFilterStatus("pendente"); setFilterMes(""); }}>
            <CardContent className="p-3 md:p-4">
              <div className="text-xl md:text-2xl font-bold text-yellow-600">{fmtNum(countsQuery.data?.pendentes || 0)}</div>
              <div className="text-[10px] md:text-xs text-muted-foreground">Pendentes</div>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-green-500 cursor-pointer hover:shadow-md transition-shadow" onClick={() => { setActiveTab("historico"); setFilterStatus("aprovada"); setFilterMes(""); }}>
            <CardContent className="p-3 md:p-4">
              <div className="text-xl md:text-2xl font-bold text-green-600">{fmtNum(countsQuery.data?.aprovadas || 0)}</div>
              <div className="text-[10px] md:text-xs text-muted-foreground">Aprovadas</div>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-red-500 cursor-pointer hover:shadow-md transition-shadow" onClick={() => { setActiveTab("historico"); setFilterStatus("rejeitada"); setFilterMes(""); }}>
            <CardContent className="p-3 md:p-4">
              <div className="text-xl md:text-2xl font-bold text-red-600">{fmtNum(countsQuery.data?.rejeitadas || 0)}</div>
              <div className="text-[10px] md:text-xs text-muted-foreground">Rejeitadas</div>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-blue-500 cursor-pointer hover:shadow-md transition-shadow" onClick={() => { setActiveTab("historico"); setFilterStatus("todas"); setFilterMes(""); }}>
            <CardContent className="p-3 md:p-4">
              <div className="text-xl md:text-2xl font-bold text-blue-600">{fmtNum(countsQuery.data?.total || 0)}</div>
              <div className="text-[10px] md:text-xs text-muted-foreground">Total</div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 border-b pb-0 overflow-x-auto">
          {tabs.map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-1.5 px-3 md:px-4 py-2 md:py-2.5 text-xs md:text-sm font-medium rounded-t-lg transition-colors relative whitespace-nowrap ${
                activeTab === tab.key
                  ? "bg-white text-blue-700 border border-b-white -mb-px z-10 shadow-sm"
                  : "text-muted-foreground hover:text-foreground hover:bg-gray-50"
              }`}
            >
              <tab.icon className="h-3.5 w-3.5 md:h-4 md:w-4" />
              {tab.label}
              {tab.badge && tab.badge > 0 ? (
                <span className="ml-1 bg-red-500 text-white text-[10px] md:text-xs rounded-full px-1.5 py-0.5 min-w-[18px] text-center">
                  {tab.badge}
                </span>
              ) : null}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="bg-white rounded-lg border p-3 md:p-6">
          {/* ========== TAB: NOVA SOLICITAÇÃO / EDITAR ========== */}
          {activeTab === "solicitar" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  {editingId ? <SquarePen className="h-5 w-5 text-amber-600" /> : <Send className="h-5 w-5 text-blue-600" />}
                  {editingId ? `Editando HE-${String(editingId).padStart(5, '0')}` : "Nova Solicitação de Horas Extras"}
                </h2>
                {editingId && (
                  <Button variant="outline" size="sm" className="text-xs" onClick={handleCancelEdit}>
                    <X className="h-3.5 w-3.5 mr-1" /> Cancelar Edição
                  </Button>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {/* Obra */}
                <div className="space-y-1.5">
                  <Label>Obra (opcional)</Label>
                  <Select value={formData.obraId} onValueChange={v => { setFormData(p => ({ ...p, obraId: v, planejamentoAtividadeIds: [], funcionarioIds: [] })); setBuscaAtividade(""); setVerTodosFuncionarios(false); }}>
                    <SelectTrigger><SelectValue placeholder="Selecione a obra..." /></SelectTrigger>
                    <SelectContent>
                      {(obrasQuery.data || []).map((o: any) => (
                        <SelectItem key={o.id} value={String(o.id)}>{o.nome}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Atividade do Cronograma — multi-seleção */}
                <div className="space-y-1.5 md:col-span-2">
                  <Label className="flex items-center gap-1.5">
                    <TrendingUp className="h-3.5 w-3.5 text-blue-600" />
                    Atividades do Cronograma (opcional)
                    {formData.planejamentoAtividadeIds.length > 0 && (
                      <span className="ml-1 px-1.5 py-0.5 text-xs rounded-full bg-blue-100 text-blue-700 font-semibold">
                        {formData.planejamentoAtividadeIds.length} selecionada{formData.planejamentoAtividadeIds.length > 1 ? "s" : ""}
                      </span>
                    )}
                  </Label>
                  {!formData.obraId ? (
                    <p className="text-xs text-muted-foreground italic py-2">Selecione uma obra para carregar as atividades do cronograma.</p>
                  ) : atividadesQuery.isLoading ? (
                    <div className="flex items-center gap-2 text-xs text-muted-foreground py-2"><Loader2 className="h-3.5 w-3.5 animate-spin" /> Carregando atividades...</div>
                  ) : !(atividadesQuery.data as any)?.atividades?.length ? (
                    <p className="text-xs text-amber-600 italic py-2">Esta obra não possui cronograma cadastrado no módulo Planejamento.</p>
                  ) : (() => {
                    const todasAtvs: any[] = (atividadesQuery.data as any)?.atividades || [];
                    const termo = buscaAtividade.toLowerCase().trim();
                    const atvsVisiveis = termo
                      ? todasAtvs.filter((a: any) =>
                          a.nome?.toLowerCase().includes(termo) ||
                          a.eapCodigo?.toLowerCase().includes(termo)
                        )
                      : todasAtvs;
                    return (
                      <div className="rounded-lg border bg-white overflow-hidden">
                        {/* Campo de busca */}
                        <div className="flex items-center gap-2 px-3 py-2 border-b bg-slate-50 sticky top-0">
                          <Search className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                          <input
                            type="text"
                            value={buscaAtividade}
                            onChange={e => setBuscaAtividade(e.target.value)}
                            placeholder="Buscar atividade pelo nome ou código EAP..."
                            className="flex-1 text-xs bg-transparent outline-none placeholder:text-muted-foreground"
                          />
                          {buscaAtividade && (
                            <button onClick={() => setBuscaAtividade("")} className="text-muted-foreground hover:text-slate-700">
                              <X className="h-3 w-3" />
                            </button>
                          )}
                        </div>
                        {/* Lista com scroll */}
                        <div className="max-h-48 overflow-y-auto divide-y">
                          {atvsVisiveis.length === 0 ? (
                            <p className="text-xs text-muted-foreground italic px-3 py-3">Nenhuma atividade encontrada.</p>
                          ) : atvsVisiveis.map((a: any) => {
                            const sid = String(a.id);
                            const checked = formData.planejamentoAtividadeIds.includes(sid);
                            return (
                              <label key={a.id} className={`flex items-center gap-3 px-3 py-2.5 cursor-pointer hover:bg-blue-50 transition-colors ${checked ? "bg-blue-50 border-l-2 border-l-blue-500" : ""}`}>
                                <input
                                  type="checkbox"
                                  checked={checked}
                                  onChange={() => setFormData(p => ({
                                    ...p,
                                    planejamentoAtividadeIds: checked
                                      ? p.planejamentoAtividadeIds.filter(id => id !== sid)
                                      : [...p.planejamentoAtividadeIds, sid],
                                  }))}
                                  className="h-4 w-4 rounded border-gray-300 text-blue-600 accent-blue-600 shrink-0"
                                />
                                <span className="font-mono text-xs text-blue-700 shrink-0 w-12">{a.eapCodigo}</span>
                                <span className="text-sm flex-1 text-slate-700 leading-tight">{a.nome}</span>
                                {a.avancoPct > 0 && (
                                  <span className="text-xs text-slate-400 shrink-0">{a.avancoPct.toFixed(0)}%</span>
                                )}
                              </label>
                            );
                          })}
                        </div>
                        {/* Rodapé com contagem */}
                        <div className="px-3 py-1.5 bg-slate-50 border-t flex items-center justify-between">
                          <span className="text-xs text-muted-foreground">
                            {atvsVisiveis.length === todasAtvs.length
                              ? `${todasAtvs.length} atividade${todasAtvs.length !== 1 ? "s" : ""} disponível${todasAtvs.length !== 1 ? "s" : ""}`
                              : `${atvsVisiveis.length} de ${todasAtvs.length} encontrada${atvsVisiveis.length !== 1 ? "s" : ""}`
                            }
                            <span className="ml-1 text-amber-600 text-xs">(100% concluídas já ocultadas)</span>
                          </span>
                          {formData.planejamentoAtividadeIds.length > 0 && (
                            <button onClick={() => setFormData(p => ({ ...p, planejamentoAtividadeIds: [] }))} className="text-xs text-red-500 hover:text-red-700">
                              Limpar seleção
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })()}
                  {formData.planejamentoAtividadeIds.length > 0 && (
                    <p className="text-xs text-green-700 flex items-center gap-1">
                      <CheckCircle className="h-3 w-3" /> Custo será distribuído entre as {formData.planejamentoAtividadeIds.length} atividade{formData.planejamentoAtividadeIds.length > 1 ? "s" : ""} e acumulado no REFI ao aprovar.
                    </p>
                  )}
                </div>

                {/* Data */}
                <div className="space-y-1.5">
                  <Label>Data da HE *</Label>
                  <Input
                    type="date"
                    value={formData.dataSolicitacao}
                    onChange={e => setFormData(p => ({ ...p, dataSolicitacao: e.target.value }))}
                  />
                </div>

                {/* Hora Início */}
                <div className="space-y-1.5">
                  <Label>Hora Início (prevista)</Label>
                  <Input
                    type="time"
                    value={formData.horaInicio}
                    onChange={e => setFormData(p => ({ ...p, horaInicio: e.target.value }))}
                  />
                </div>

                {/* Hora Fim */}
                <div className="space-y-1.5">
                  <Label>Hora Fim (prevista)</Label>
                  <Input
                    type="time"
                    value={formData.horaFim}
                    onChange={e => setFormData(p => ({ ...p, horaFim: e.target.value }))}
                  />
                </div>

                {/* Motivo */}
                <div className="space-y-1.5 md:col-span-2">
                  <Label>Motivo *</Label>
                  <textarea
                    className="w-full border rounded-md p-2 text-sm min-h-[80px] resize-y"
                    placeholder="Descreva o motivo da necessidade de horas extras..."
                    value={formData.motivo}
                    onChange={e => setFormData(p => ({ ...p, motivo: e.target.value }))}
                  />
                </div>

                {/* Observações */}
                <div className="space-y-1.5 md:col-span-2 lg:col-span-3">
                  <Label>Observações</Label>
                  <Input
                    placeholder="Observações adicionais..."
                    value={formData.observacoes}
                    onChange={e => setFormData(p => ({ ...p, observacoes: e.target.value }))}
                  />
                </div>
              </div>

              {/* Aviso Prévio Alert */}
              {avisoPrevioSet.size > 0 && (
                <div className="flex items-start gap-3 p-3 bg-orange-50 border border-orange-200 rounded-lg text-sm">
                  <AlertTriangle className="h-4 w-4 text-orange-500 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-orange-800">Atenção — Aviso Prévio</p>
                    <p className="text-orange-700 text-xs mt-0.5">
                      {avisoPrevioSet.size === 1
                        ? "1 funcionário desta lista está em aviso prévio"
                        : `${avisoPrevioSet.size} funcionários desta lista estão em aviso prévio`} e <strong>não pode(m) realizar horas extras</strong> conforme a CLT. Eles estão marcados com o ícone
                      {" "}<Ban className="h-3 w-3 inline text-orange-500" /> e não podem ser selecionados.
                    </p>
                  </div>
                </div>
              )}

              {/* Seleção de Funcionários */}
              <div className="space-y-3">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                  <Label className="text-sm md:text-base font-semibold flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Funcionários ({formData.funcionarioIds.length} selecionados)
                  </Label>
                  <div className="flex gap-2 flex-wrap">
                    {formData.obraId && (
                      <Button
                        variant={verTodosFuncionarios ? "default" : "outline"}
                        size="sm"
                        className={`text-xs md:text-sm gap-1.5 ${verTodosFuncionarios ? "bg-purple-600 hover:bg-purple-700 text-white" : "text-purple-700 border-purple-200 hover:bg-purple-50"}`}
                        onClick={() => {
                          setVerTodosFuncionarios(v => {
                            if (v) {
                              const obraIds = new Set(obraEmployees.map((e: any) => e.id));
                              setFormData(p => ({ ...p, funcionarioIds: p.funcionarioIds.filter(id => obraIds.has(id)) }));
                            }
                            return !v;
                          });
                        }}
                      >
                        <Building2 className="h-3.5 w-3.5" />
                        {verTodosFuncionarios ? "Apenas desta obra" : "Todas as obras"}
                      </Button>
                    )}
                    <Button variant="outline" size="sm" className="text-xs md:text-sm" onClick={selectAllEmployees}>
                      Selecionar Todos ({displayEmployees.filter((e: any) => !avisoPrevioSet.has(e.id)).length})
                    </Button>
                    <Button variant="outline" size="sm" className="text-xs md:text-sm" onClick={deselectAllEmployees}>
                      Limpar Seleção
                    </Button>
                  </div>
                </div>
                {verTodosFuncionarios && formData.obraId && (
                  <div className="flex items-center gap-2 p-2.5 bg-purple-50 border border-purple-200 rounded-lg text-xs text-purple-700">
                    <Building2 className="h-3.5 w-3.5 shrink-0" />
                    Mostrando funcionários de <strong>todas as obras</strong>. Os que não são desta obra aparecerão com a obra de origem indicada.
                  </div>
                )}

                {/* Busca por nome */}
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">🔍</span>
                  <Input
                    placeholder="Buscar por nome ou função..."
                    value={buscaFunc}
                    onChange={e => setBuscaFunc(e.target.value)}
                    className="pl-9 text-sm"
                  />
                  {buscaFunc && (
                    <button
                      onClick={() => setBuscaFunc("")}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 text-lg leading-none"
                    >×</button>
                  )}
                </div>

                <div className="border rounded-lg max-h-[300px] overflow-y-auto">
                  {displayEmployees.length === 0 ? (
                    <div className="p-4 text-center text-muted-foreground text-sm">
                      Nenhum funcionário ativo encontrado{formData.obraId && !verTodosFuncionarios ? " nesta obra" : ""}
                    </div>
                  ) : (
                    <div className="overflow-x-auto"><table className="w-full text-sm">
                      <thead className="bg-gray-50 sticky top-0">
                        <tr>
                          <th className="p-2 text-left w-10"></th>
                          <th className="p-2 text-left">Nome</th>
                          <th className="p-2 text-left">Função</th>
                          {verTodosFuncionarios && formData.obraId && <th className="p-2 text-left">Obra Atual</th>}
                          <th className="p-2 text-left">CPF</th>
                        </tr>
                      </thead>
                      <tbody>
                        {displayEmployees
                          .filter((emp: any) =>
                            !buscaFunc ||
                            emp.nomeCompleto?.toLowerCase().includes(buscaFunc.toLowerCase()) ||
                            emp.funcao?.toLowerCase().includes(buscaFunc.toLowerCase())
                          )
                          .map((emp: any) => {
                            const isAviso = avisoPrevioSet.has(emp.id);
                            const isSelected = formData.funcionarioIds.includes(emp.id);
                            const isOutraObra = verTodosFuncionarios && formData.obraId && !obraEmployees.some((o: any) => o.id === emp.id);
                            return (
                              <tr
                                key={emp.id}
                                className={`border-t transition-colors ${
                                  isAviso
                                    ? "bg-orange-50 cursor-not-allowed"
                                    : isSelected
                                      ? "bg-blue-50 cursor-pointer hover:bg-blue-100"
                                      : isOutraObra
                                        ? "bg-purple-50/30 cursor-pointer hover:bg-purple-50"
                                        : "cursor-pointer hover:bg-blue-50"
                                }`}
                                onClick={() => { if (!isAviso) toggleEmployee(emp.id); }}
                              >
                                <td className="p-2" onClick={e => e.stopPropagation()}>
                                  {isAviso ? (
                                    <Ban className="h-4 w-4 text-orange-400 mx-auto" title="Em aviso prévio — HE não permitida" />
                                  ) : (
                                    <input
                                      type="checkbox"
                                      checked={isSelected}
                                      onChange={() => toggleEmployee(emp.id)}
                                      className="rounded"
                                    />
                                  )}
                                </td>
                                <td
                                  className={`p-2 font-medium cursor-pointer hover:underline flex items-center gap-1.5 ${isAviso ? "text-orange-600" : "text-blue-700"}`}
                                  onClick={e => { e.stopPropagation(); openHEHistory(emp.id, emp.nomeCompleto); }}
                                  title="Ver histórico de horas extras"
                                >
                                  <History className="h-3.5 w-3.5 opacity-60 shrink-0" />
                                  {emp.nomeCompleto}
                                  {isAviso && (
                                    <span className="ml-1 text-[10px] font-semibold bg-orange-200 text-orange-800 px-1.5 py-0.5 rounded-full whitespace-nowrap">
                                      AVISO PRÉVIO
                                    </span>
                                  )}
                                  {isOutraObra && (
                                    <span className="ml-1 text-[10px] font-semibold bg-purple-100 text-purple-700 px-1.5 py-0.5 rounded-full whitespace-nowrap">
                                      OUTRA OBRA
                                    </span>
                                  )}
                                </td>
                                <td className="p-2 text-muted-foreground">{emp.funcao || "-"}</td>
                                {verTodosFuncionarios && formData.obraId && (
                                  <td className="p-2 text-muted-foreground text-xs">
                                    {emp.obraAtualId ? (obrasMap[emp.obraAtualId] || `Obra #${emp.obraAtualId}`) : "Sem obra"}
                                  </td>
                                )}
                                <td className="p-2 text-muted-foreground">{emp.cpf || "-"}</td>
                              </tr>
                            );
                          })}
                        {buscaFunc && displayEmployees.filter((emp: any) =>
                          emp.nomeCompleto?.toLowerCase().includes(buscaFunc.toLowerCase()) ||
                          emp.funcao?.toLowerCase().includes(buscaFunc.toLowerCase())
                        ).length === 0 && (
                          <tr>
                            <td colSpan={verTodosFuncionarios && formData.obraId ? 5 : 4} className="p-4 text-center text-sm text-gray-400">
                              Nenhum funcionário encontrado para "{buscaFunc}"
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table></div>
                  )}
                </div>
              </div>

              <div className="flex justify-end gap-2">
                {editingId && (
                  <Button variant="outline" onClick={handleCancelEdit}>
                    Cancelar
                  </Button>
                )}
                <Button
                  onClick={handleSubmit}
                  disabled={createMut.isPending || updateMut.isPending}
                  className={editingId ? "bg-amber-600 hover:bg-amber-700" : "bg-blue-600 hover:bg-blue-700"}
                >
                  {(createMut.isPending || updateMut.isPending) ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : editingId ? <SquarePen className="h-4 w-4 mr-2" /> : <Send className="h-4 w-4 mr-2" />}
                  {editingId ? "Salvar Alterações" : "Enviar Solicitação"}
                </Button>
              </div>
            </div>
          )}

          {/* ========== TAB: APROVAÇÕES (Admin Master) ========== */}
          {activeTab === "aprovacoes" && (() => {
            // Mostrar TODAS as solicitações na aba Aprovações com sub-filtros
            const allSols = listQuery.data || [];
            const aprovPendentes = allSols.filter((s: any) => s.status === "pendente");
            const aprovAprovadas = allSols.filter((s: any) => s.status === "aprovada");
            const aprovRejeitadas = allSols.filter((s: any) => s.status === "rejeitada");
            // Também incluir pendentes de outros meses via pendentesQuery
            const pendentesOutrosMeses = (pendentesQuery.data || []).filter(
              (p: any) => !aprovPendentes.some((a: any) => a.id === p.id)
            );
            const todasPendentes = [...aprovPendentes, ...pendentesOutrosMeses];
            return (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <h2 className="text-base md:text-lg font-semibold flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  Gestão de Aprovações
                  {!isAdminMaster && (
                    <Badge variant="outline" className="ml-2 text-orange-600 border-orange-300 text-[10px] md:text-xs">
                      Somente Admin Master
                    </Badge>
                  )}
                </h2>
                <div className="flex gap-2 w-full sm:w-auto items-center">
                  <div className="relative">
                    <Input
                      type="month"
                      value={filterMes}
                      onChange={e => setFilterMes(e.target.value)}
                      className="w-full sm:w-44"
                      placeholder="Todos os meses"
                    />
                    {filterMes && (
                      <button onClick={() => setFilterMes("")} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 text-sm" title="Limpar filtro de mês">×</button>
                    )}
                  </div>
                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="w-full sm:w-36"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todas">Todas</SelectItem>
                      <SelectItem value="pendente">Pendentes</SelectItem>
                      <SelectItem value="aprovada">Aprovadas</SelectItem>
                      <SelectItem value="rejeitada">Rejeitadas</SelectItem>
                      <SelectItem value="cancelada">Canceladas</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Mini resumo */}
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" className="text-yellow-700 border-yellow-300 bg-yellow-50">
                  {todasPendentes.length} pendentes
                </Badge>
                <Badge variant="outline" className="text-green-700 border-green-300 bg-green-50">
                  {aprovAprovadas.length} aprovadas
                </Badge>
                <Badge variant="outline" className="text-red-700 border-red-300 bg-red-50">
                  {aprovRejeitadas.length} rejeitadas
                </Badge>
              </div>

              {/* Rev. 2220 — Alerta "HE aprovada SEM ponto" foi MOVIDO
                  exclusivamente pra Folha → Módulo Hora Extra (onde a
                  decisão de pagar realmente acontece). Removido daqui
                  e do Fechamento de Ponto pra não poluir as telas. */}

              {/* Seção: Pendentes (sempre visível se houver) */}
              {(filterStatus === "todas" || filterStatus === "pendente") && todasPendentes.length > 0 && (
                <div className="space-y-3">
                  <h3 className="text-sm font-semibold text-yellow-700 flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    Aguardando Aprovação ({todasPendentes.length})
                  </h3>
                  {todasPendentes.map((sol: any) => (
                    <Card key={sol.id} className="border-l-4 border-l-yellow-400">
                      <CardContent className="p-3 md:p-4">
                        <div className="flex flex-col md:flex-row md:items-start justify-between gap-3">
                          <div className="space-y-1.5 flex-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <Badge className={STATUS_COLORS.pendente + " text-[10px] md:text-xs"}>Pendente</Badge>
                              <span className="text-xs md:text-sm text-muted-foreground">
                                HE-{String(sol.id).padStart(5, '0')} · {new Date(sol.dataSolicitacao + "T12:00:00").toLocaleDateString("pt-BR")}
                              </span>
                              {sol.obraNome && (
                                <span className="text-xs flex items-center gap-1">
                                  <Building2 className="h-3 w-3" /> {sol.obraNome}
                                </span>
                              )}
                            </div>
                            <p className="text-xs md:text-sm"><strong>Motivo:</strong> {sol.motivo}</p>
                            {sol.horaInicio && sol.horaFim && (
                              <p className="text-[10px] md:text-xs text-muted-foreground">
                                Horário: {sol.horaInicio} — {sol.horaFim}
                              </p>
                            )}
                            <p className="text-[10px] md:text-xs text-muted-foreground">
                              Por: {sol.solicitadoPor} em {new Date(sol.createdAt).toLocaleString("pt-BR")}
                            </p>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {(sol.funcionarios || []).slice(0, 5).map((f: any) => (
                                <Badge key={f.employeeId} variant="secondary" className="text-[10px] md:text-xs">
                                  {f.employeeName || `ID ${f.employeeId}`}
                                </Badge>
                              ))}
                              {(sol.funcionarios || []).length > 5 && (
                                <Badge variant="secondary" className="text-[10px] md:text-xs">+{(sol.funcionarios || []).length - 5}</Badge>
                              )}
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-2 shrink-0">
                            <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-xs md:text-sm" onClick={() => openDetail(sol.id)}>
                              <Eye className="h-3.5 w-3.5 mr-1" /> Analisar
                            </Button>
                            {sol.canEdit && (
                              <Button size="sm" variant="outline" className="text-xs md:text-sm text-amber-600 border-amber-300" onClick={() => handleStartEdit(sol)}>
                                <SquarePen className="h-3.5 w-3.5 mr-1" /> Editar
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              {/* Seção: Aprovadas/Rejeitadas/Todas do período */}
              {(filterStatus !== "pendente") && (() => {
                const filtered = filterStatus === "todas"
                  ? allSols.filter((s: any) => s.status !== "pendente")
                  : allSols;
                if (filtered.length === 0 && todasPendentes.length === 0) return (
                  <div className="text-center py-12 text-muted-foreground">
                    <CheckCircle className="h-12 w-12 mx-auto mb-3 opacity-30" />
                    <p>Nenhuma solicitação encontrada para o período</p>
                  </div>
                );
                if (filtered.length === 0) return null;
                return (
                  <div className="space-y-3">
                    {filterStatus === "todas" && (
                      <h3 className="text-sm font-semibold text-muted-foreground">Histórico de Decisões</h3>
                    )}
                    {filtered.map((sol: any) => (
                      <Card key={sol.id} className={`border-l-4 ${
                        sol.status === "aprovada" ? "border-l-green-400" :
                        sol.status === "rejeitada" ? "border-l-red-400" :
                        sol.status === "cancelada" ? "border-l-gray-400" :
                        "border-l-yellow-400"
                      }`}>
                        <CardContent className="p-3 md:p-4">
                          <div className="flex flex-col md:flex-row md:items-start justify-between gap-3">
                            <div className="space-y-1.5 flex-1">
                              <div className="flex items-center gap-2 flex-wrap">
                                <Badge className={(STATUS_COLORS[sol.status] || STATUS_COLORS.pendente) + " text-[10px] md:text-xs"}>
                                  {STATUS_LABELS[sol.status] || sol.status}
                                </Badge>
                                <span className="text-xs md:text-sm font-medium">
                                  HE-{String(sol.id).padStart(5, '0')} · {new Date(sol.dataSolicitacao + "T12:00:00").toLocaleDateString("pt-BR")}
                                </span>
                                {sol.obraNome && (
                                  <span className="text-xs flex items-center gap-1 text-muted-foreground">
                                    <Building2 className="h-3 w-3" /> {sol.obraNome}
                                  </span>
                                )}
                              </div>
                              <p className="text-xs md:text-sm">{sol.motivo}</p>
                              {sol.aprovadoPor && (
                                <p className="text-[10px] md:text-xs text-muted-foreground">
                                  {sol.status === "aprovada" ? "Aprovado" : "Rejeitado"} por: {sol.aprovadoPor}
                                  {sol.aprovadoEm && ` em ${new Date(sol.aprovadoEm).toLocaleString("pt-BR")}`}
                                </p>
                              )}
                              {sol.observacaoAdmin && (
                                <p className="text-[10px] md:text-xs text-blue-700">Obs Admin: {sol.observacaoAdmin}</p>
                              )}
                              <div className="flex flex-wrap gap-1 mt-1">
                                {(sol.funcionarios || []).slice(0, 5).map((f: any) => (
                                  <Badge key={f.employeeId} variant="secondary" className="text-[10px] md:text-xs">
                                    {f.employeeName || `ID ${f.employeeId}`}
                                  </Badge>
                                ))}
                                {(sol.funcionarios || []).length > 5 && (
                                  <Badge variant="secondary" className="text-[10px] md:text-xs">+{(sol.funcionarios || []).length - 5}</Badge>
                                )}
                              </div>
                            </div>
                            <div className="flex flex-wrap gap-2 shrink-0">
                              <Button size="sm" variant="outline" className="text-xs md:text-sm" onClick={() => openDetail(sol.id)}>
                                <Eye className="h-3.5 w-3.5 mr-1" /> Detalhes
                              </Button>
                              {sol.canEdit && sol.status === "pendente" && (
                                <Button size="sm" variant="outline" className="text-xs md:text-sm text-amber-600 border-amber-300" onClick={() => handleStartEdit(sol)}>
                                  <SquarePen className="h-3.5 w-3.5 mr-1" /> Editar
                                </Button>
                              )}
                              {sol.status !== "pendente" && sol.status !== "cancelada" && isAdminMaster && (
                                <Button size="sm" variant="outline" className="text-xs md:text-sm text-orange-600 border-orange-300 hover:bg-orange-50" onClick={() => { setDetailSolId(sol.id); setShowRevertDialog(true); setRevertMotivo(""); }}>
                                  <RotateCcw className="h-3.5 w-3.5 mr-1" /> Reverter
                                </Button>
                              )}
                              {(isAdminMaster || (sol.canEdit && sol.status === "pendente")) && (
                                confirmDeleteId === sol.id ? (
                                  <div className="flex items-center gap-1">
                                    <Button size="sm" variant="destructive" className="text-xs" onClick={() => { deleteMut.mutate({ id: sol.id }); setConfirmDeleteId(null); }} disabled={deleteMut.isPending}>
                                      {deleteMut.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : "Sim"}
                                    </Button>
                                    <Button size="sm" variant="outline" className="text-xs" onClick={() => setConfirmDeleteId(null)}>Não</Button>
                                  </div>
                                ) : (
                                  <Button size="sm" variant="outline" className="text-xs md:text-sm text-red-600 border-red-300" onClick={() => setConfirmDeleteId(sol.id)}>
                                    <Trash2 className="h-3.5 w-3.5 mr-1" /> Excluir
                                  </Button>
                                )
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                );
              })()}
            </div>
            );
          })()}

          {/* ========== TAB: HISTÓRICO ========== */}
          {activeTab === "historico" && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <h2 className="text-base md:text-lg font-semibold flex items-center gap-2">
                  <FileText className="h-5 w-5 text-blue-600" />
                  Histórico de Solicitações
                </h2>
                <div className="flex gap-2 w-full sm:w-auto items-center">
                  <div className="relative">
                    <Input
                      type="month"
                      value={filterMes}
                      onChange={e => setFilterMes(e.target.value)}
                      className="w-full sm:w-44"
                      placeholder="Todos os meses"
                    />
                    {filterMes && (
                      <button onClick={() => setFilterMes("")} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 text-sm" title="Limpar filtro de mês">×</button>
                    )}
                  </div>
                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="w-full sm:w-36"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="todas">Todas</SelectItem>
                      <SelectItem value="pendente">Pendentes</SelectItem>
                      <SelectItem value="aprovada">Aprovadas</SelectItem>
                      <SelectItem value="rejeitada">Rejeitadas</SelectItem>
                      <SelectItem value="cancelada">Canceladas</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {!filterMes && (
                <div className="flex items-center gap-2 px-3 py-2 bg-blue-50 border border-blue-200 rounded-lg text-xs text-blue-700">
                  <Calendar className="h-3.5 w-3.5 shrink-0" />
                  Mostrando <strong>todo o histórico</strong>. Use o filtro de mês para limitar o período.
                </div>
              )}

              {listQuery.isLoading ? (
                <div className="text-center py-12"><Loader2 className="h-8 w-8 animate-spin mx-auto text-blue-600" /></div>
              ) : (listQuery.data || []).length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <Calendar className="h-12 w-12 mx-auto mb-3 opacity-30" />
                  <p>Nenhuma solicitação encontrada{filterMes ? " para o período" : ""}</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {(listQuery.data || []).map((sol: any) => (
                    <Card key={sol.id} className={`border-l-4 ${
                      sol.status === "aprovada" ? "border-l-green-400" :
                      sol.status === "rejeitada" ? "border-l-red-400" :
                      sol.status === "cancelada" ? "border-l-gray-400" :
                      "border-l-yellow-400"
                    }`}>
                      <CardContent className="p-4">
                        <div className="flex flex-col md:flex-row md:items-start justify-between gap-3">
                          <div className="space-y-1.5 flex-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <Badge className={STATUS_COLORS[sol.status] || STATUS_COLORS.pendente}>
                                {STATUS_LABELS[sol.status] || sol.status}
                              </Badge>
                              <span className="text-xs md:text-sm font-medium">
                                HE-{String(sol.id).padStart(5, '0')} · {new Date(sol.dataSolicitacao + "T12:00:00").toLocaleDateString("pt-BR")}
                              </span>
                              {sol.obraNome && (
                                <span className="text-xs flex items-center gap-1 text-muted-foreground">
                                  <Building2 className="h-3 w-3" /> {sol.obraNome}
                                </span>
                              )}
                            </div>
                            <p className="text-sm">{sol.motivo}</p>
                            {sol.horaInicio && sol.horaFim && (
                              <p className="text-xs text-muted-foreground">
                                Horário: {sol.horaInicio} — {sol.horaFim}
                              </p>
                            )}
                            <p className="text-xs text-muted-foreground">
                              Solicitado por: {sol.solicitadoPor} | {new Date(sol.createdAt).toLocaleString("pt-BR")}
                            </p>
                            {sol.aprovadoPor && (
                              <p className="text-xs text-muted-foreground">
                                {sol.status === "aprovada" ? "Aprovado" : "Rejeitado"} por: {sol.aprovadoPor}
                                {sol.aprovadoEm && ` em ${new Date(sol.aprovadoEm).toLocaleString("pt-BR")}`}
                              </p>
                            )}
                            {sol.motivoRejeicao && (
                              <p className="text-xs text-red-600">Motivo rejeição: {sol.motivoRejeicao}</p>
                            )}
                            <div className="flex flex-wrap gap-1 mt-1">
                              {(sol.funcionarios || []).map((f: any) => (
                                <Badge key={f.employeeId} variant="secondary" className="text-xs">
                                  {f.employeeName || `ID ${f.employeeId}`}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-2 shrink-0">
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-xs md:text-sm"
                              onClick={() => openDetail(sol.id)}
                            >
                              <Eye className="h-3.5 w-3.5 mr-1" /> Detalhes
                            </Button>
                            {sol.canEdit && sol.status === "pendente" && (
                              <Button size="sm" variant="outline" className="text-xs md:text-sm text-amber-600 border-amber-300" onClick={() => handleStartEdit(sol)}>
                                <SquarePen className="h-3.5 w-3.5 mr-1" /> Editar
                              </Button>
                            )}
                            {sol.status !== "pendente" && sol.status !== "cancelada" && isAdminMaster && (
                              <Button size="sm" variant="outline" className="text-xs md:text-sm text-orange-600 border-orange-300 hover:bg-orange-50" onClick={() => { setDetailSolId(sol.id); setShowRevertDialog(true); setRevertMotivo(""); }}>
                                <RotateCcw className="h-3.5 w-3.5 mr-1" /> Reverter
                              </Button>
                            )}
                            {sol.status === "pendente" && (
                              <Button size="sm" variant="outline" className="text-xs md:text-sm text-red-600" onClick={() => handleCancel(sol.id)}>
                                Cancelar
                              </Button>
                            )}
                            {(isAdminMaster || (sol.canEdit && sol.status === "pendente")) && (
                              confirmDeleteId === sol.id ? (
                                <div className="flex items-center gap-1">
                                  <Button size="sm" variant="destructive" className="text-xs" onClick={() => { deleteMut.mutate({ id: sol.id }); setConfirmDeleteId(null); }} disabled={deleteMut.isPending}>
                                    {deleteMut.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : "Sim"}
                                  </Button>
                                  <Button size="sm" variant="outline" className="text-xs" onClick={() => setConfirmDeleteId(null)}>Não</Button>
                                </div>
                              ) : (
                                <Button size="sm" variant="outline" className="text-xs md:text-sm text-red-600 border-red-300" onClick={() => setConfirmDeleteId(sol.id)}>
                                  <Trash2 className="h-3.5 w-3.5 mr-1" /> Excluir
                                </Button>
                              )
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
      {/* ========== FULLSCREEN DIALOG: ANÁLISE DETALHADA ========== */}
      <FullScreenDialog
        open={!!detailSolId}
        onClose={() => { setDetailSolId(null); setAdminObs(""); setRejectReason(""); setShowRejectForm(false); }}
        title={`Análise da Solicitação HE-${String(detailSolId || "").padStart(5, '0')}`}
      >
        {detailQuery.isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
          </div>
        ) : detailQuery.data ? (() => {
          const sol = detailQuery.data;
          const canApprove = isAdminMaster && sol.status !== "aprovada" && sol.status !== "cancelada";
          const canReject = isAdminMaster && sol.status !== "rejeitada" && sol.status !== "cancelada";
          return (
            <div className="space-y-6 max-w-4xl mx-auto">
              {/* Status Header */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b">
                <div className="flex items-center gap-3">
                  <Badge className={`text-sm px-3 py-1 ${STATUS_COLORS[sol.status] || STATUS_COLORS.pendente}`}>
                    {STATUS_LABELS[sol.status] || sol.status}
                  </Badge>
                  <span className="text-lg font-semibold">HE-{String(sol.id).padStart(5, '0')}</span>
                </div>
                <div className="flex items-center gap-2">
                  {sol.status === "pendente" && (sol.solicitadoPorId === user?.id || isAdminMaster || user?.role === "admin") && (
                    <Button size="sm" variant="outline" className="text-xs text-amber-600 border-amber-300" onClick={() => handleStartEdit(sol)}>
                      <SquarePen className="h-3.5 w-3.5 mr-1" /> Editar
                    </Button>
                  )}
                  {sol.status !== "pendente" && sol.status !== "cancelada" && isAdminMaster && (
                    <Button size="sm" variant="outline" className="text-xs text-orange-600 border-orange-300 hover:bg-orange-50" onClick={() => { setShowRevertDialog(true); setRevertMotivo(""); }}>
                      <RotateCcw className="h-3.5 w-3.5 mr-1" /> Reverter para Pendente
                    </Button>
                  )}
                </div>
              </div>

              {/* Info Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-xs text-muted-foreground mb-1">Data da HE</p>
                  <p className="font-semibold flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-blue-600" />
                    {new Date(sol.dataSolicitacao + "T12:00:00").toLocaleDateString("pt-BR", { weekday: "long", day: "2-digit", month: "long", year: "numeric" })}
                  </p>
                </div>
                {sol.obraNome && (
                  <div className="bg-gray-50 rounded-lg p-4">
                    <p className="text-xs text-muted-foreground mb-1">Obra</p>
                    <p className="font-semibold flex items-center gap-2">
                      <Building2 className="h-4 w-4 text-blue-600" />
                      {sol.obraNome}
                    </p>
                  </div>
                )}
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-xs text-muted-foreground mb-1">Horário Previsto</p>
                  <p className="font-semibold flex items-center gap-2">
                    <Clock className="h-4 w-4 text-blue-600" />
                    {sol.horaInicio && sol.horaFim ? `${sol.horaInicio} — ${sol.horaFim}` : "Não informado"}
                  </p>
                </div>
                <div className="bg-gray-50 rounded-lg p-4 sm:col-span-2 lg:col-span-3">
                  <p className="text-xs text-muted-foreground mb-1">Motivo</p>
                  <p className="font-semibold">{sol.motivo}</p>
                </div>
                {sol.observacoes && (
                  <div className="bg-gray-50 rounded-lg p-4 sm:col-span-2 lg:col-span-3">
                    <p className="text-xs text-muted-foreground mb-1">Observações do Solicitante</p>
                    <p className="text-sm">{sol.observacoes}</p>
                  </div>
                )}
              </div>

              {/* Solicitante */}
              <div className="text-xs text-muted-foreground">
                Solicitado por: <strong>{sol.solicitadoPor}</strong> em {new Date(sol.createdAt).toLocaleString("pt-BR")}
              </div>

              {/* Atividades Vinculadas — suporta múltiplas */}
              {((sol.atividadesVinculadas as any[])?.length > 0 || sol.atividadeInfo) && (() => {
                const atvs: any[] = (sol.atividadesVinculadas as any[])?.length > 0
                  ? (sol.atividadesVinculadas as any[])
                  : [sol.atividadeInfo];
                return (
                  <div className="rounded-lg border-2 border-indigo-200 bg-indigo-50 p-3 space-y-2">
                    <div className="flex items-center gap-2 mb-1">
                      <TrendingUp className="h-4 w-4 text-indigo-700 shrink-0" />
                      <p className="text-xs font-semibold text-indigo-800">
                        {atvs.length === 1 ? "Atividade do Cronograma Vinculada" : `${atvs.length} Atividades do Cronograma Vinculadas`}
                      </p>
                      {sol.status === "aprovada" && (
                        <span className="ml-auto text-xs text-green-700 flex items-center gap-1">
                          <CheckCircle className="h-3 w-3" /> Custo acumulado no REFI
                        </span>
                      )}
                    </div>
                    {atvs.map((atv: any, i: number) => (
                      <div key={atv.id ?? i} className="flex items-start gap-2 bg-white rounded px-2 py-1.5 border border-indigo-100">
                        {atv.eapCodigo && <span className="font-mono text-xs text-indigo-600 shrink-0 pt-0.5">{atv.eapCodigo}</span>}
                        <span className="text-sm font-medium text-indigo-900 flex-1">{atv.nome}</span>
                        {(atv.dataInicio || atv.dataFim) && (
                          <span className="text-xs text-indigo-600 shrink-0">
                            {atv.dataInicio && new Date(atv.dataInicio + "T12:00:00").toLocaleDateString("pt-BR")}
                            {atv.dataInicio && atv.dataFim && " → "}
                            {atv.dataFim && new Date(atv.dataFim + "T12:00:00").toLocaleDateString("pt-BR")}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                );
              })()}

              {/* Funcionários + Custo Previsto */}
              {(() => {
                const funcs = sol.funcionarios || [];
                // --- calcula horas da HE ---
                function calcHoras(ini: string, fim: string): number {
                  if (!ini || !fim) return 0;
                  const [h1, m1] = ini.split(":").map(Number);
                  const [h2, m2] = fim.split(":").map(Number);
                  const mins = (h2 * 60 + m2) - (h1 * 60 + m1);
                  return mins > 0 ? mins / 60 : 0;
                }
                const horasHE = calcHoras(sol.horaInicio || "", sol.horaFim || "");
                // dia da semana → tipo de HE e percentual CLT
                const diaSemana = sol.dataSolicitacao
                  ? new Date(sol.dataSolicitacao + "T12:00:00").getDay()  // 0=dom, 6=sab
                  : -1;
                const isSabado  = diaSemana === 6;
                const isDomingo = diaSemana === 0;
                const isWeekend = isSabado || isDomingo;
                const percentHE = isWeekend ? 100 : 50;

                // Base "normal" = o que custaria se as mesmas horas fossem à tarifa normal
                // Isso vale para QUALQUER dia — a comparação é: normal × horas vs HE × horas
                const custoNormalPorFuncionario = (vh: number) => vh * horasHE;

                const DIAS_SEMANA = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
                const nomeDia = diaSemana >= 0 ? DIAS_SEMANA[diaSemana] : "";
                // valor/hora por funcionário — retorna também a fonte
                function getValorHoraInfo(f: any): { vh: number; fonte: "valorHora" | "salarioBase" | null; salario?: number } {
                  if (f.employeeValorHora) {
                    const v = parseFloat(String(f.employeeValorHora).replace(",", "."));
                    if (!isNaN(v) && v > 0) return { vh: v, fonte: "valorHora" };
                  }
                  if (f.employeeSalarioBase) {
                    const s = parseFloat(String(f.employeeSalarioBase).replace(",", "."));
                    if (!isNaN(s) && s > 0) return { vh: s / 220, fonte: "salarioBase", salario: s };
                  }
                  return { vh: 0, fonte: null };
                }
                function getValorHora(f: any): number | null {
                  const info = getValorHoraInfo(f);
                  return info.fonte ? info.vh : null;
                }
                // Rev. 2570 — Cargo de confiança (CLT art. 62, II): funcionário de
                // cargo de confiança NÃO recebe hora extra. Sem valor a pagar.
                const isCargoConfianca = (f: any) => Number(f.employeeCargoConfianca) === 1;
                const confiancaList = funcs.filter(isCargoConfianca);
                // custoTotal usa o percentual cadastrado de cada funcionário
                // (cargo de confiança NÃO entra — não há HE a pagar)
                const custoTotal = funcs.reduce((acc: number, f: any) => {
                  if (isCargoConfianca(f)) return acc;
                  const vh = getValorHora(f);
                  if (!vh || horasHE === 0) return acc;
                  const pStr = isWeekend ? (f.employeeHe100 ?? f.employeeHeFeriado ?? "100") : (f.employeeHeNormal50 ?? "50");
                  const pct  = parseFloat(String(pStr).replace(",", ".")) || percentHE;
                  return acc + vh * (1 + pct / 100) * horasHE;
                }, 0);
                // totalNormal = base de comparação: VH × horas (sem adicional);
                // cargo de confiança fora (não há HE).
                const totalNormalGlobal = funcs.reduce((acc: number, f: any) => {
                  if (isCargoConfianca(f)) return acc;
                  const vh = getValorHora(f);
                  return acc + (vh && horasHE > 0 ? vh * horasHE : 0);
                }, 0);
                const totalExtraGlobal = custoTotal - totalNormalGlobal;
                const semSalario = funcs.filter((f: any) => !isCargoConfianca(f) && getValorHora(f) === null);
                // elegíveis = funcionários que efetivamente entram nos totais monetários
                // (têm salário E não são cargo de confiança)
                const elegiveis = funcs.filter((f: any) => !isCargoConfianca(f) && getValorHora(f) !== null);

                return (
                  <div className="space-y-4">
                    {/* ── Banner do tipo de HE ── */}
                    {horasHE > 0 && (
                      <div className={`rounded-lg border-l-4 px-4 py-3 ${isWeekend
                        ? "border-l-orange-500 bg-orange-50 border border-orange-200"
                        : "border-l-blue-500 bg-blue-50 border border-blue-200"}`}>
                        <div className="flex flex-wrap items-start gap-4">
                          <div>
                            <p className={`text-xs font-bold uppercase tracking-wide mb-0.5 ${isWeekend ? "text-orange-700" : "text-blue-700"}`}>
                              {isWeekend
                                ? `⚠ Trabalho em Dia de Descanso — ${nomeDia}`
                                : `Hora Extra — Dia Útil (${nomeDia})`}
                            </p>
                            <p className="text-[11px] text-slate-600 leading-snug">
                              {isWeekend ? (
                                <>
                                  <strong>Adicional: 100%</strong> — art. 7º, XV da CF + CLT art. 67/68.{" "}
                                  O funcionário estaria de folga, portanto <strong>não há custo "normal" de base</strong>.{" "}
                                  O valor total pago é custo extra integralmente.
                                  {isSabado && " (Sábado = dia de repouso semanal remunerado na convenção coletiva da construção civil)"}
                                </>
                              ) : (
                                <>
                                  <strong>Adicional: 50%</strong> — CLT art. 59.{" "}
                                  O funcionário trabalharia normalmente parte do período; a HE é a extensão da jornada.{" "}
                                  O custo "normal" representa o valor que seria pago a qualquer modo pela jornada base.
                                </>
                              )}
                            </p>
                          </div>
                          <div className="ml-auto text-right shrink-0">
                            <p className={`text-xs font-semibold ${isWeekend ? "text-orange-700" : "text-blue-700"}`}>Fórmula aplicada</p>
                            <p className="font-mono text-xs text-slate-700">
                              Valor/h × {(1 + percentHE / 100).toFixed(2)} × {horasHE.toFixed(1)}h
                            </p>
                            <p className="text-[10px] text-slate-500">(fator = 1 + {percentHE}%)</p>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* ── Cabeçalho ── */}
                    <h3 className="text-sm font-semibold flex items-center gap-2">
                      <Users className="h-4 w-4" />
                      Funcionários ({funcs.length})
                    </h3>

                    {/* ── Tabela detalhada por funcionário ── */}
                    <div className="border rounded-lg overflow-hidden">
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead className="bg-slate-50 border-b">
                            <tr>
                              <th className="px-3 py-2 text-left text-xs text-slate-500 font-semibold w-6">#</th>
                              <th className="px-3 py-2 text-left text-xs text-slate-500 font-semibold">Nome</th>
                              <th className="px-3 py-2 text-left text-xs text-slate-500 font-semibold">Função</th>
                              {horasHE > 0 && (<>
                                <th className="px-3 py-2 text-right text-xs text-slate-500 font-semibold">Valor/hora</th>
                                <th className="px-3 py-2 text-right text-xs text-slate-500 font-semibold">
                                  <span className="text-slate-600">Custo Normal</span>
                                  <p className="text-[9px] font-normal text-slate-400">Valor/h × horas (sem adicional)</p>
                                </th>
                                <th className="px-3 py-2 text-right text-xs text-slate-500 font-semibold">
                                  <span className={isWeekend ? "text-orange-700" : "text-blue-700"}>Custo HE</span>
                                  <p className="text-[9px] font-normal text-slate-400">(+{percentHE}% CLT)</p>
                                </th>
                                <th className="px-3 py-2 text-right text-xs text-slate-500 font-semibold">
                                  <span className="text-red-600">Diferença</span>
                                  <p className="text-[9px] font-normal text-slate-400">custo extra do adicional</p>
                                </th>
                              </>)}
                            </tr>
                          </thead>
                          <tbody>
                            {funcs.map((f: any, i: number) => {
                              const info = getValorHoraInfo(f);
                              const vh = info.fonte ? info.vh : null;
                              // Rev. 2570 — cargo de confiança não recebe HE
                              const confianca = isCargoConfianca(f);
                              // custoNormal = VH × horas (sempre, é a base de comparação)
                              const custoNormal = vh && horasHE > 0 ? custoNormalPorFuncionario(vh) : null;
                              // percentual individual do funcionário; fallback 50%/100%
                              const pctFuncStr  = isWeekend
                                ? (f.employeeHe100 ?? f.employeeHeFeriado ?? "100")
                                : (f.employeeHeNormal50 ?? "50");
                              const pctFunc     = parseFloat(String(pctFuncStr).replace(",", ".")) || percentHE;
                              const custoHE     = confianca ? 0 : (vh && horasHE > 0 ? vh * (1 + pctFunc / 100) * horasHE : null);
                              // diferença = quanto a mais foi pago por causa do adicional
                              const custoExtra  = confianca ? 0 : (custoNormal != null && custoHE != null ? custoHE - custoNormal : null);
                              return (
                                <tr key={f.employeeId} className={`border-t transition-colors ${confianca ? "bg-violet-50/40 hover:bg-violet-50" : isWeekend ? "hover:bg-orange-50" : "hover:bg-blue-50"}`}>
                                  <td className="px-3 py-3 text-muted-foreground text-xs align-top">{i + 1}</td>
                                  <td className="px-3 py-3">
                                    <div className="flex items-center gap-2">
                                      <PersonPhoto src={f.employeeFotoUrl} alt={f.employeeName || `ID ${f.employeeId}`} size="sm" caption={f.employeeFuncao || undefined} />
                                      <span
                                        className="text-blue-700 font-medium cursor-pointer hover:underline"
                                        onClick={() => setRaioXEmployeeId(f.employeeId)}
                                      >
                                        {f.employeeName || `ID ${f.employeeId}`}
                                      </span>
                                    </div>
                                  </td>
                                  <td className="px-3 py-3 text-muted-foreground text-xs align-top">
                                    {f.employeeFuncao || <span className="italic text-slate-400">—</span>}
                                    {confianca && (
                                      <span className="mt-1 inline-flex items-center gap-1 rounded-full bg-violet-100 text-violet-700 px-2 py-0.5 text-[9px] font-semibold uppercase tracking-wide">
                                        Cargo de confiança{f.employeeCargoConfiancaInciso ? ` · art. 62, ${f.employeeCargoConfiancaInciso}` : " · CLT art. 62"}
                                      </span>
                                    )}
                                  </td>
                                  {horasHE > 0 && (<>
                                    {/* Valor/hora */}
                                    <td className="px-3 py-3 text-right align-top">
                                      {vh != null ? (
                                        <div className="flex flex-col items-end gap-0.5">
                                          <span className="font-mono text-sm font-semibold text-slate-800">R$ {fmtNum(vh)}</span>
                                          {info.fonte === "salarioBase" ? (
                                            <span className="text-[10px] text-amber-600">Sal. R$ {fmtNum(info.salario!)} ÷ 220h</span>
                                          ) : (
                                            <span className="text-[10px] text-green-700">Valor/hora direto</span>
                                          )}
                                        </div>
                                      ) : (
                                        <span className="text-xs text-red-400 italic">sem cadastro</span>
                                      )}
                                    </td>
                                    {confianca ? (
                                      /* Cargo de confiança — não há HE a pagar (CLT art. 62, II) */
                                      <td colSpan={3} className="px-3 py-3 text-center align-middle">
                                        <span className="inline-flex items-center gap-1.5 rounded-lg bg-violet-100 text-violet-700 px-3 py-1.5 text-xs font-semibold">
                                          Isento de hora extra — nada a pagar (CLT art. 62)
                                        </span>
                                      </td>
                                    ) : (<>
                                      {/* Custo Normal — base de comparação (VH × horas, sem adicional) */}
                                      <td className="px-3 py-3 text-right align-top">
                                        {custoNormal != null ? (
                                          <div className="flex flex-col items-end gap-0.5">
                                            <span className="font-mono text-sm font-semibold text-slate-700">R$ {fmtNum(custoNormal)}</span>
                                            <span className="text-[10px] text-slate-400">R$ {fmtNum(vh!)} × {horasHE.toFixed(1)}h</span>
                                          </div>
                                        ) : <span className="text-xs text-slate-300">—</span>}
                                      </td>
                                      {/* Custo HE — com adicional do funcionário */}
                                      <td className="px-3 py-3 text-right align-top">
                                        {custoHE != null ? (
                                          <div className="flex flex-col items-end gap-0.5">
                                            <span className={`font-bold text-sm font-mono ${isWeekend ? "text-orange-700" : "text-blue-800"}`}>
                                              R$ {fmtNum(custoHE)}
                                            </span>
                                            <span className="text-[10px] text-slate-400">
                                              R$ {fmtNum(vh!)} × {(1 + pctFunc / 100).toFixed(2)} × {horasHE.toFixed(1)}h
                                            </span>
                                          </div>
                                        ) : <span className="text-xs text-slate-300">—</span>}
                                      </td>
                                      {/* Diferença — quanto a mais sai por causa do adicional */}
                                      <td className="px-3 py-3 text-right align-top">
                                        {custoExtra != null ? (
                                          <div className="flex flex-col items-end gap-0.5">
                                            <span className="font-mono text-sm font-bold text-red-600">+R$ {fmtNum(custoExtra)}</span>
                                            <span className="text-[10px] text-slate-400">
                                              {pctFunc}% de R$ {fmtNum(custoNormal ?? 0)}
                                            </span>
                                          </div>
                                        ) : <span className="text-xs text-slate-300">—</span>}
                                      </td>
                                    </>)}
                                  </>)}
                                </tr>
                              );
                            })}
                          </tbody>
                          {horasHE > 0 && (
                            <tfoot className={`border-t-2 ${isWeekend ? "border-orange-300 bg-orange-50" : "border-slate-300 bg-slate-100"}`}>
                              <tr>
                                <td colSpan={3} className="px-3 py-2.5 text-xs font-bold text-slate-600 text-right uppercase tracking-wide">
                                  Totais
                                </td>
                                <td className="px-3 py-2.5 text-right">
                                  <span className="text-xs text-slate-400 font-mono">—</span>
                                </td>
                                <td className="px-3 py-2.5 text-right">
                                  <span className="font-mono font-bold text-slate-700">R$ {fmtNum(totalNormalGlobal)}</span>
                                  <p className="text-[10px] text-slate-400">VH × {horasHE.toFixed(1)}h (sem adicional)</p>
                                </td>
                                <td className="px-3 py-2.5 text-right">
                                  <span className={`font-mono font-bold text-base ${isWeekend ? "text-orange-700" : "text-blue-800"}`}>
                                    R$ {fmtNum(custoTotal)}
                                  </span>
                                  <p className="text-[10px] text-slate-400">com adicional {percentHE}%</p>
                                </td>
                                <td className="px-3 py-2.5 text-right">
                                  <span className="font-mono font-bold text-red-600 text-base">+R$ {fmtNum(totalExtraGlobal)}</span>
                                  <p className="text-[10px] text-slate-400">custo extra do adicional</p>
                                </td>
                              </tr>
                            </tfoot>
                          )}
                        </table>
                      </div>
                    </div>

                    {/* ── Painel de resumo ── */}
                    {horasHE > 0 && (() => {
                      const borderColor = isWeekend ? "border-orange-300 bg-orange-50" : "border-blue-200 bg-blue-50";
                      const accentColor = isWeekend ? "text-orange-700" : "text-blue-700";
                      return (
                        <div className={`rounded-lg border-2 p-4 space-y-3 ${borderColor}`}>
                          <div className="flex items-center gap-2">
                            <TrendingUp className={`h-4 w-4 ${accentColor}`} />
                            <span className={`font-bold text-sm ${accentColor}`}>Resumo do Custo Previsto</span>
                          </div>

                          {/* Linha 1: info geral */}
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                            <div className="bg-white rounded p-2 border border-slate-200">
                              <p className="text-muted-foreground mb-1">Duração</p>
                              <p className="font-bold text-base">{horasHE.toFixed(1)}h</p>
                              <p className="text-[10px] text-muted-foreground">{sol.horaInicio} → {sol.horaFim}</p>
                            </div>
                            <div className={`bg-white rounded p-2 border ${isWeekend ? "border-orange-300" : "border-blue-200"}`}>
                              <p className="text-muted-foreground mb-1">Tipo de HE</p>
                              <p className={`font-bold text-base ${isWeekend ? "text-orange-600" : "text-blue-700"}`}>+{percentHE}%</p>
                              <p className="text-[10px] text-muted-foreground">
                                {isDomingo ? "Domingo — 100% CLT art. 67" : isSabado ? "Sábado — 100% CLT/CCT" : "Dia útil — 50% CLT art. 59"}
                              </p>
                            </div>
                            <div className="bg-white rounded p-2 border border-slate-200">
                              <p className="text-muted-foreground mb-1">Funcionários (com HE)</p>
                              <p className="font-bold text-base">{elegiveis.length}<span className="text-xs font-normal text-muted-foreground">/{funcs.length}</span></p>
                              {semSalario.length > 0 && (
                                <p className="text-[10px] text-red-500">{semSalario.length} sem salário</p>
                              )}
                              {confiancaList.length > 0 && (
                                <p className="text-[10px] text-violet-600">{confiancaList.length} cargo de confiança (sem HE)</p>
                              )}
                              {semSalario.length === 0 && confiancaList.length === 0 && (
                                <p className="text-[10px] text-green-600">Todos com salário</p>
                              )}
                            </div>
                            <div className="bg-white rounded p-2 border border-slate-200">
                              <p className="text-muted-foreground mb-1">Base salarial</p>
                              <p className="text-[10px] leading-relaxed text-slate-700">
                                {funcs.filter((f: any) => getValorHoraInfo(f).fonte === "valorHora").length > 0 && (
                                  <span className="block text-green-700">✓ {funcs.filter((f: any) => getValorHoraInfo(f).fonte === "valorHora").length} via Valor/h direto</span>
                                )}
                                {funcs.filter((f: any) => getValorHoraInfo(f).fonte === "salarioBase").length > 0 && (
                                  <span className="block text-amber-600">✓ {funcs.filter((f: any) => getValorHoraInfo(f).fonte === "salarioBase").length} via Salário ÷ 220h</span>
                                )}
                                {semSalario.length > 0 && (
                                  <span className="block text-red-500">✗ {semSalario.length} sem dados</span>
                                )}
                              </p>
                            </div>
                          </div>

                          {/* Linha 2: comparativo Normal × HE × Diferença */}
                          <div className="grid grid-cols-3 gap-3 text-xs">
                            <div className="bg-white rounded-lg p-3 border border-slate-200">
                              <p className="text-slate-500 font-semibold mb-1 uppercase text-[10px] tracking-wide">
                                Custo sem adicional
                              </p>
                              <p className="font-bold text-xl text-slate-700">
                                R$ {fmtNum(totalNormalGlobal)}
                              </p>
                              <p className="text-[10px] text-slate-400 mt-1">
                                VH × {horasHE.toFixed(1)}h × {elegiveis.length} func.
                              </p>
                            </div>
                            <div className={`rounded-lg p-3 border-2 ${isWeekend ? "border-orange-400 bg-orange-50" : "border-blue-400 bg-white"}`}>
                              <p className={`font-semibold mb-1 uppercase text-[10px] tracking-wide ${isWeekend ? "text-orange-700" : "text-blue-700"}`}>
                                Custo real da HE
                              </p>
                              <p className={`font-bold text-xl ${isWeekend ? "text-orange-700" : "text-blue-800"}`}>
                                R$ {fmtNum(custoTotal)}
                              </p>
                              <p className="text-[10px] text-slate-400 mt-1">
                                Valor/h × {(1 + percentHE / 100).toFixed(2)} × {horasHE.toFixed(1)}h
                              </p>
                            </div>
                            <div className="bg-red-50 rounded-lg p-3 border-2 border-red-300">
                              <p className="text-red-600 font-semibold mb-1 uppercase text-[10px] tracking-wide">
                                Diferença ({percentHE}% adicional)
                              </p>
                              <p className="font-bold text-xl text-red-600">+R$ {fmtNum(totalExtraGlobal)}</p>
                              <p className="text-[10px] text-slate-400 mt-1">
                                Custo HE − Custo normal
                              </p>
                            </div>
                          </div>

                          {semSalario.length > 0 && (
                            <p className="text-[11px] text-amber-700 bg-amber-50 border border-amber-200 rounded px-2 py-1">
                              ⚠ {semSalario.length} funcionário(s) sem salário/valor-hora cadastrado — não incluídos nos totais.
                            </p>
                          )}
                        </div>
                      );
                    })()}
                  </div>
                );
              })()}

              {/* ═══ CONFIRMAÇÃO DE PRESENÇA ═══ */}
              {(() => {
                const funcs = sol.funcionarios || [];
                const funcIds = new Set(funcs.map((f: any) => f.employeeId));
                const allConfs = confirmQ.data || [];
                const confs = allConfs.filter((c: any) => funcIds.has(c.employeeId));
                const confirmadosSet = new Set(confs.map((c: any) => c.employeeId));
                const pendentes = funcs.filter((f: any) => !confirmadosSet.has(f.employeeId));
                const totalConf = confs.length;
                const totalFuncs = funcs.length;
                const compareceuList = confs.filter((c: any) => c.compareceu === true);
                const ausenteList = confs.filter((c: any) => c.compareceu === false);
                const semRegistro = confs.filter((c: any) => c.compareceu === null);

                return (
                  <div className="rounded-lg border-2 border-amber-300 bg-amber-50 p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <ClipboardCheck className="h-4 w-4 text-amber-700" />
                        <span className="font-bold text-sm text-amber-800">
                          Confirmação de Presença — {totalConf}/{totalFuncs} assinaram
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        {ausenteList.length > 0 && (
                          <Badge className="bg-red-100 text-red-800 border-red-300 text-xs">
                            {ausenteList.length} ausente(s)
                          </Badge>
                        )}
                        {compareceuList.length > 0 && (
                          <Badge className="bg-green-100 text-green-800 border-green-300 text-xs">
                            {compareceuList.length} compareceu
                          </Badge>
                        )}
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <p className="text-xs font-semibold text-gray-600">Funcionários:</p>
                      <div className="flex flex-wrap gap-2">
                        {funcs.map((f: any) => {
                          const jaAssinou = confirmadosSet.has(f.employeeId);
                          if (jaAssinou) {
                            return (
                              <div
                                key={f.employeeId}
                                className="flex items-center gap-1.5 bg-green-50 border border-green-400 rounded-lg px-3 py-2 text-sm cursor-default"
                              >
                                <CheckCircle2 className="h-3.5 w-3.5 text-green-600" />
                                <span className="font-medium text-green-800">{f.employeeName || `ID ${f.employeeId}`}</span>
                              </div>
                            );
                          }
                          return (
                            <button
                              key={f.employeeId}
                              type="button"
                              onClick={() => { setAssinaturaEmployeeId(f.employeeId); setAssinaturaEmployeeName(f.employeeName || `ID ${f.employeeId}`); }}
                              className="flex items-center gap-1.5 bg-white border border-amber-300 rounded-lg px-3 py-2 text-sm hover:bg-amber-100 transition-colors"
                            >
                              <SquarePen className="h-3.5 w-3.5 text-amber-600" />
                              <span className="font-medium">{f.employeeName || `ID ${f.employeeId}`}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {totalConf > 0 && (
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between">
                          <p className="text-xs font-semibold text-green-700">Já confirmaram ({totalConf}):</p>
                          {semRegistro.length > 0 && sol.status === "aprovada" && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-7 text-xs border-blue-300 text-blue-700 hover:bg-blue-50"
                              onClick={() => setModoComparecimento(!modoComparecimento)}
                            >
                              <UserCheck className="h-3 w-3 mr-1" />
                              {modoComparecimento ? "Cancelar" : "Registrar Comparecimento"}
                            </Button>
                          )}
                          {semRegistro.length > 0 && sol.status !== "aprovada" && (
                            <span className="text-xs text-amber-600 italic">Aprovação necessária para registrar comparecimento</span>
                          )}
                        </div>
                        <div className="divide-y divide-amber-200 border border-amber-200 rounded-lg overflow-hidden bg-white">
                          {confs.map((c: any) => (
                            <div key={c.id} className={`px-3 py-2 space-y-2 ${c.compareceu === false ? "bg-red-50" : c.compareceu === true ? "bg-green-50" : ""}`}>
                              <div className="flex items-center gap-3 text-sm">
                                <div className="flex-1 min-w-0">
                                  <span className="font-medium">{c.nomeCompleto || `ID ${c.employeeId}`}</span>
                                  {c.matricula && <span className="text-xs text-muted-foreground ml-1">({c.matricula})</span>}
                                  {c.cargo && <span className="text-xs text-muted-foreground ml-1">— {c.cargo}</span>}
                                </div>
                                <div className="text-xs text-muted-foreground shrink-0">
                                  {c.confirmedAt && new Date(c.confirmedAt).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}
                                </div>
                                {c.assinaturaDivergente && (
                                  <Badge className="bg-red-200 text-red-900 border-red-400 text-xs shrink-0 animate-pulse">
                                    <AlertTriangle className="h-3 w-3 mr-1" /> Assinatura Divergente ({c.similaridade || 0}%)
                                  </Badge>
                                )}
                                {c.provaAlternativa && (
                                  <Badge className="bg-blue-100 text-blue-800 border-blue-300 text-xs shrink-0">
                                    {c.provaAlternativaTipo === "video" ? <Video className="h-3 w-3 mr-1" /> : <Camera className="h-3 w-3 mr-1" />}
                                    Prova {c.provaAlternativaTipo === "video" ? "vídeo" : "foto"}
                                  </Badge>
                                )}
                                {c.compareceu === true && (
                                  <Badge className="bg-green-100 text-green-800 border-green-300 text-xs shrink-0">
                                    <UserCheck className="h-3 w-3 mr-1" /> Compareceu
                                  </Badge>
                                )}
                                {c.compareceu === false && (
                                  <Badge className="bg-red-100 text-red-800 border-red-300 text-xs shrink-0">
                                    <UserX className="h-3 w-3 mr-1" /> Ausente
                                  </Badge>
                                )}
                                {c.compareceu === null && !modoComparecimento && (
                                  <Badge variant="outline" className="text-xs shrink-0">Aguardando</Badge>
                                )}
                                {c.compareceu === null && modoComparecimento && (
                                  <div className="flex gap-1 shrink-0">
                                    <Button size="sm" className="h-6 text-xs bg-green-600 hover:bg-green-700 px-2"
                                      onClick={() => comparecMut.mutate({ solicitacaoId: sol.id, registros: [{ employeeId: c.employeeId, compareceu: true }] })}
                                      disabled={comparecMut.isPending}
                                    >
                                      <UserCheck className="h-3 w-3" />
                                    </Button>
                                    <Button size="sm" variant="destructive" className="h-6 text-xs px-2"
                                      onClick={() => {
                                        setAusenciaDialog({ employeeId: c.employeeId, nome: c.nomeCompleto || "Funcionário", solicitacaoId: sol.id, dataSolicitacao: sol.dataSolicitacao });
                                        setJustificativaTexto("");
                                      }}
                                      disabled={comparecMut.isPending}
                                    >
                                      <UserX className="h-3 w-3" />
                                    </Button>
                                  </div>
                                )}
                                {c.assinaturaUrl && (
                                  <button
                                    type="button"
                                    onClick={() => setVerAssinatura(verAssinatura === c.id ? null : c.id)}
                                    className="text-xs text-blue-600 hover:text-blue-800 flex items-center gap-1 shrink-0"
                                  >
                                    <SquarePen className="h-3 w-3" />
                                    {verAssinatura === c.id ? "Ocultar" : "Ver Assinatura"}
                                  </button>
                                )}
                              </div>
                              {c.observacao && c.compareceu === false && (
                                <p className="text-xs text-red-600 italic pl-1">{c.observacao}</p>
                              )}
                              {verAssinatura === c.id && c.assinaturaUrl && (
                                <div className={`border rounded-lg p-2 ${c.assinaturaDivergente ? "border-red-300 bg-red-50" : "border-gray-200 bg-white"}`}>
                                  <div className="flex items-center justify-between mb-1">
                                    <span className="text-xs font-medium text-gray-500">Assinatura digital de {c.nomeCompleto || "funcionário"}</span>
                                    {c.assinaturaDivergente && (
                                      <span className="text-xs font-bold text-red-700 flex items-center gap-1">
                                        <AlertTriangle className="h-3 w-3" />
                                        Diverge do memorial ({c.similaridade || 0}% similaridade)
                                      </span>
                                    )}
                                    {!c.assinaturaDivergente && c.similaridade && (
                                      <span className="text-xs text-green-600 flex items-center gap-1">
                                        <CheckCircle2 className="h-3 w-3" />
                                        {c.similaridade}% similaridade com memorial
                                      </span>
                                    )}
                                  </div>
                                  <img src={c.assinaturaUrl} alt={`Assinatura de ${c.nomeCompleto}`} className="max-h-24 mx-auto" />
                                  {c.assinaturaDivergente && !c.provaAlternativa && (
                                    <div className="mt-2 pt-2 border-t border-red-200">
                                      <p className="text-xs text-red-700 mb-2">
                                        <AlertTriangle className="h-3 w-3 inline mr-1" />
                                        Assinatura não confere com o memorial ({c.similaridade || 0}% &lt; 90% mínimo).
                                        Anexe uma <strong>foto ou vídeo</strong> do funcionário confirmando a HE:
                                      </p>
                                      <Button
                                        size="sm"
                                        variant="outline"
                                        className="text-blue-700 border-blue-300 hover:bg-blue-50"
                                        onClick={() => handleProvaAlternativa(c.id)}
                                        disabled={provaAltMut.isPending}
                                      >
                                        {provaAltMut.isPending ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> : <Upload className="h-3.5 w-3.5 mr-1" />}
                                        Anexar Foto/Vídeo como Prova
                                      </Button>
                                    </div>
                                  )}
                                  {c.provaAlternativa && (
                                    <div className="mt-2 pt-2 border-t border-blue-200">
                                      <p className="text-xs text-blue-700 mb-1 flex items-center gap-1">
                                        <CheckCircle2 className="h-3 w-3 text-green-600" />
                                        Prova alternativa ({c.provaAlternativaTipo}) anexada por {c.provaAlternativaPor} em{" "}
                                        {c.provaAlternativaEm ? new Date(c.provaAlternativaEm).toLocaleString("pt-BR") : "-"}
                                      </p>
                                      {c.provaAlternativaTipo === "foto" && (
                                        <img src={c.provaAlternativa} alt="Prova foto" className="max-h-32 mx-auto rounded border" />
                                      )}
                                      {c.provaAlternativaTipo === "video" && (
                                        <video src={c.provaAlternativa} controls className="max-h-32 mx-auto rounded border" />
                                      )}
                                    </div>
                                  )}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                        {modoComparecimento && semRegistro.length > 1 && (
                          <div className="flex gap-2 pt-1">
                            <Button size="sm" className="text-xs bg-green-600 hover:bg-green-700"
                              onClick={() => comparecMut.mutate({ solicitacaoId: sol.id, registros: semRegistro.map((c: any) => ({ employeeId: c.employeeId, compareceu: true })) })}
                              disabled={comparecMut.isPending}
                            >
                              <UserCheck className="h-3 w-3 mr-1" /> Todos compareceram
                            </Button>
                            <Button size="sm" variant="destructive" className="text-xs"
                              onClick={() => {
                                const primeiro = semRegistro[0];
                                setAusenciaDialog({
                                  employeeId: primeiro.employeeId,
                                  nome: "Todos os funcionários pendentes",
                                  solicitacaoId: sol.id,
                                  dataSolicitacao: sol.dataSolicitacao,
                                  bulk: semRegistro.map((c: any) => ({ employeeId: c.employeeId, nome: c.nomeCompleto || "Funcionário" }))
                                });
                                setJustificativaTexto("");
                              }}
                              disabled={comparecMut.isPending}
                            >
                              <UserX className="h-3 w-3 mr-1" /> Todos ausentes
                            </Button>
                          </div>
                        )}
                      </div>
                    )}

                    {totalConf === 0 && totalFuncs > 0 && (
                      <p className="text-xs text-amber-600">Nenhuma confirmação coletada ainda. Clique no nome do funcionário para colher a assinatura.</p>
                    )}
                  </div>
                );
              })()}

              {/* Histórico de decisão (se já teve) */}
              {sol.aprovadoPor && (
                <div className={`rounded-lg p-4 ${sol.status === "aprovada" ? "bg-green-50 border border-green-200" : sol.status === "rejeitada" ? "bg-red-50 border border-red-200" : "bg-gray-50 border"}`}>
                  <p className="text-sm font-semibold mb-1">
                    {sol.status === "aprovada" ? "✅ Aprovada" : sol.status === "rejeitada" ? "❌ Rejeitada" : "Decisão"} por {sol.aprovadoPor}
                  </p>
                  {sol.aprovadoEm && (
                    <p className="text-xs text-muted-foreground">Em {new Date(sol.aprovadoEm).toLocaleString("pt-BR")}</p>
                  )}
                  {sol.motivoRejeicao && (
                    <p className="text-sm mt-2"><strong>Motivo da rejeição:</strong> {sol.motivoRejeicao}</p>
                  )}
                  {sol.observacaoAdmin && (
                    <p className="text-sm mt-2"><strong>Observação do Admin:</strong> {sol.observacaoAdmin}</p>
                  )}
                </div>
              )}

              {/* Área de ação do Admin */}
              {isAdminMaster && sol.status !== "cancelada" && (
                <div className="border-t pt-6 space-y-4">
                  <h3 className="text-sm font-semibold flex items-center gap-2">
                    <MessageSquare className="h-4 w-4" />
                    Ação do Administrador
                  </h3>

                  {/* Campo de observação */}
                  <div>
                    <Label className="text-sm">Observações do Admin (opcional)</Label>
                    <Textarea
                      value={adminObs}
                      onChange={e => setAdminObs(e.target.value)}
                      placeholder="Registre suas observações sobre esta solicitação..."
                      className="mt-1"
                      rows={3}
                    />
                  </div>

                  {/* Formulário de rejeição (aparece ao clicar Rejeitar) */}
                  {showRejectForm && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-4 space-y-3">
                      <Label className="text-sm font-semibold text-red-700">Motivo da Rejeição *</Label>
                      <Textarea
                        value={rejectReason}
                        onChange={e => setRejectReason(e.target.value)}
                        placeholder="Informe o motivo da rejeição (mínimo 5 caracteres)..."
                        className="border-red-300"
                        rows={2}
                      />
                      <div className="flex gap-2">
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={handleRejectFromDialog}
                          disabled={rejectMut.isPending}
                        >
                          {rejectMut.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <XCircle className="h-4 w-4 mr-1" />}
                          Confirmar Rejeição
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => { setShowRejectForm(false); setRejectReason(""); }}>
                          Cancelar
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Botões de ação */}
                  {!showRejectForm && (
                    <div className="flex flex-wrap gap-3">
                      {canApprove && (
                        <Button
                          className="bg-green-600 hover:bg-green-700"
                          onClick={handleApproveFromDialog}
                          disabled={approveMut.isPending}
                        >
                          {approveMut.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <CheckCircle className="h-4 w-4 mr-2" />}
                          {sol.status === "rejeitada" ? "Reverter → Aprovar" : "Aprovar Solicitação"}
                        </Button>
                      )}
                      {canReject && (
                        <Button
                          variant="destructive"
                          onClick={() => setShowRejectForm(true)}
                        >
                          <XCircle className="h-4 w-4 mr-2" />
                          {sol.status === "aprovada" ? "Reverter → Rejeitar" : "Rejeitar Solicitação"}
                        </Button>
                      )}
                      {/* Botão Excluir - Admin Master */}
                      {confirmDeleteId === sol.id ? (
                        <div className="flex items-center gap-2 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                          <span className="text-sm text-red-700 font-medium">Excluir permanentemente?</span>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => { deleteMut.mutate({ id: sol.id }); setConfirmDeleteId(null); }}
                            disabled={deleteMut.isPending}
                          >
                            {deleteMut.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : "Sim, excluir"}
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => setConfirmDeleteId(null)}>Não</Button>
                        </div>
                      ) : (
                        <Button
                          variant="outline"
                          className="text-red-600 border-red-300 hover:bg-red-50"
                          onClick={() => setConfirmDeleteId(sol.id)}
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Excluir
                        </Button>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })() : (
          <div className="text-center py-12 text-muted-foreground">Solicitação não encontrada</div>
        )}
      </FullScreenDialog>

      {/* Dialog de Reversão de Aprovação */}
      <AlertDialog open={showRevertDialog} onOpenChange={(v) => { if (!v) { setShowRevertDialog(false); setRevertMotivo(""); } }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <RotateCcw className="h-5 w-5 text-orange-600" />
              Reverter Aprovação
            </AlertDialogTitle>
            <AlertDialogDescription>
              A solicitação HE-{String(detailSolId || "").padStart(5, "0")} voltará ao status <strong>"Pendente"</strong> e poderá ser reavaliada.
              Informe o motivo da reversão:
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-3 py-2">
            <Textarea
              value={revertMotivo}
              onChange={e => setRevertMotivo(e.target.value)}
              placeholder="Motivo da reversão (mínimo 5 caracteres)..."
              rows={3}
              className="border-orange-300 focus:border-orange-500"
            />
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <Button
              className="bg-orange-600 hover:bg-orange-700"
              disabled={revertMotivo.trim().length < 5 || reverterMut.isPending}
              onClick={() => { if (detailSolId) reverterMut.mutate({ id: detailSolId, motivo: revertMotivo.trim() }); }}
            >
              {reverterMut.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <RotateCcw className="h-4 w-4 mr-2" />}
              Confirmar Reversão
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {assinaturaEmployeeId && detailSolId && detailQuery.data && (
        <SignatureModal
          open={!!assinaturaEmployeeId}
          onClose={() => { setAssinaturaEmployeeId(null); setAssinaturaEmployeeName(""); }}
          employeeName={assinaturaEmployeeName}
          solicitacao={detailQuery.data}
          onConfirm={(base64: string) => {
            confirmarMut.mutate({
              solicitacaoId: detailQuery.data!.id,
              employeeId: assinaturaEmployeeId!,
              assinaturaBase64: base64,
            });
          }}
          isPending={confirmarMut.isPending}
        />
      )}

      <RaioXFuncionario employeeId={raioXEmployeeId} open={!!raioXEmployeeId} onClose={() => setRaioXEmployeeId(null)} />

      {/* ========== MODAL: HISTÓRICO DE HE DO FUNCIONÁRIO ========== */}
      <FullScreenDialog
        open={!!heHistoryEmployeeId}
        onClose={() => { setHeHistoryEmployeeId(null); setHeHistoryEmployeeName(""); }}
        title={`Histórico de HE — ${heHistoryEmployeeName}`}
      >
        <div className="max-w-3xl mx-auto space-y-4 p-2">
          <div className="flex items-center gap-2 text-sm text-muted-foreground pb-2 border-b">
            <History className="h-4 w-4 text-blue-600" />
            <span>Todas as solicitações de horas extras deste funcionário</span>
          </div>

          {heHistoryQuery.isLoading ? (
            <div className="flex items-center justify-center py-16">
              <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
            </div>
          ) : !heHistoryQuery.data || heHistoryQuery.data.length === 0 ? (
            <div className="text-center py-16 text-muted-foreground">
              <History className="h-12 w-12 mx-auto mb-3 opacity-30" />
              <p className="font-medium">Nenhuma HE registrada</p>
              <p className="text-sm">Este funcionário ainda não tem solicitações de horas extras.</p>
            </div>
          ) : (
            <div className="space-y-3">
              <p className="text-xs text-muted-foreground">{heHistoryQuery.data.length} solicitação(ões) encontrada(s)</p>
              {heHistoryQuery.data.map((row: any) => (
                <Card key={`${row.id}-${row.heStatus}`} className={`border-l-4 ${
                  row.status === "aprovada" ? "border-l-green-400" :
                  row.status === "rejeitada" ? "border-l-red-400" :
                  row.status === "cancelada" ? "border-l-gray-400" :
                  "border-l-yellow-400"
                }`}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1.5 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge className={`text-xs ${STATUS_COLORS[row.status] || STATUS_COLORS.pendente}`}>
                            {STATUS_LABELS[row.status] || row.status}
                          </Badge>
                          <span className="text-sm font-semibold">
                            #{row.id} — {new Date(row.dataSolicitacao + "T12:00:00").toLocaleDateString("pt-BR", { weekday: "long", day: "2-digit", month: "long", year: "numeric" })}
                          </span>
                        </div>
                        {row.obraNome && (
                          <p className="text-xs flex items-center gap-1 text-muted-foreground">
                            <Building2 className="h-3 w-3" /> {row.obraNome}
                          </p>
                        )}
                        <p className="text-sm"><strong>Motivo:</strong> {row.motivo}</p>
                        {row.horaInicio && row.horaFim && (
                          <p className="text-xs text-muted-foreground flex items-center gap-1">
                            <Clock className="h-3 w-3" /> {row.horaInicio} — {row.horaFim}
                          </p>
                        )}
                        {row.horasRealizadas && (
                          <p className="text-xs text-green-700 font-medium">
                            ✓ Horas realizadas: {row.horasRealizadas}h
                          </p>
                        )}
                        <p className="text-xs text-muted-foreground">
                          Solicitado por: {row.solicitadoPor}
                          {row.createdAt && ` em ${new Date(row.createdAt).toLocaleString("pt-BR")}`}
                        </p>
                        {row.aprovadoPor && (
                          <p className="text-xs text-muted-foreground">
                            {row.status === "aprovada" ? "✓ Aprovado" : "✗ Rejeitado"} por: {row.aprovadoPor}
                            {row.aprovadoEm && ` em ${new Date(row.aprovadoEm).toLocaleString("pt-BR")}`}
                          </p>
                        )}
                        {row.motivoRejeicao && (
                          <p className="text-xs text-red-600">Motivo rejeição: {row.motivoRejeicao}</p>
                        )}
                        {row.observacaoAdmin && (
                          <p className="text-xs text-blue-700">Obs: {row.observacaoAdmin}</p>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </FullScreenDialog>

    <AlertDialog open={!!ausenciaDialog} onOpenChange={(open) => { if (!open) setAusenciaDialog(null); }}>
      <AlertDialogContent className="max-w-md">
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center gap-2 text-red-700">
            <ShieldAlert className="h-5 w-5" />
            Ausência — {ausenciaDialog?.bulk ? `${ausenciaDialog.bulk.length} funcionários` : ausenciaDialog?.nome}
          </AlertDialogTitle>
          <AlertDialogDescription className="text-sm text-gray-700 space-y-3">
            <p>O funcionário apresentou justificativa para a ausência?</p>
            <div className="space-y-1.5">
              <Label htmlFor="justificativa-texto" className="text-xs font-medium">Justificativa: <span className="text-red-600">*</span></Label>
              <Textarea
                id="justificativa-texto"
                placeholder="Ex: atestado médico, compromisso pessoal..."
                value={justificativaTexto}
                onChange={(e) => setJustificativaTexto(e.target.value)}
                className={`text-sm h-16 ${!justificativaTexto.trim() ? "border-red-300 focus:border-red-500" : ""}`}
              />
              {!justificativaTexto.trim() && (
                <p className="text-xs text-red-500">Informe a justificativa da ausência</p>
              )}
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="flex-col sm:flex-row gap-2">
          <AlertDialogCancel className="text-sm">Cancelar</AlertDialogCancel>
          <Button
            className="bg-amber-600 hover:bg-amber-700 text-white text-sm"
            disabled={comparecMut.isPending || !justificativaTexto.trim()}
            onClick={() => {
              if (!ausenciaDialog || !justificativaTexto.trim()) return;
              const registros = ausenciaDialog.bulk
                ? ausenciaDialog.bulk.map((f) => ({
                    employeeId: f.employeeId,
                    compareceu: false,
                    observacao: `Falta justificada: ${justificativaTexto.trim()}`,
                  }))
                : [{
                    employeeId: ausenciaDialog.employeeId,
                    compareceu: false,
                    observacao: `Falta justificada: ${justificativaTexto.trim()}`,
                  }];
              comparecMut.mutate(
                { solicitacaoId: ausenciaDialog.solicitacaoId, registros },
                { onSuccess: () => setAusenciaDialog(null) }
              );
            }}
          >
            <CheckCircle2 className="h-4 w-4 mr-1" />
            Sim, justificou
          </Button>
          <Button
            variant="destructive"
            className="text-sm"
            disabled={comparecMut.isPending}
            onClick={() => {
              if (!ausenciaDialog) return;
              const registros = ausenciaDialog.bulk
                ? ausenciaDialog.bulk.map((f) => ({
                    employeeId: f.employeeId,
                    compareceu: false,
                    observacao: justificativaTexto
                      ? `Falta NÃO justificada — pendente de advertência. Obs: ${justificativaTexto}`
                      : "Falta NÃO justificada — pendente de advertência",
                  }))
                : [{
                    employeeId: ausenciaDialog.employeeId,
                    compareceu: false,
                    observacao: justificativaTexto
                      ? `Falta NÃO justificada — pendente de advertência. Obs: ${justificativaTexto}`
                      : "Falta NÃO justificada — pendente de advertência",
                  }];
              const targetEmployee = ausenciaDialog.bulk ? ausenciaDialog.bulk[0] : { employeeId: ausenciaDialog.employeeId, nome: ausenciaDialog.nome };
              const dataSol = ausenciaDialog.dataSolicitacao || new Date().toISOString().slice(0, 10);
              comparecMut.mutate(
                { solicitacaoId: ausenciaDialog.solicitacaoId, registros },
                {
                  onSuccess: () => {
                    setAusenciaDialog(null);
                    const preFill = {
                      employeeId: targetEmployee.employeeId,
                      employeeName: targetEmployee.nome,
                      dataOcorrencia: dataSol,
                      motivo: `Falta não justificada na Hora Extra (Solicitação #${ausenciaDialog.solicitacaoId}) do dia ${new Date(dataSol + "T12:00:00").toLocaleDateString("pt-BR")}`,
                      descricao: `O colaborador ${targetEmployee.nome} confirmou presença na solicitação de Hora Extra #${ausenciaDialog.solicitacaoId}, porém não compareceu e não apresentou justificativa.${justificativaTexto ? ` Observação: ${justificativaTexto}` : ""}`,
                    };
                    sessionStorage.setItem("advPreFill", JSON.stringify(preFill));
                    sessionStorage.setItem("_navParams", "tab=advertencias&action=nova");
                    window.location.href = "/controle-documentos?tab=advertencias&action=nova";
                  },
                }
              );
            }}
          >
            <ShieldAlert className="h-4 w-4 mr-1" />
            Não justificou — Advertência
          </Button>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>

    <PrintFooterLGPD />
    </DashboardLayout>
  );
}
